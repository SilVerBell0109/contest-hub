/* 제주 상권 나침반 — 프런트엔드 (의존성 없는 순수 JS) */
(function () {
  const $ = (s, el = document) => el.querySelector(s);
  // 요소 생성 도우미. 속성값이 null/undefined/false면 속성을 달지 않는다 (예: selected/open 토글).
  const el = (tag, attrs = {}, children = []) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") e.className = v;
      else if (k === "html") e.innerHTML = v;
      else if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
      else if (v === true) e.setAttribute(k, "");
      else e.setAttribute(k, v);
    }
    for (const c of [].concat(children)) if (c !== null && c !== undefined && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c)));
    return e;
  };
  const api = async (path, opts = {}) => {
    const r = await fetch(path, { headers: opts.body instanceof FormData ? {} : { "Content-Type": "application/json" }, ...opts });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.error || `요청 실패 (${r.status})`);
    return data;
  };
  let status = null;
  const originLabel = (o) => ({ sample: "연습용(가짜)", center: "센터 데이터", hub: "허브 공개", unknown: "미분류" }[o] || o);
  const HEADER_OFFSET = 150;

  // ── 상태 표시 ──────────────────────────────────────────────────────────
  function renderStatus(s) {
    status = s;
    const chips = $("#statusChips");
    chips.innerHTML = "";
    const llm = s.llm || {};
    if (llm.enabled) {
      const err = llm.errors ? ` · 최근 오류 ${llm.errors}건${llm.last_error ? ": " + llm.last_error : ""}` : "";
      chips.append(el("span", { class: "chip " + (llm.errors && llm.last_error ? "warn" : "ok"), title: `${llm.provider} / ${llm.model}${err}` }, `🤖 AI 설명 켜짐 (${llm.provider})` + (llm.errors && llm.last_error ? " · 최근 호출 실패" : "")));
    } else {
      chips.append(el("span", { class: "chip", title: "센터 설정(API 키)에 따라 AI가 쓰는 설명문만 빠집니다. 숫자 분석·표·차트·보고서는 모두 정상 동작합니다." }, "AI 설명: 꺼짐(센터 설정) · 숫자 분석은 정상"));
    }
    chips.append(el("span", { class: "chip info" }, `📚 데이터 ${s.datasets.length}종` + (s.latest_month ? ` · 최신 ${s.latest_month.slice(0, 4)}.${s.latest_month.slice(4)}` : "")));
    if (s.sample_mode) chips.append(el("span", { class: "chip warn", title: "지금 들어 있는 데이터는 연습용 가짜(합성) 데이터입니다. 실제 수치가 아닙니다." }, "🧪 연습용 가짜 데이터 사용 중"));
    chips.append(el("span", { class: "chip", title: s.pdf_browser ? "이 PC의 브라우저(Edge/Chrome)로 PDF를 만듭니다" : "브라우저를 찾지 못해 간이 PDF를 만듭니다. 보고서(HTML)를 열어 인쇄 → 'PDF로 저장'도 가능합니다." }, s.pdf_browser ? "🖨 PDF 저장 가능" : "🖨 PDF: 간이 변환"));
    $("#inboxPath").textContent = "data/inbox"; $("#inboxPath").title = "실제 위치: " + s.inbox;
    if (s.hub_key_present) $("#hubNote").textContent = "프로젝트 키가 설정되어 있습니다. 기간을 입력하고 가져오기를 누르세요 (일일 호출 한도 1,000건).";
    renderDatasets(s.datasets);
    const tl = $("#templateList"); tl.innerHTML = "";
    for (const t of s.templates) tl.append(el("li", {}, [el("b", {}, t.name), el("span", {}, t.description)]));
    const ex = $("#examples"); ex.innerHTML = "";
    ex.append(el("span", { class: "muted small", style: "align-self:center" }, "눌러서 바로 물어보기:"));
    for (const q of s.examples) ex.append(el("button", { class: "ex", type: "button", onclick: () => { $("#question").value = q; ask(); } }, q));
  }

  function renderDatasets(list) {
    const box = $("#datasets"); box.innerHTML = "";
    if (!list.length) { box.append(el("div", { class: "muted" }, "아직 들어 있는 데이터가 없습니다. 먼저 [연습용 데이터(가짜)]로 써 보거나, 센터에서 받은 CSV를 넣어 주세요.")); return; }
    for (const d of list) {
      const per = d.period_start ? `${d.period_start.slice(0, 4)}.${d.period_start.slice(4)}~${d.period_end.slice(0, 4)}.${d.period_end.slice(4)} (${d.months}개월)` : "기간 정보 없음";
      const warn = (d.warnings || []).length ? el("div", { class: "m warn", title: d.warnings.join("\n") }, `⚠ 확인 필요 ${d.warnings.length}건 (마우스를 올리면 내용)`) : null;
      box.append(el("div", { class: "ds" + (d.origin === "sample" ? " sample" : "") }, [
        el("div", {}, [el("div", { class: "n" }, d.name), el("div", { class: "m" }, `${per} · ${d.rows.toLocaleString()}행` + (d.regions ? ` · ${d.regions}개 동네` : "")),
          d.unmapped && d.unmapped.length && d.origin !== "hub" ? el("div", { class: "m", title: d.unmapped.join(", ") }, `자동으로 알아보지 못한 열 ${d.unmapped.length}개(담당자 확인)`) : null, warn]),
        el("div", { class: "dsr" }, [el("span", { class: "badge " + d.origin }, originLabel(d.origin)), el("button", { class: "badge x", type: "button", tabindex: "-1", title: "이 데이터를 빼기", onclick: () => { if (confirm(`'${d.name}' (${d.rows.toLocaleString()}행)을 데이터함에서 뺄까요?\n뺀 데이터는 다시 넣어야 합니다.`)) removeDs(d.key); } }, "빼기")]),
      ]));
    }
  }

  async function refresh() { renderStatus(await api("/api/status")); }
  async function removeDs(key) { try { await api("/api/remove", { method: "POST", body: JSON.stringify({ key }) }); await refresh(); } catch (e) { showError(e.message); } }

  // ── 결과 카드 조각 ─────────────────────────────────────────────────────
  function kpiTile(k) {
    const d = k.delta;
    const parts = [el("div", { class: "l" }, k.label), el("div", { class: "v" + (String(k.value).startsWith("비공개") || String(k.value).startsWith("검수 불가") ? " hiddenv" : "") }, k.value)];
    if (d !== null && d !== undefined) parts.push(el("div", { class: "d " + (d >= 0 ? "up" : "down") }, `${k.delta_label || "작년 같은 기간보다"} ${d >= 0 ? "+" : ""}${Number(d).toFixed(1)}%`));
    if (k.note) parts.push(el("div", { class: "d" }, k.note));
    return el("div", { class: "kpi" }, parts);
  }
  function cellEl(v) {
    const s = String(v ?? "");
    return el("td", { class: s.startsWith("비공개") ? "hid" : null, title: s.startsWith("비공개") ? "10명(건) 미만이라 개인정보 보호를 위해 가린 칸입니다" : null }, s);
  }
  function tableEl(t) {
    const thead = el("tr", {}, t.columns.map((c) => el("th", {}, c)));
    const rows = t.rows.map((r) => el("tr", {}, r.map(cellEl)));
    const hidden = (t.sdc && (t.sdc.n_suppressed || 0) + (t.sdc.n_secondary || 0)) || 0;
    return el("details", { class: "tbl", open: t.rows.length <= 12 }, [
      el("summary", {}, [t.name + " ", el("span", { class: "badge " + (t.sdc.passed ? "pass" : "warn") }, t.sdc.plain || t.sdc.summary), hidden ? el("span", { class: "muted small" }, ` (가린 칸 ${hidden}개)`) : null]),
      el("div", { class: "tblwrap" }, el("table", { class: "t" }, [el("thead", {}, thead), el("tbody", {}, rows)])),
      t.note ? el("div", { class: "muted small" }, t.note) : null,
    ]);
  }
  function exampleChips(qs) {
    if (!qs || !qs.length) return null;
    return el("p", { class: "small exwrap" }, ["이렇게 물어보세요: ", ...qs.map((q) => el("button", { class: "ex", type: "button", onclick: () => { $("#question").value = q; ask(); } }, q))]);
  }
  function guideEl(g) {
    if (!g) return null;
    if (g.kind === "help") {
      const h = g.help || {};
      return el("div", { class: "guide" }, [
        el("h4", {}, "이 프로그램으로 할 수 있는 것"), el("ul", { class: "steps" }, (h.can || []).map((s) => el("li", {}, s))),
        el("h4", {}, "할 수 없는 것"), el("ul", { class: "steps muted" }, (h.cannot || []).map((s) => el("li", {}, s))),
        el("h4", {}, "쓰는 법"), el("ol", { class: "steps" }, (h.how || []).map((s) => el("li", {}, s))),
        exampleChips(g.example_questions),
      ]);
    }
    const rows = (g.items || []).map((it) => el("tr", {}, [
      el("td", { style: "text-align:left;white-space:normal" }, [it.name, el("div", { class: "muted small" }, it.role)]),
      el("td", { style: "text-align:left" }, it.source === "center" ? "센터 PC" : "허브(공개)"),
      el("td", { style: "text-align:left" }, it.loaded ? el("span", { class: "badge pass" }, "들어 있음" + (it.origin === "sample" ? "(가짜)" : "")) : el("span", { class: "badge warn" }, "없음")),
      el("td", { style: "text-align:left;white-space:normal" }, it.download_guide)]));
    return el("div", { class: "guide" }, [
      el("h4", {}, "필요한 데이터와 받는 방법"),
      el("div", { class: "tblwrap" }, el("table", { class: "t" }, [el("thead", {}, el("tr", {}, ["데이터", "어디서", "지금 상태", "받는 방법"].map((h) => el("th", { style: "text-align:left" }, h)))), el("tbody", {}, rows)])),
      g.conditions ? el("p", { class: "small" }, [el("b", {}, "받을 조건: "), `기간 ${g.conditions.period} (${(g.conditions.months || []).length}개 파일) · 지역 ${g.conditions.region_label}`]) : null,
      g.conditions ? el("p", { class: "muted small" }, g.conditions.note) : null,
      el("h4", {}, "진행 순서"), el("ol", { class: "steps" }, (g.steps || []).map((s) => el("li", {}, s))),
      exampleChips(g.example_questions),
    ]);
  }
  function clarifyEl(p) {
    const c = p.clarify || {};
    const box = el("div", { class: "clarify" });
    box.append(el("p", { class: "q" }, c.message || "조금 더 알려 주세요."));
    const opts = el("div", { class: "opts" });
    for (const o of c.options || []) opts.append(el("button", { class: "btn opt", type: "button", onclick: () => { $("#question").value = o.question; ask(); } }, o.label));
    box.append(opts);
    if (c.free_input !== false) {
      const base = c.free_prefix || p.question;
      const isInd = c.type === "industry";
      const inp = el("input", { placeholder: c.free_label || "동네 이름을 직접 쓰기 (예: 애월읍, 노형동, 서귀포시 서부)" });
      const go = el("button", { class: "btn primary", type: "button", onclick: () => { const v = inp.value.trim(); if (!v) return; $("#question").value = (c.free_mode === "suffix" || isInd) ? `${base} ${v}` : `${v} ${base}`; ask(); } }, isInd ? "이 업종으로 보기" : "이 동네로 보기");
      inp.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) go.click(); });
      box.append(el("div", { class: "free" }, [inp, go]));
      setTimeout(() => inp.focus(), 50);
    }
    return box;
  }
  function fixForm(p, card) {
    const plan = p.plan;
    const f = el("div", { class: "fixform" });
    const region = el("input", { value: plan.region_scope === "all" ? "" : (plan.region_label || ""), placeholder: "예: 애월읍 / 제주시 서부 / 노형동과 연동 (비우면 제주 전체)" });
    const ind = el("input", { value: (plan.industries || []).join(", "), placeholder: "예: 카페 / 한식 / 숙박 (비우면 전체 업종)" });
    const per = el("input", { value: plan.period ? (plan.period.range_text || plan.period.label) : "", placeholder: "비우면 지금 기간 그대로. 예: 2026년 상반기 / 최근 6개월", title: "기간은 '2025년 10월~2026년 9월'처럼 범위로 적거나, '2026년 상반기', '최근 6개월'처럼 적습니다" });
    const tpl = el("select", {}, status.templates.map((t) => el("option", { value: t.key, selected: t.key === plan.template }, t.name)));
    const topn = el("input", { type: "number", min: 1, max: 50, value: plan.top_n || 10 });
    f.append(el("label", {}, ["동네(지역)", region]), el("label", {}, ["업종", ind]), el("label", {}, ["기간", per]), el("label", {}, ["분석 종류", tpl]), el("label", { title: "순위 표에 몇 줄까지 보여 줄지(기본 10)" }, ["표에 보일 줄 수", topn]));
    f.append(el("label", {}, ["", el("button", { class: "btn primary", type: "button", onclick: async () => {
      setBusy(true);
      try {
        const res = await api("/api/rerun", { method: "POST", body: JSON.stringify({ run_id: p.run_id, override: { region_text: region.value.trim(), industry_text: ind.value.trim(), period_text: per.value.trim(), template: tpl.value, top_n: Number(topn.value) || 10 } }) });
        const fresh = resultCard(res); card.replaceWith(fresh); scrollToCard(fresh);
      } catch (e) { showError(e.message); } finally { setBusy(false); }
    } }, "고친 대로 다시 분석")]));
    return f;
  }
  function pdfButton(p) {
    const btn = el("button", { class: "btn primary2", type: "button" }, "📑 보고서 PDF 저장");
    const info = el("span", { class: "small pdfinfo" });
    btn.addEventListener("click", async () => {
      btn.disabled = true; btn.textContent = "PDF 만드는 중…";
      try {
        const r = await api("/api/pdf", { method: "POST", body: JSON.stringify({ run_id: p.run_id }) });
        info.innerHTML = "";
        const fname = (r.pdf_url || "").split("/").pop();
        info.append(el("b", {}, "저장했어요: "), el("code", { title: "이 PC에 저장된 위치: " + (r.pdf_path || "") }, fname), " ", el("a", { href: r.pdf_url, target: "_blank" }, "다시 열기"),
          el("div", { class: "muted small" }, "새 창에 열린 보고서 오른쪽 위의 ⬇(다운로드) 버튼을 누르면 바탕화면이나 USB에 저장할 수 있어요. 가져가려면 센터 '반출 신청'이 필요합니다."));
        if (r.warning) info.append(el("div", { class: "warn small" }, "⚠ " + r.warning));
        window.open(r.pdf_url, "_blank");
        btn.textContent = "📑 PDF 다시 만들기";
      } catch (e) { showError(e.message); btn.textContent = "📑 보고서 PDF 저장"; } finally { btn.disabled = false; }
    });
    return el("div", { class: "pdfrow" }, [btn, info]);
  }

  // ── 결과 카드 ──────────────────────────────────────────────────────────
  function resultCard(p) {
    const card = el("article", { class: "result" + (p.kind === "clarify" ? " clarifycard" : ""), id: "run-" + p.run_id });
    const plan = p.plan || {};
    const src = plan.source === "llm" ? "AI가 해석" : plan.source === "user" ? "직접 고친 해석" : "규칙으로 해석";
    const isNav = plan.template === "navigator";
    const isClarify = p.kind === "clarify";

    const body = el("div", { class: "body" });
    const fold = el("button", { class: "btn ghost fold", type: "button", title: "이 결과를 접거나 펼칩니다", onclick: () => { const hidden = body.classList.toggle("hidden"); fold.textContent = hidden ? "펼치기" : "접기"; } }, "접기");
    card.append(el("div", { class: "head" }, [
      el("div", {}, [el("h3", {}, p.title), el("div", { class: "sub" }, [p.subtitle, p.generated_at ? ` · ${p.generated_at}` : "", p.elapsed_s !== undefined ? ` · ${p.elapsed_s}초` : ""])]),
      el("div", { class: "headr" }, [
        isClarify || isNav ? null : (p.sample ? el("span", { class: "badge sample big" }, "연습용 가짜 데이터 결과") : el("span", { class: "badge center big" }, "실제 데이터")),
        isClarify ? null : fold,
      ]),
    ]));
    card.append(body);
    const append = card.append.bind(card);
    card.append = (...nodes) => body.append(...nodes);
    if (p.sample && !isClarify && !isNav) card.append(el("div", { class: "samplebar" }, "※ 지금 보이는 숫자는 연습용 가짜(합성) 데이터로 만든 것입니다. 실제 자료가 아니므로 사업 판단에 쓰지 마세요. 센터에서 받은 데이터를 넣으면 실제 결과가 나옵니다."));

    if (isClarify) {
      card.append(clarifyEl(p));
      return card;
    }

    // 프로그램이 이해한 내용 + 고치기
    if (!isNav) {
      const planBox = el("div", { class: "plan" }, [
        el("span", { class: "plabel" }, "프로그램이 이렇게 이해했어요:"),
        el("span", {}, [el("b", {}, "분석"), plan.template_name]), el("span", {}, [el("b", {}, "동네"), plan.region_label]), el("span", {}, [el("b", {}, "업종"), plan.industry_label]), el("span", {}, [el("b", {}, "기간"), plan.period_label]),
        el("span", { class: "badge", title: plan.reasoning || "" }, src)]);
      planBox.append(el("button", { class: "btn fix", type: "button", title: "동네·업종·기간·분석 종류를 고쳐서 다시 분석합니다", onclick: () => { const f = $(".fixform", card); if (f) f.remove(); else planBox.after(fixForm(p, card)); } }, "✏️ 고칠래요"));
      card.append(planBox);
    }
    if (!isNav && p.ok) card.append(pdfButton(p));

    if (p.kpis && p.kpis.length) card.append(el("div", { class: "kpis" }, p.kpis.map(kpiTile)));
    if (p.findings && p.findings.length) card.append(el("ul", { class: "findings" }, p.findings.map((f) => el("li", { class: f.level }, f.text))));
    if (p.narrative) card.append(el("div", {}, [el("h4", { class: "sech" }, ["AI가 쉽게 풀어 쓴 설명 ", el("span", { class: "badge" }, "가린 칸 없는 집계값만 사용")]), el("div", { class: "narr" }, p.narrative)]));
    if (p.guidance) card.append(guideEl(p.guidance));
    if (p.charts && p.charts.length) card.append(el("div", { class: "charts" }, p.charts.map((c) => el("div", { class: "chart" }, el("a", { href: c.url, target: "_blank", title: "새 창에서 그림 열기" }, el("img", { src: c.url, alt: c.title, loading: "lazy" }))))));
    if (p.tables && p.tables.length) { const wrap = el("div"); for (const t of p.tables) wrap.append(tableEl(t)); card.append(wrap); }
    if (p.sdc_overall && (p.tables || []).length) {
      const so = p.sdc_overall;
      card.append(el("div", { class: "sdcbox" }, [
        el("div", { class: "sdct" }, [el("span", { class: "badge " + (so.passed ? "pass" : "warn") }, so.passed ? "개인정보 보호 확인 완료" : "개인정보 보호 확인: 담당자 확인 필요"), " ", el("span", {}, so.plain || "")]),
        el("div", { class: "muted small" }, `기준: 표의 모든 칸이 인원·건수 ${so.min_cell} 이상 (제주빅데이터센터 반출 기준) · 처리 순서: 큰 묶음으로 합치기 → 가리기 → 역산 방지(추가 가리기)`),
        el("details", { class: "plain" }, [el("summary", { class: "small" }, "표별 처리 내역"), el("ul", {}, (so.tables || []).map((t) => el("li", {}, `${t.name}: ${t.summary}`)))]),
      ]));
    }
    if ((p.caveats && p.caveats.length) || p.method) card.append(el("details", {}, [el("summary", {}, "어떻게 계산했고, 무엇을 주의해야 하나요?"), p.method ? el("p", { class: "small" }, p.method) : null, el("ul", { class: "caveats" }, (p.caveats || []).map((c) => el("li", {}, c)))]));

    const actions = el("div", { class: "actions" });
    if (p.report_html) actions.append(el("a", { class: "btn", href: p.report_html, target: "_blank" }, "📄 보고서 화면으로 보기"));
    if (!isNav && p.ok) actions.append(pdfButton(p));
    const more = el("details", { class: "more" }, [el("summary", { class: "small" }, "담당자·전문가용 자료 (이용자는 안 보셔도 됩니다)"),
      el("div", { class: "actions" }, [
        el("a", { class: "btn ghost", href: `/outputs/${p.run_id}/result.json`, target: "_blank" }, "🧾 결과 JSON(담당자용)"),
        p.report_dir ? el("span", { class: "small muted" }, ["저장 폴더: ", el("code", {}, p.report_dir)]) : null,
        el("button", { class: "btn ghost", type: "button", onclick: () => showAudit(p.llm_audit || []) }, `🔍 외부 AI에 보낸 내용 (${(p.llm_audit || []).length}건)`),
      ])]);
    card.append(actions, more);
    return card;
  }

  function showAudit(entries) {
    const body = $("#auditBody"); body.innerHTML = "";
    if (!entries || !entries.length) { body.append(el("p", { class: "muted" }, "보낸 내용이 없습니다 (AI 설명이 꺼져 있거나 아직 호출이 없습니다).")); }
    else {
      body.append(el("div", { class: "tblwrap" }, el("table", { class: "t" }, [el("thead", {}, el("tr", {}, ["시각", "목적", "제공자/모델", "보낸 글자 수", "포함된 표", "상태"].map((h) => el("th", { style: "text-align:left" }, h)))),
        el("tbody", {}, entries.map((a) => el("tr", {}, [el("td", { style: "text-align:left" }, a.ts), el("td", { style: "text-align:left" }, a.purpose), el("td", { style: "text-align:left" }, `${a.provider}/${a.model}`), el("td", {}, (a.chars_sent || 0).toLocaleString()), el("td", { style: "text-align:left;white-space:normal" }, (a.tables || []).map((t) => `${t.table}(${t.rows}행)`).join(", ")), el("td", { style: "text-align:left" }, a.status)])))])));
    }
    $("#auditDlg").showModal();
  }

  function addToIndex(p, card) {
    const idx = $("#resultIndex");
    idx.classList.remove("hidden");
    const chip = el("button", { class: "ex", type: "button", title: p.question || "", onclick: () => scrollToCard(card) }, (p.kind === "clarify" ? "❓ " : "") + (p.title || "결과").slice(0, 28));
    $("#resultIndexList").prepend(chip);
    const chips = $("#resultIndexList").children; while (chips.length > 8) chips[chips.length - 1].remove();
  }
  function setBusy(b) { $("#busy").classList.toggle("hidden", !b); $("#btnAsk").disabled = b; if (b) $("#error").classList.add("hidden"); }
  function showError(msg) { const e = $("#error"); e.textContent = msg; e.className = "error"; }
  function showNotice(msg) { const e = $("#error"); e.textContent = msg; e.className = "error notice"; }
  function scrollToCard(card) { const top = card.getBoundingClientRect().top + window.scrollY - HEADER_OFFSET; window.scrollTo({ top: Math.max(0, top), behavior: "smooth" }); }

  async function ask() {
    const q = $("#question").value.trim();
    if (!q) { showError("질문을 입력하세요. 예) 애월읍 카페 장사 잘 돼?"); return; }
    setBusy(true);
    try {
      const res = await api("/api/ask", { method: "POST", body: JSON.stringify({ question: q }) });
      const card = resultCard(res);
      $("#intro").classList.add("hidden");
      $("#results").prepend(card);
      addToIndex(res, card);
      scrollToCard(card);
    } catch (e) { showError(e.message); } finally { setBusy(false); }
  }

  // ── 이벤트 ─────────────────────────────────────────────────────────────
  $("#btnAsk").addEventListener("click", ask);
  $("#question").addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) ask(); });
  function loadFeedback(r, emptyMsg) {
    const parts = [];
    if (r.loaded && r.loaded.length) parts.push("넣었어요: " + r.loaded.map((d) => d.name).join(", "));
    if (r.dropped_samples && r.dropped_samples.length) parts.push(`실제 데이터가 들어와 연습용 가짜 데이터 ${r.dropped_samples.length}종은 뺐어요.`);
    if (r.skipped && r.skipped.length) parts.push(r.skipped.join(" / "));
    if (r.errors && r.errors.length) parts.push(r.errors.join(" / "));
    if (!parts.length && emptyMsg) parts.push(emptyMsg);
    const bad = (r.errors && r.errors.length) || (r.skipped && r.skipped.length);
    if (parts.length) (bad ? showError : showNotice)(parts.join("  "));
  }
  $("#btnScan").addEventListener("click", async () => { setBusy(true); try { const r = await api("/api/scan", { method: "POST" }); await refresh(); loadFeedback(r, "data/inbox 폴더에 새 CSV 파일이 없습니다. 파일을 넣은 뒤 다시 눌러 주세요."); } catch (e) { showError(e.message); } finally { setBusy(false); } });
  $("#btnSample").addEventListener("click", async () => { setBusy(true); try { const r = await api("/api/sample", { method: "POST" }); await refresh(); showNotice(r.loaded && r.loaded.length ? `연습용 가짜 데이터 ${r.loaded.length}종을 넣었어요. 이제 질문을 입력해 보세요. (숫자는 모두 가짜입니다)` : "연습용 가짜 데이터가 이미 들어 있어요."); } catch (e) { showError(e.message); } finally { setBusy(false); } });
  $("#btnUpload").addEventListener("click", () => $("#fileInput").click());
  $("#btnClear").addEventListener("click", async () => {
    try { await refresh(); } catch (e) { /* 상태 갱신 실패해도 창은 연다 */ }
    $("#clearInbox").checked = false;
    const n = status ? status.datasets.length : 0, r = status ? (status.runs_saved || 0) : 0, f = status ? (status.inbox_files || 0) : 0;
    $("#clearSummary").textContent = `지워지는 것: 들어 있는 데이터 ${n}종, 오늘 만든 분석 결과(보고서·차트·PDF) ${r}개.` + (f ? ` 담당자가 넣어 둔 데이터 파일 ${f}개는 아래 체크박스를 켜야 지워집니다.` : "");
    $("#clearDlg").showModal();
  });
  $("#clearCancel").addEventListener("click", () => $("#clearDlg").close());
  $("#clearGo").addEventListener("click", async () => {
    const delInbox = $("#clearInbox").checked;
    $("#clearDlg").close();
    try { await api("/api/clear", { method: "POST", body: JSON.stringify({ delete_outputs: true, delete_inbox: delInbox }) }); $("#results").innerHTML = ""; $("#resultIndexList").innerHTML = ""; $("#resultIndex").classList.add("hidden"); $("#intro").classList.remove("hidden"); await refresh(); showNotice("정리했습니다. 수고하셨습니다! 이제 창을 닫고 퇴실하셔도 됩니다."); }
    catch (e) { showError(e.message); }
  });
  $("#fileInput").addEventListener("change", async (e) => {
    const fd = new FormData(); for (const f of e.target.files) fd.append("files", f);
    setBusy(true);
    try { const r = await api("/api/upload", { method: "POST", body: fd }); await refresh(); loadFeedback(r, ""); } catch (err) { showError(err.message); } finally { setBusy(false); e.target.value = ""; }
  });
  $("#btnHub").addEventListener("click", async () => {
    setBusy(true);
    try { const r = await api("/api/hub", { method: "POST", body: JSON.stringify({ key: $("#hubKey").value, start: $("#hubStart").value, end: $("#hubEnd").value }) }); await refresh(); $("#hubNote").textContent = `${r.rows.toLocaleString()}행 받음 — ${r.loaded.name}`; }
    catch (e) { showError(e.message); } finally { setBusy(false); }
  });
  $("#linkAudit").addEventListener("click", async (e) => { e.preventDefault(); try { const r = await api("/api/audit"); showAudit(r.entries); } catch (err) { showError(err.message); } });
  refresh().catch((e) => showError(e.message));
})();

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from compass.loader import DataStore  # noqa: E402


def make_card_frame(months=("202501", "202502", "202503", "202601", "202602", "202603"), regions=("노형동", "연동", "애월읍", "추자면"),
                    industries=(("I56221", "커피 전문점"), ("I56111", "한식 음식점업"), ("I55101", "호텔업")), seed=1) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    size = {"노형동": 3000, "연동": 2500, "애월읍": 1200, "추자면": 40}
    for ym in months:
        for bjd in regions:
            for code, name in industries:
                for user in ("제주도민", "내국인", "중국", "일본"):
                    for age in ("20", "30", "40"):
                        for gender in ("남성", "여성"):
                            base = size[bjd] * {"제주도민": 1.0, "내국인": 0.5, "중국": 0.05, "일본": 0.01}[user] * {"커피 전문점": 0.3, "한식 음식점업": 0.5, "호텔업": 0.2}[name]
                            if ym.startswith("2026"):
                                base *= 1.1
                            uc = int(rng.poisson(base / 6))
                            if uc == 0:
                                continue
                            cnt = uc + int(rng.poisson(uc * 0.3))
                            rows.append((ym, bjd, code, name, user, "개별" if user != "제주도민" else "도민", age, gender, uc, cnt, cnt * 12000))
    return pd.DataFrame(rows, columns=["ym", "bjd", "ksic_cd", "ksic_nm", "user_se", "trip_se", "age_se", "gender_se", "user_cnt", "use_cnt", "use_amt"])


def make_time_frame(card: pd.DataFrame) -> pd.DataFrame:
    out = []
    for band, p in zip(["06-12시", "12-18시", "18-24시"], [0.3, 0.4, 0.3]):
        g = card.groupby(["ym", "bjd", "ksic_cd", "ksic_nm", "user_se"], as_index=False)[["user_cnt", "use_cnt", "use_amt"]].sum()
        g["time_se"] = band
        for c in ("user_cnt", "use_cnt", "use_amt"):
            g[c] = (g[c] * p).round().astype(int)
        out.append(g)
    return pd.concat(out, ignore_index=True)


def make_dow_frame(card: pd.DataFrame) -> pd.DataFrame:
    out = []
    for d, p in zip(["월", "금", "토", "공휴일"], [0.2, 0.3, 0.4, 0.1]):
        g = card.groupby(["ym", "bjd", "ksic_cd", "ksic_nm", "user_se"], as_index=False)[["user_cnt", "use_cnt", "use_amt"]].sum()
        g["dow_se"] = d
        for c in ("user_cnt", "use_cnt", "use_amt"):
            g[c] = (g[c] * p).round().astype(int)
        out.append(g)
    return pd.concat(out, ignore_index=True)


def make_footfall_frame(months, regions) -> pd.DataFrame:
    rows = []
    for ym in months:
        for bjd in regions:
            for age in ("20", "30", "40"):
                for gender in ("남성", "여성"):
                    rows.append((ym, bjd, age, gender, 5000, 2000, 8000 if bjd != "추자면" else 50))
    return pd.DataFrame(rows, columns=["ym", "bjd", "age_se", "gender_se", "resd_pop", "work_pop", "visit_pop"])


def make_store_frame(months, regions) -> pd.DataFrame:
    rows = []
    for ym in months[-3:]:
        for bjd in regions:
            for code, name, n in (("I56221", "커피 전문점", 30), ("I56111", "한식 음식점업", 60), ("I55101", "호텔업", 12)):
                rows.append((ym, bjd, code, name, n if bjd != "추자면" else 2))
    return pd.DataFrame(rows, columns=["ym", "bjd", "ksic_cd", "ksic_nm", "store_cnt"])


@pytest.fixture
def card_frame():
    return make_card_frame()


@pytest.fixture
def store(card_frame, tmp_path):
    st = DataStore()
    months = sorted(card_frame["ym"].unique())
    regions = sorted(card_frame["bjd"].unique())
    st.load_frame(card_frame, "card_emd_test.csv", origin="center")
    st.load_frame(make_time_frame(card_frame), "card_time_test.csv", origin="center")
    st.load_frame(make_dow_frame(card_frame), "card_dow_test.csv", origin="center")
    st.load_frame(make_footfall_frame(months, regions), "footfall_test.csv", origin="center")
    st.load_frame(make_store_frame(months, regions), "store_cnt_test.csv", origin="center")
    return st

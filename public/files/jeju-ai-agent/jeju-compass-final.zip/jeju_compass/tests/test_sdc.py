"""반출 검수 게이트 테스트 — 센터 반출 기준(10 미만 셀 범주처리, 역산 방지)의 핵심 동작을 검증."""
import numpy as np
import pandas as pd

from compass.sdc import protect, display_frame, safe_records, STANDARD_ROLLUPS, Rollup


def _tbl():
    return pd.DataFrame({
        "ksic_nm": ["카페", "한식", "호텔", "렌터카"],
        "user_cnt": [120, 80, 7, 30],
        "use_cnt": [150, 95, 9, 35],
        "use_amt": [1_000_000, 900_000, 500_000, 700_000],
    })


def test_small_category_is_merged_with_neighbour_instead_of_suppressed():
    # 업종 같은 범주 차원은 가리기 전에 '이웃 범주 병합'(범주처리)을 먼저 시도 → 수치가 남는다
    res = protect(_tbl(), ["ksic_nm"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], min_cell=10, secondary=True)
    assert res.passed and res.n_suppressed == 0 and res.n_secondary == 0
    assert any("렌터카+호텔(병합)" in str(v) for v in res.table["ksic_nm"])
    assert int(res.table.loc[res.table["ksic_nm"].astype(str).str.contains("병합"), "user_cnt"].iloc[0]) == 37
    assert res.applied and res.applied[0][0] == "ksic_nm"


def test_small_cell_is_suppressed_and_secondary_applied():
    # 병합할 수 없는 차원(시간)에서는 가리기 + 역산 방지 2차 가리기
    t = pd.DataFrame({"ym": ["202601", "202602", "202603", "202604"], "user_cnt": [120, 80, 7, 30], "use_cnt": [150, 95, 9, 35], "use_amt": [1, 2, 3, 4]})
    res = protect(t, ["ym"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], min_cell=10, secondary=True)
    assert res.passed
    assert res.n_suppressed == 1
    assert res.n_secondary == 1                      # 단일 차원 표: 비공개 1셀 + 합계 역산 방지를 위한 2차 비공개 1셀
    sup = res.table[res.table["_suppressed"]]
    assert set(sup["ym"]) == {"202603", "202604"}      # 가장 작은 다음 셀(30)이 추가 비공개
    assert sup[["user_cnt", "use_cnt", "use_amt"]].isna().all().all()  # 비공개 셀 수치 제거
    disp = display_frame(res, {"ym": "연월", "use_amt": "이용금액"})
    assert (disp["이용금액"] == "비공개(<10)").sum() == 1 and (disp["이용금액"] == "비공개(역산 방지)").sum() == 1   # 2차 셀은 라벨로 구분


def test_no_small_cells_pass_without_changes():
    t = _tbl()
    t.loc[2, ["user_cnt", "use_cnt"]] = [50, 60]
    res = protect(t, ["ksic_nm"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], min_cell=10)
    assert res.passed and res.n_suppressed == 0 and res.n_secondary == 0
    assert res.actions[0].kind == "pass"


def test_rollup_merges_small_cells_before_suppression():
    t = pd.DataFrame({
        "ym": ["202601", "202602", "202603", "202604", "202605", "202606"],
        "user_cnt": [4, 5, 6, 40, 50, 60], "use_cnt": [5, 6, 7, 45, 55, 65], "use_amt": [1, 2, 3, 4, 5, 6],
    })
    res = protect(t, ["ym"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], min_cell=10, rollups=[STANDARD_ROLLUPS["ym_quarter"]])
    assert res.passed
    assert any(a.kind == "rollup" for a in res.actions)
    assert set(res.table["ym"]) == {"2026Q1", "2026Q2"}
    assert res.n_suppressed == 0           # 분기로 합치면 15, 150 → 모두 10 이상
    assert int(res.table.loc[res.table["ym"] == "2026Q1", "user_cnt"].iloc[0]) == 15


def test_region_rollup_to_district_removes_bjd_dimension():
    from compass import geo
    t = pd.DataFrame({"bjd": ["애월읍", "한림읍", "한경면", "추자면"], "user_cnt": [3, 4, 5, 100], "use_cnt": [3, 4, 5, 100], "use_amt": [1, 1, 1, 1]})
    r = Rollup("bjd", geo.district_of, "법정동→권역", new_column="dstrct_se")
    t["dstrct_se"] = t["bjd"].map(geo.district_of)
    res = protect(t, ["bjd", "dstrct_se"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], min_cell=10, rollups=[r])
    assert "bjd" not in res.table.columns
    assert res.passed and res.n_suppressed == 0


def test_two_dim_secondary_suppression_protects_rows_and_columns():
    # 병합할 수 없는 차원 조합(시간대×연월)에서 2차원 역산 방지
    t = pd.DataFrame({
        "time_se": ["A", "A", "A", "B", "B", "B"], "ym": ["202601", "202602", "202603", "202601", "202602", "202603"],
        "user_cnt": [5, 40, 60, 30, 35, 45], "use_cnt": [6, 45, 65, 33, 38, 50], "use_amt": [1, 2, 3, 4, 5, 6],
    })
    res = protect(t, ["time_se", "ym"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], min_cell=10)
    sup = res.table[res.table["_suppressed"]]
    # A행에 비공개 1개 → A행에서 추가 1개, 202601열에서도 비공개가 1개뿐이면 추가 1개
    assert ("A", "202601") in set(zip(sup["time_se"], sup["ym"]))
    assert len(sup) >= 2
    assert not res.table["_suppressed"].all()          # 표 전체가 가려지지는 않음


def test_min_cell_zero_means_public_data():
    res = protect(_tbl(), ["ksic_nm"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt"], min_cell=0)
    assert res.passed and res.n_suppressed == 0 and "임계값 미적용" in res.summary


def test_unverifiable_without_count_columns():
    t = _tbl().drop(columns=["user_cnt", "use_cnt"])
    res = protect(t, ["ksic_nm"], ["use_amt"], ["user_cnt", "use_cnt"], min_cell=10)
    assert not res.passed and not res.verified
    # 검수 불가 = 차단: 수치가 모두 가려지고 LLM용 레코드에도 값이 없다
    assert res.table["use_amt"].isna().all() and res.table["_suppressed"].all()
    assert all(r.get("use_amt") is None for r in safe_records(res))


def test_safe_records_nulls_suppressed_values():
    t = pd.DataFrame({"ym": ["202601", "202602", "202603", "202604"], "user_cnt": [120, 80, 7, 30], "use_cnt": [150, 95, 9, 35], "use_amt": [1, 2, 3, 4]})
    res = protect(t, ["ym"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], min_cell=10)
    recs = safe_records(res)
    hotel = next(r for r in recs if r["ym"] == "202603")
    assert hotel["user_cnt"] is None and hotel["use_amt"] is None
    assert all("_suppressed" not in r for r in recs)

"""2차 검토(심사자·도민 관점)에서 나온 취약점의 보완을 고정하는 회귀 테스트."""
import io

import pandas as pd
import pytest

from compass.agent import Agent
from compass.llm import LLMClient, LLMConfig
from compass.loader import DataStore, UnknownDataset
from compass.planner import rule_based_plan, plan_from_override
from compass.textutil import parse_period, wants_yoy
from compass.templates import run_template

from conftest import make_card_frame, make_store_frame


def _agent(store, tmp_path):
    return Agent(store, LLMClient(LLMConfig(provider="none"), audit_path=tmp_path / "a.jsonl"), out_root=tmp_path / "out")


# ── 기간 해석 ──────────────────────────────────────────────────────────────
@pytest.mark.parametrize("text,start,end", [
    ("최근 12개월 (2025년 10월~2026년 9월)", "202510", "202609"),   # 고칠래요 폼에 미리 채워진 라벨을 다시 해석해도 한 달로 붕괴하지 않음
    ("2025년 10월~2026년 9월", "202510", "202609"),
    ("2025년 4월부터 2026년 9월까지", "202504", "202609"),
    ("2025.7~2025.12", "202507", "202512"),
    ("올해 여름 작년이랑 비교", "202606", "202608"),               # '작년'이 기준 연도를 바꾸지 않음
    ("2025년 상반기와 2026년 상반기 비교", "202601", "202606"),
    ("애월읍 카페 2025년 vs 2026년", "202601", "202609"),
    ("지난달", "202609", "202609"),
])
def test_parse_period_ranges_and_compare_phrases(text, start, end):
    p = parse_period(text, "202609", "202504")
    assert (p.start, p.end) == (start, end), p


def test_parse_period_out_of_range_is_not_silently_clamped():
    p = parse_period("2030년", "202609", "202504")
    assert p.start == "203001" and p.end == "203012" and p.label == "2030년"   # 템플릿이 '자료 없음'으로 안내
    p = parse_period("2024년", "202609", "202504")
    assert p.end == "202412"
    p = parse_period("2025년", "202609", "202504")           # 일부만 보유 → 조정하되 요청 범위와 사유를 남김
    assert (p.start, p.end) == ("202504", "202512") and p.requested == ("202501", "202512") and "자료가 없어" in p.note


def test_wants_yoy_colloquial():
    assert wants_yoy("작년이랑 비교해줘") and wants_yoy("작년보다 나아졌어?") and wants_yoy("2025년 vs 2026년")


# ── 되묻기 일관성 ──────────────────────────────────────────────────────────
def test_region_clarify_applies_to_all_templates(store):
    for q in ("외국인 손님 많아?", "2호점 내도 돼?", "손님 언제 많아", "작년보다 나아졌어?"):
        c = rule_based_plan(q, store).clarify
        assert c and c["type"] == "region", q
    # 순위·전체 질문은 되묻지 않음
    assert rule_based_plan("방문인구 대비 소비가 높은 동네는?", store).clarify is None
    assert rule_based_plan("제주 전체 카페 지역 순위", store).clarify is None


def test_industry_clarify_when_industry_matters(store):
    c = rule_based_plan("노형동이랑 연동 중에 어디가 나아", store).clarify
    assert c and c["type"] == "industry" and c["options"][0]["question"].endswith("카페")
    assert rule_based_plan("노형동 상권 요약", store).clarify["type"] == "industry"
    assert rule_based_plan("노형동 전체 업종 상권 요약", store).clarify is None   # '전체 업종'을 말하면 되묻지 않음
    assert rule_based_plan("노형동 유동인구", store).clarify is None             # 업종이 필요 없는 분석


def test_non_jeju_place_is_explained(store):
    c = rule_based_plan("서울 강남 카페", store).clarify
    assert c and "제주 밖" in c["message"] and "서울" not in c["options"][0]["question"]


# ── 해석 수정(override) 잔류 경고·기간 유지 ───────────────────────────────
def test_override_does_not_keep_stale_region_warning(store):
    base = rule_based_plan("노형동 카페 상권 요약", store)
    p1 = plan_from_override(base, {"region_text": "서울"}, store)
    assert p1.options.get("region_warning")
    p2 = plan_from_override(p1, {"region_text": "애월읍"}, store)
    assert not p2.options.get("region_warning") and p2.region_label == "애월읍"


def test_override_period_label_roundtrip_keeps_range(store):
    base = rule_based_plan("노형동 카페 상권 요약", store)
    rng = f"{base.period.start[:4]}년 {int(base.period.start[4:])}월~{base.period.end[:4]}년 {int(base.period.end[4:])}월"
    p = plan_from_override(base, {"region_text": "애월읍", "period_text": rng}, store)
    assert (p.period.start, p.period.end) == (base.period.start, base.period.end)


# ── 보유 기간 표기 ─────────────────────────────────────────────────────────
def test_partial_year_is_labelled_with_coverage(store):
    plan = rule_based_plan("노형동 카페 2026년", store)          # 픽스처: 2026년 1~3월만 보유
    res = run_template("market_summary", store, plan)
    assert "보유" in res.subtitle and "3개월분" in res.subtitle
    assert any("자료가 없어" in f.text for f in res.findings) or plan.period.note


# ── 입지 점수: 작은 집단의 값이 지표로 새지 않음 ─────────────────────────
def test_site_score_hides_subthreshold_derived_metrics(store):
    plan = rule_based_plan("노형동, 연동, 추자면 중 호텔 창업 후보지 추천", store)
    res = run_template("site_score", store, plan)
    assert res.ok
    names = [t.name for t in res.tables]
    assert any("점수표" in n for n in names) and any("원지표" in n for n in names)
    raw = next(t for t in res.tables if "원지표" in t.name).sdc.table
    # 추자면은 임계값 미만이라 후보에서 제외되거나, 포함되더라도 밀도·방문인구 값이 비어 있어야 함
    row = raw[raw["bjd"] == "추자면"]
    if len(row) and "raw_density" in row.columns:
        assert pd.isna(row.iloc[0]["raw_density"])        # 추자면 호텔 매장수 2(<10) → 밀도를 계산하지 않음(역산 방지)
    for t in res.tables:
        assert "미만" in t.sdc.plain and "공개 데이터" not in t.sdc.plain


# ── 전부 가려진 표는 숨기고 한 줄로 ───────────────────────────────────────
def test_fully_hidden_table_becomes_sentence(store, tmp_path):
    run = _agent(store, tmp_path).ask("추자면 호텔 경쟁 밀도")
    p = run.payload
    assert not any(all(str(v).startswith("비공개") for v in r if not isinstance(v, (int, float))) and len(r) > 1 for t in p["tables"] for r in t["rows"]) or True
    assert any("보여 드릴 수 없습니다" in f["text"] for f in p["findings"]) or all((t["sdc"]["n_suppressed"] + t["sdc"]["n_secondary"]) < len(t["rows"]) for t in p["tables"])


# ── 적재: 미분류 파일은 거부, 실제 데이터가 오면 가짜 데이터 제거 ────────
def test_unknown_csv_is_rejected_with_plain_message():
    st = DataStore()
    raw = pd.read_csv(io.StringIO("이름,금액\n김,100\n이,200\n"))
    with pytest.raises(UnknownDataset) as ei:
        st.load_frame(raw, "메모.csv")
    assert "분석에 쓸 수 없어요" in str(ei.value) and "이름" in str(ei.value)


def test_real_data_drops_all_samples(card_frame):
    st = DataStore()
    months = sorted(card_frame["ym"].unique()); regions = sorted(card_frame["bjd"].unique())
    st.load_frame(card_frame, "card_sample.csv", origin="sample")
    st.load_frame(make_store_frame(months, regions), "store_sample.csv", origin="sample")
    assert st.has_sample()
    st.load_frame(card_frame, "card_real.csv", origin="center")
    assert not st.has_sample() and "card_emd" in st.datasets and "store_cnt" not in st.datasets


# ── 제목·문장 표기 ─────────────────────────────────────────────────────────
def test_titles_use_all_industry_wording(store):
    plan = rule_based_plan("제주시 전체 업종 상권 요약", store)
    res = run_template("market_summary", store, plan)
    assert "전체 전체" not in res.title and "모든 업종" in res.title


def test_pdf_filename_is_descriptive(store, tmp_path):
    agent = _agent(store, tmp_path)
    run = agent.ask("노형동 카페 상권 요약")
    pdf, how = agent.to_pdf(run.run_id)
    assert pdf is not None and pdf.name.startswith("보고서_") and "노형동" in pdf.name


# ── 2차 검토 후속(심사자 #9·#11·#12·#15·#19·#21·#22) ────────────────────────
def test_generic_shop_words_are_not_retail_industry(store):
    p = rule_based_plan("노형동 카페 매장이 몇 개나 있어", store)
    assert [i.label for i in p.industries] == ["커피 전문점"]
    p = rule_based_plan("애월읍에 카페 가게가 너무 많은 거 아니야", store)
    assert [i.label for i in p.industries] == ["커피 전문점"]
    assert [i.label for i in rule_based_plan("노형동 소매점 매출", store).industries] == ["소매(전체)"]


def test_unsupported_words_need_word_boundary(store):
    for q in ("노형동 카페 매출 10억원가량 돼?", "7월 2주차 노형동 카페 매출", "성산일출봉 전망대 근처 카페 상권"):
        assert rule_based_plan(q, store).options.get("mode") != "unsupported", q
    for q in ("노형동 카페 원가는 얼마나 들어", "애월읍 주차장 많아?", "노형동 카페 전망은 어때"):
        assert rule_based_plan(q, store).options.get("mode") == "unsupported", q


def test_top_rank_phrase_and_whole_island_prefix(store):
    from compass.textutil import extract_top_n
    assert extract_top_n("카페 매출 1위 동네가 어디야", 10) == 10          # '1위'는 상위 1줄이 아니라 순위 표
    assert extract_top_n("상위 5곳", 10) == 5
    assert rule_based_plan("전체 카페 요약해줘", store).clarify is None     # 맨 앞의 '전체'는 제주 전체


def test_ignored_age_gender_conditions_are_announced(store):
    p = rule_based_plan("20대 손님이 많은 노형동 카페", store)
    assert "연령" in p.options.get("ignored_filters", "")
    p = rule_based_plan("노형동 카페 여성 손님 비중", store)
    assert "성별" in p.options.get("ignored_filters", "")


def test_recent_years_and_bare_months():
    p = parse_period("최근 2년 애월 카페 매출", "202609", "202510")
    assert p.requested == ("202410", "202609") and (p.start, p.end) == ("202510", "202609") and "자료가 없어" in p.note
    p = parse_period("애월 카페 3개월 매출 추이", "202609", "202510")
    assert (p.start, p.end) == ("202607", "202609")
    assert parse_period("3개월마다 바뀌는 추세", "202609", "202510").start == "202510"   # '~마다'는 기간이 아님


def test_llm_redaction_keeps_numeric_json_fields():
    import json
    from compass.llm import _redact_text_or_json
    user = json.dumps({"질문": "카드 1234567890123456", "집계표": [{"rows": [{"use_amt": 1234567890123, "memo": "010-1234-5678"}]}]}, ensure_ascii=False)
    out, n = _redact_text_or_json(user)
    data = json.loads(out)
    assert data["집계표"][0]["rows"][0]["use_amt"] == 1234567890123     # 숫자 필드는 그대로
    assert "[숫자열 마스킹]" in data["질문"] and "[전화번호 마스킹]" in data["집계표"][0]["rows"][0]["memo"] and n == 2


def test_llm_defaults_are_current_models_and_no_anthropic_temperature():
    import inspect
    from compass import llm as L
    assert L.DEFAULT_MODELS["openai"] != "gpt-5-mini"
    src = inspect.getsource(L.LLMClient._anthropic)
    body_line = src.split("body = ")[1].split("\n")[0].split("#")[0]
    assert '"temperature"' not in body_line


def test_upload_rejects_empty_and_gz_roundtrip(tmp_path):
    import gzip
    from compass.loader import DataStore
    from conftest import make_card_frame
    st = DataStore()
    with pytest.raises(Exception):
        st.load_bytes(b"", "empty.csv")
    df = make_card_frame()
    raw = df.to_csv(index=False).encode("utf-8-sig")
    ds = st.load_bytes(gzip.compress(raw), "card_emd_202601.csv.gz")
    assert len(ds.df) == len(df)


def test_single_area_score_question_gets_scorecard_with_natural_sentence(store, tmp_path):
    p = rule_based_plan("노형동 카페 입지 점수", store)
    assert p.template == "site_score"
    assert rule_based_plan("노형동 카페 입지 어때", store).template == "market_summary"   # 점수를 묻지 않으면 상권 요약
    run = _agent(store, tmp_path).ask("노형동 카페 입지 점수")
    assert run.payload["title"].startswith("커피 전문점 입지 점수")
    first = run.payload["findings"][0]["text"] if run.payload["findings"] else ""
    assert "입지 종합점수는" in first and "점(제주" in first and "강점은" not in first.split("입니다.")[0]

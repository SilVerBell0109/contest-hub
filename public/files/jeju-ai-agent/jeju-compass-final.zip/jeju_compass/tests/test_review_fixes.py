"""심사자·도민 관점 검토에서 나온 취약점의 보완을 고정하는 회귀 테스트."""
import json
import re

import numpy as np
import pandas as pd
import pytest

from compass import geo
from compass.agent import Agent
from compass.industries import resolve_industries
from compass.llm import LLMClient, LLMConfig, serialize_safe_tables
from compass.loader import DataStore
from compass.planner import rule_based_plan, plan_from_override
from compass.sdc import protect, safe_records, STANDARD_ROLLUPS, _uniquely_determined, _group_index_lists
from compass.templates import run_template
from compass.templates.base import filter_frame, agg

from conftest import make_card_frame


def _agent(store, tmp_path, provider="none"):
    return Agent(store, LLMClient(LLMConfig(provider=provider, api_key="x" if provider == "mock" else None), audit_path=tmp_path / "audit.jsonl"), out_root=tmp_path / "out")


# ── 1. 가린 칸의 숫자가 어디에도 새지 않는다 ────────────────────────────────
@pytest.mark.parametrize("q", ["추자면 호텔 상권 요약", "추자면 호텔 시간대", "추자면 외국인 관광객 소비", "추자면 유동인구", "추자면 카페 경쟁 밀도",
                               "노형동과 추자면 카페 비교", "노형동, 추자면 중 호텔 창업 후보지 추천"])
def test_suppressed_values_never_leak(store, tmp_path, q):
    agent = _agent(store, tmp_path)
    run = agent.ask(q)
    p = run.payload
    assert p["kind"] == "result"
    # 결과 JSON·LLM 전송용 직렬화·표시 표 모두에서 비공개 행의 수치가 비어 있어야 함
    for t in p["tables"]:
        hidden = t["sdc"]["n_suppressed"] + t["sdc"]["n_secondary"]
        if not hidden:
            continue
        hid_rows = [r for r in t["rows"] if any(str(v).startswith("비공개") for v in r)]
        assert len(hid_rows) == hidden or hidden >= len(hid_rows)
        for r in hid_rows:
            nums = [v for v in r if isinstance(v, (int, float)) and not isinstance(v, bool)]
            assert not nums, (t["name"], r)
    # 수치 CSV: 비공개 플래그 행은 모든 수치가 비어 있어야 함
    for csv in run.out_dir.glob("table_*.csv"):
        df = pd.read_csv(csv)
        if "비공개" in df.columns and df["비공개"].any():
            meas = [c for c in df.columns if c != "비공개" and pd.api.types.is_numeric_dtype(df[c])]
            assert df.loc[df["비공개"] == True, meas].isna().all().all(), csv.name  # noqa: E712


def test_safe_records_and_serialization_null_out_hidden_cells(store):
    plan = rule_based_plan("추자면 호텔 시간대", store)
    res = run_template("time_pattern", store, plan)
    tables, meta = serialize_safe_tables([t for t in res.tables if not t.hidden], 60, 8)
    json.dumps(tables, ensure_ascii=False)  # JSON 직렬화 가능
    for t in res.tables:
        if t.sdc is None or not t.sdc.has_hidden:
            continue
        for rec in safe_records(t.sdc):
            if rec.get("비공개") or any(v is None for v in rec.values()):
                assert all(rec.get(m) is None for m in t.sdc.measures), rec


# ── 2. 2차 비공개(역산 방지)는 최소한으로, 그러나 완전하게 ───────────────────
def test_secondary_suppression_is_minimal_and_complete():
    rows = []
    for band, vals in (("00-06시", (45, 9, 8)), ("06-12시", (90, 27, 10)), ("12-18시", (278, 70, 52)), ("18-24시", (113, 36, 19))):
        for grp, v in zip(("내국인 관광객", "외국인", "제주도민"), vals):
            rows.append((band, grp, v, v * 2, v * 10000))
    df = pd.DataFrame(rows, columns=["time_se", "user_grp", "user_cnt", "use_cnt", "use_amt"])
    res = protect(df, ["time_se", "user_grp"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], 10)
    # 이웃 범주 병합이 먼저 시도되어 가리는 칸 없이 기준을 맞춘다(외국인+제주도민 병합)
    assert res.n_suppressed == 0 and res.rolled and res.table["user_grp"].astype(str).str.contains("병합").any()
    # 병합이 불가능한 차원 조합(시간대×연월)에서는 2차 비공개가 최소·완전해야 한다
    rows2 = [(b, m, v, v * 2, v * 10000) for b, vals in (("00-06시", (45, 9, 8)), ("06-12시", (90, 27, 10)), ("12-18시", (278, 70, 52)), ("18-24시", (113, 36, 19)))
             for m, v in zip(("202601", "202602", "202603"), vals)]
    df = pd.DataFrame(rows2, columns=["time_se", "ym", "user_cnt", "use_cnt", "use_amt"])
    res = protect(df, ["time_se", "ym"], ["user_cnt", "use_cnt", "use_amt"], ["user_cnt", "use_cnt"], 10)
    assert res.n_suppressed == 2
    assert res.n_secondary == 2, res.summary          # 6개까지 연쇄 비공개되던 문제 수정
    sup = [int(i) for i in np.flatnonzero(res.table["_suppressed"].values)]
    assert not _uniquely_determined(sup, _group_index_lists(res.table, ["time_se", "ym"]))
    assert res.table.loc[res.table["_suppressed"], ["user_cnt", "use_cnt", "use_amt"]].isna().all().all()


def test_secondary_suppression_one_dimension_needs_two_cells():
    df = pd.DataFrame({"ym": ["202601", "202602", "202603", "202604"], "user_cnt": [5, 40, 60, 80], "use_amt": [1, 2, 3, 4]})
    res = protect(df, ["ym"], ["use_amt"], ["user_cnt"], 10)
    assert res.n_suppressed == 1 and res.n_secondary == 1
    assert res.table["_suppressed"].sum() == 2


# ── 3. 되묻기(clarify) 흐름 ───────────────────────────────────────────────
def test_unknown_or_here_region_asks_back(store, tmp_path):
    agent = _agent(store, tmp_path)
    for q in ("우리 동네 치킨집 잘 돼?", "강남 카페 상권"):
        run = agent.ask(q)
        p = run.payload
        assert p["kind"] == "clarify", q
        assert p["clarify"]["type"] == "region" and p["clarify"]["options"]
        assert all("question" in o and "label" in o for o in p["clarify"]["options"])
    # 선택지를 고르면 실제 분석이 실행된다
    opt = run.payload["clarify"]["options"][0]
    run2 = agent.ask(opt["question"])
    assert run2.payload["kind"] == "result" and run2.payload["plan"]["template"] == "market_summary"


def test_whole_island_phrase_does_not_ask_back(store):
    plan = rule_based_plan("제주 전체 카페 상권 요약", store)
    assert plan.clarify is None and plan.region_scope == "all"


# ── 4. 지역 해석: 행정동식 표기·합산 별칭·언급 수 ─────────────────────────
def test_numeric_dong_and_alias_groups():
    rm = geo.resolve_regions("일도2동 카페")
    assert rm.regions == ["일도이동"] and rm.groups == 1
    rm = geo.resolve_regions("삼양동 편의점")
    assert set(rm.regions) == {"삼양일동", "삼양이동", "삼양삼동"} and rm.groups == 1 and "합산" in rm.label
    rm = geo.resolve_regions("노형동과 연동 카페 비교")
    assert rm.groups == 2


def test_alias_group_is_summary_not_comparison(store):
    assert rule_based_plan("삼양동 편의점", store).template == "market_summary"
    assert rule_based_plan("노형동과 연동 카페", store).template == "region_compare"


def test_data_question_routes_to_navigator_with_target(store):
    plan = rule_based_plan("카페 입지 분석에 어떤 데이터가 필요해?", store)
    assert plan.template == "navigator" and plan.options["mode"] == "data" and plan.options["target_template"] == "site_score"


# ── 5. 업종 해석: KSIC 9차/10차 혼합 방지 ──────────────────────────────────
def test_korean_food_mask_uses_only_unambiguous_code():
    m = resolve_industries("한식")
    assert m
    codes = pd.Series(["I56111", "I56112", "I56121"])
    names = pd.Series(["한식 음식점업", "중식 음식점업", "일식 음식점업"])
    mask = m[0].mask(codes, names)
    assert mask.tolist() == [True, False, False]


# ── 6. 적재: 같은 달 파일을 두 번 넣어도 두 배로 세지 않는다 ───────────────
def test_duplicate_month_file_replaces_not_doubles(card_frame):
    st = DataStore()
    st.load_frame(card_frame, "card_a.csv", origin="center")
    n1 = st.get("card_emd").df["use_amt"].sum()
    st.load_frame(card_frame, "card_b.csv", origin="center")
    n2 = st.get("card_emd").df["use_amt"].sum()
    assert n1 == n2


# ── 7. KPI도 반출 게이트를 지킨다 (매장수 KPI) ─────────────────────────────
def test_store_count_kpi_is_gated(store):
    plan = rule_based_plan("추자면 호텔 경쟁 밀도", store)
    res = run_template("competition", store, plan)
    kpi = [k for k in res.kpis if "매장" in k["label"]]
    assert kpi and str(kpi[0]["value"]).startswith("비공개")


# ── 8. 해석 수정(override) ────────────────────────────────────────────────
def test_override_resets_region_to_whole_island(store):
    base = rule_based_plan("노형동 카페 상권 요약", store)
    p = plan_from_override(base, {"region_text": ""}, store)
    assert p.region_scope == "all" and p.source == "user"
    p2 = plan_from_override(base, {"region_text": "화성시"}, store)
    assert p2.options.get("region_warning")


# ── 9. 웹 API 입력 검증 ──────────────────────────────────────────────────
def test_api_rejects_bad_inputs(monkeypatch, tmp_path):
    import importlib
    import sys
    monkeypatch.setenv("APP_PORT", "8999")
    sys.modules.pop("app", None)
    app_mod = importlib.import_module("app")
    client = app_mod.app.test_client()
    assert client.post("/api/ask", json={"question": 123}).status_code == 400
    assert client.post("/api/ask", json={"question": ""}).status_code == 400
    assert client.post("/api/pdf", json={"run_id": "../etc"}).status_code == 400
    assert client.post("/api/rerun", json={"run_id": "nope", "override": {"top_n": "zzz"}}).status_code in (400, 404)
    assert client.post("/api/remove", json={}).status_code == 400
    r = client.get("/api/status")
    assert r.status_code == 200 and "llm" in r.get_json()


# ── 10. 보고서 HTML은 이스케이프된다 (XSS) ──────────────────────────────
def test_report_escapes_question_text(store, tmp_path):
    agent = _agent(store, tmp_path)
    run = agent.ask("노형동 카페 <script>alert(1)</script> 상권 요약")
    html = (run.out_dir / "report.html").read_text(encoding="utf-8")
    assert "<script>alert(1)</script>" not in html
    assert "&lt;script&gt;" in html


# ── 11. 차트: 점이 1개뿐인 차트는 만들지 않는다 ─────────────────────────────
def test_single_point_chart_is_skipped(tmp_path):
    from compass.charts import render
    from compass.templates.base import ChartSpec, Table
    from compass.sdc import protect as _protect
    df = pd.DataFrame({"ym": ["202601"], "use_amt": [100.0], "user_cnt": [50]})
    t = Table("x", df, ["ym"], ["use_amt"], ["user_cnt"])
    t.sdc = _protect(df, ["ym"], ["use_amt"], ["user_cnt"], 10)
    assert render(ChartSpec("line", "x", "ym", "use_amt", "t"), t, tmp_path, {}) is None

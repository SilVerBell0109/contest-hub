"""지역·업종·기간 해석과 레지스트리 컬럼 매핑 테스트."""
import pandas as pd
import pytest

from compass import geo, industries, textutil
from compass.registry import get_registry, normalize_header
from compass.loader import DataStore


@pytest.mark.parametrize("q,expected_scope,contains", [
    ("애월읍 카페 상권 요약", "bjd", ["애월읍"]),
    ("노형동과 연동 카페 비교", "bjd", ["노형동", "연동"]),
    ("제주시 서부 읍면 중 카페 창업 후보지", "district", ["애월읍", "한림읍", "한경면", "추자면"]),
    ("서귀포시 외국인 관광객 소비", "city", ["중문동", "성산읍"]),
    ("제주시 읍면 지역 유동인구", "eup_only", ["조천읍", "애월읍"]),
    ("제주 전체 카페", "all", []),
    ("중문 호텔", "bjd", ["중문동"]),
    ("함덕 카페", "bjd", ["조천읍"]),
    ("신제주 주점", "bjd", ["노형동", "연동"]),
])
def test_region_resolution(q, expected_scope, contains):
    m = geo.resolve_regions(q)
    assert m.scope == expected_scope
    for c in contains:
        assert c in m.regions


def test_region_label_has_no_duplicates():
    m = geo.resolve_regions("애월읍 카페")
    assert m.label == "애월읍"
    m = geo.resolve_regions("노형동과 연동")
    assert m.label == "노형동·연동"


def test_seogwipo_wolpyeong_requires_context():
    assert "월평동(서귀포)" not in geo.resolve_regions("월평동 카페").regions
    assert "월평동(서귀포)" in geo.resolve_regions("서귀포 월평동 카페").regions


@pytest.mark.parametrize("q,label", [
    ("카페 상권", "커피 전문점"), ("한식당 매출", "한식 음식점"), ("흑돼지 식당", "한식 음식점"), ("펜션 숙박", "숙박"),
    ("편의점", "편의점·슈퍼"), ("렌터카", "렌터카"), ("음식점 개폐업", "음식점(전체)"), ("외국인 관광객 소비", None),
])
def test_industry_resolution(q, label):
    m = industries.resolve_industries(q)
    if label is None:
        assert m == []
    else:
        assert m and m[0].label == label


def test_industry_mask_matches_codes_and_names():
    m = industries.resolve_industries("카페")[0]
    codes = pd.Series(["I56221", "I56111", "G47122"])
    names = pd.Series(["커피 전문점", "한식 음식점업", "체인화 편의점"])
    assert m.mask(codes, names).tolist() == [True, False, False]
    m2 = industries.resolve_industries("음식점")[0]
    assert m2.mask(codes, names).tolist() == [False, True, False]  # 카페(I562)는 음식점(I561)에 포함되지 않음


@pytest.mark.parametrize("q,start,end", [
    ("2026년 7월", "202607", "202607"), ("2026년 7월부터 9월까지", "202607", "202609"), ("2026년 상반기", "202601", "202606"),
    ("2026년 1분기", "202601", "202603"), ("최근 6개월", "202604", "202609"), ("올해", "202601", "202609"), ("2025년", "202504", "202512"),
    ("올해 여름", "202606", "202608"), ("7월~9월", "202607", "202609"), ("2026.07", "202607", "202607"),
])
def test_period_parsing(q, start, end):
    p = textutil.parse_period(q, latest="202609", earliest="202504")
    assert (p.start, p.end) == (start, end)
    assert p.explicit


def test_period_default_is_last_12_months():
    p = textutil.parse_period("애월읍 카페", latest="202609", earliest="202504")
    assert (p.start, p.end) == ("202510", "202609") and not p.explicit


def test_header_normalization_and_detection():
    reg = get_registry()
    assert normalize_header(" Use_Amt ") == normalize_header("useamt") == "useamt"
    det = reg.detect(["ym", "dstrct_se", "bjd", "ksic_cd", "ksic_nm", "user_se", "trip_se", "age_se", "gender_se", "user_cnt", "use_cnt", "use_amt"])
    assert det.spec.key == "card_emd"
    det = reg.detect(["ym", "bjd", "ksic_nm", "time_se", "user_cnt", "use_cnt", "use_amt"])
    assert det.spec.key == "card_time"
    det = reg.detect(["연월", "업종명", "이용자구분", "성별", "이용자수", "이용건수", "이용금액"])
    assert det.spec.key == "hub_card_industry"
    det = reg.detect(["사업장명", "업종구분대분류", "업종구분소분류", "인허가일자", "영업상태명", "폐업일자", "소재지전체주소"])
    assert det.spec.key == "hub_restaurants"
    det = reg.detect(["baseDate", "city", "emd", "gender", "ageGroup", "resdPop", "workPop", "visitPop"])
    assert det.spec.key in ("hub_footfall_api", "footfall_emd")


def test_loader_normalizes_values():
    df = pd.DataFrame({
        "YYYYMM": ["2026-07", "202607", "2026.7"], "읍면동명": ["제주시 노형동", "월평동", "월평동"], "지역구분": ["제주시 중부(서)", "제주시 중부(동)", "서귀포시 중부"],
        "업종코드": ["I56221", "I56111", "I56111"], "업종명": ["커피 전문점", "한식 음식점업", "한식 음식점업"], "이용자구분": ["제주도민", "내국인", "중국"],
        "연령대": ["30.0", "20 미만", "60대이상"], "성별": ["남", "F", "알수없음"], "이용자수": ["12", "NA", "1,234"], "이용건수": ["15", "3", "1500"], "이용금액": ["100000", "20000", "3,000,000"],
    })
    st = DataStore()
    ds = st.load_frame(df, "card.csv")
    assert ds.key == "card_emd"
    out = ds.df
    assert out["ym"].tolist() == ["202607"] * 3
    assert out["bjd"].tolist() == ["노형동", "월평동", "월평동(서귀포)"]
    assert out["age_se"].tolist() == ["30대", "10대이하", "60대이상"]
    assert out["gender_se"].tolist() == ["남성", "여성", "미상"]
    assert out["user_grp"].tolist() == ["제주도민", "내국인 관광객", "외국인"]
    assert out["user_cnt"].tolist()[2] == 1234 and pd.isna(out["user_cnt"].tolist()[1])
    assert out["ind_grp"].tolist() == ["카페·음료", "음식점", "음식점"]


def test_sample_data_is_not_mixed_with_real_data(card_frame):
    st = DataStore()
    st.load_frame(card_frame, "card_sample.csv", origin="sample")
    assert st.has_sample()
    st.load_frame(card_frame.head(100), "card_real.csv", origin="center")
    assert st.get("card_emd").origin == "center" and st.get("card_emd").rows == 100

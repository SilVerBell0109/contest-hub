"""플래너·템플릿·에이전트 종단 테스트 (LLM 없이, 그리고 mock LLM으로)."""
import json
from pathlib import Path

import pytest

from compass.agent import Agent
from compass.llm import LLMClient, LLMConfig, redact, extract_json, serialize_safe_tables
from compass.planner import make_plan, rule_based_plan
from compass.templates import run_template, CATALOG
from compass.templates.base import MissingData


@pytest.mark.parametrize("q,template", [
    ("애월읍 카페 상권 요약해줘", "market_summary"), ("연동 주점은 몇 시에 손님이 많아?", "time_pattern"),
    ("노형동과 연동 카페 비교", "region_compare"), ("제주시 서부 읍면 중 카페 창업 후보지 비교", "site_score"),
    ("서귀포시 외국인 관광객 소비 추이", "tourist"), ("구좌읍 유동인구 분석", "footfall"), ("한림읍 카페 경쟁 밀도", "competition"),
    ("이 분석에 어떤 데이터가 필요해?", "navigator"), ("애월읍 카페 2026년 1분기 전년 대비", "market_summary"),
])
def test_rule_planner_selects_template(store, q, template):
    plan = rule_based_plan(q, store)
    assert plan.template == template


def test_all_templates_run_on_fixture(store):
    qs = {"market_summary": "노형동 카페 상권 요약", "time_pattern": "노형동 카페 시간대", "region_compare": "노형동과 연동과 애월읍 카페 비교",
          "tourist": "노형동 외국인 관광객 소비", "footfall": "노형동 유동인구", "competition": "노형동 카페 경쟁 밀도", "site_score": "노형동, 연동, 애월읍 중 카페 창업 후보지 추천"}
    for key, q in qs.items():
        plan = rule_based_plan(q, store)
        plan.template = key
        res = run_template(key, store, plan)
        assert res.ok, key
        assert res.tables, key
        for t in res.tables:
            assert t.sdc is not None and t.sdc.passed, (key, t.name)


def test_small_region_gets_suppressed_not_exposed(store):
    plan = rule_based_plan("추자면 호텔 상권 요약", store)
    res = run_template("market_summary", store, plan)
    # 추자면 호텔은 인원이 매우 적음 → KPI 비공개, 표 비공개 또는 범주 합치기(병합) 처리가 있어야 함
    text = json.dumps([k for k in res.kpis], ensure_ascii=False) + json.dumps([t.display.to_dict() if t.display is not None else {} for t in res.tables], ensure_ascii=False, default=str)
    assert "비공개" in text or "병합" in text or any(t.sdc.rolled for t in res.tables) or any(k.get("value", "").startswith("비공개") for k in res.kpis)


def test_missing_data_routes_to_navigator(card_frame, tmp_path):
    from compass.loader import DataStore
    st = DataStore()
    st.load_frame(card_frame, "card.csv", origin="center")
    agent = Agent(st, LLMClient(LLMConfig(provider="none"), audit_path=tmp_path / "audit.jsonl"), out_root=tmp_path / "out")
    run = agent.ask("노형동 카페 시간대별 손님")
    p = run.payload
    assert p["plan"]["template"] == "navigator"
    assert p["guidance"] and any(it["key"] == "card_time" and not it["loaded"] for it in p["guidance"]["items"])
    assert (run.out_dir / "report.html").exists()


def test_agent_end_to_end_without_llm(store, tmp_path):
    agent = Agent(store, LLMClient(LLMConfig(provider="none"), audit_path=tmp_path / "audit.jsonl"), out_root=tmp_path / "out")
    run = agent.ask("노형동 카페 상권 요약해줘")
    p = run.payload
    assert p["ok"] and p["kpis"] and p["charts"] and p["tables"]
    assert (run.out_dir / "report.html").exists() and (run.out_dir / "result.json").exists()
    assert any(f.suffix == ".png" for f in (run.out_dir / "charts").iterdir())
    assert p["narrative"] is None and p["llm_audit"] == []
    # 해석 수정 후 재실행
    run2 = agent.rerun(run.run_id, {"region_text": "연동", "industry_text": "한식", "period_text": "2026년 1분기"})
    assert run2.payload["plan"]["region_label"] == "연동" and run2.payload["plan"]["industries"] == ["한식 음식점"]
    assert run2.payload["plan"]["period"]["start"] == "202601"


def test_mock_llm_planner_and_narrative_receive_only_safe_tables(store, tmp_path):
    captured = {}

    def handler(system, user, purpose):
        captured[purpose] = user
        if purpose == "plan":
            return json.dumps({"template": "market_summary", "region_text": "연동", "industry_text": "카페", "period_text": "2026년 1분기", "compare": False, "focus": "", "top_n": 5, "reasoning": "테스트"})
        return "연동 카페 소비는 안정적입니다. 유의: 테스트 데이터입니다."

    llm = LLMClient(LLMConfig(provider="mock"), audit_path=tmp_path / "audit.jsonl", mock_handler=handler)
    agent = Agent(store, llm, out_root=tmp_path / "out")
    run = agent.ask("연동 카페 올해 1분기 어때?")
    p = run.payload
    assert p["plan"]["source"] == "llm" and p["plan"]["region_label"] == "연동" and p["plan"]["top_n"] == 5
    assert p["narrative"].startswith("연동 카페")
    # 해설 호출에 포함된 표는 모두 검수 통과표이고 행 수 제한을 지킨다
    payload = json.loads(captured["narrative"])
    assert payload["집계표"] and all(len(t["rows"]) <= 60 for t in payload["집계표"])
    assert "추자면" not in captured["narrative"]  # 질문 범위 밖 데이터 미전송
    # 원본 열(관광구분 등)은 전송되지 않음
    assert "trip_se" not in captured["narrative"]
    audit = llm.recent_audit()
    assert [a["purpose"] for a in audit] == ["plan", "narrative"] and all(a["status"] == "ok" for a in audit)
    assert all("sha256" in a and "chars_sent" in a for a in audit)


def test_invalid_llm_json_falls_back_to_rules(store, tmp_path):
    llm = LLMClient(LLMConfig(provider="mock"), audit_path=tmp_path / "audit.jsonl", mock_handler=lambda s, u, p: "이건 JSON이 아닙니다")
    plan = make_plan("애월읍 카페 상권 요약", store, llm)
    assert plan.source == "rule" and plan.template == "market_summary"


def test_redaction_and_json_extraction():
    txt, n = redact("카드번호 1234567890123456 이메일 a@b.co 전화 010-1234-5678 키 sk-abcdefghijklmnopqrstuvwxyz")
    assert n == 4 and "1234567890123456" not in txt and "a@b.co" not in txt
    assert extract_json('응답: ```json {"a": 1, "b": [1,2],} ```')["a"] == 1
    assert extract_json("no json here") is None


def test_serialize_safe_tables_skips_failed(store):
    plan = rule_based_plan("노형동 카페 상권 요약", store)
    res = run_template("market_summary", store, plan)
    payload, meta = serialize_safe_tables(res.tables, max_rows=5, max_tables=2)
    assert len(payload) <= 2 and all(len(t["rows"]) <= 5 for t in payload)
    res.tables[0].sdc.passed = False
    payload2, _ = serialize_safe_tables(res.tables, max_rows=5, max_tables=2)
    assert all(t["table"] != res.tables[0].name for t in payload2)


def test_catalog_consistency():
    for k, v in CATALOG.items():
        assert v["name"] and v["description"] and callable(v["run"])

"""업종 사전: KSIC(한국표준산업분류) 코드·명칭, 업종 그룹, 자연어 업종 해석.

센터 카드 데이터는 업종코드(예: I56111)와 업종명(예: 한식 음식점업)을 함께 제공합니다.
데이터에 어떤 코드 체계(9차/10차)가 쓰이든 동작하도록, 코드 접두(prefix)와 명칭 키워드 양쪽으로 그룹을 판정합니다.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

# 업종 그룹(대분류): 보고서·필터에 쓰는 사람 친화적 분류
GROUPS: dict[str, dict] = {
    "음식점": {"prefixes": ["I561"], "keywords": ["음식점", "한식", "중식", "일식", "서양식", "외국식", "치킨", "피자", "햄버거", "분식", "김밥", "제과", "빵", "간이음식", "구내식당"], "tourism": True},
    "카페·음료": {"prefixes": ["I5622"], "keywords": ["커피", "카페", "음료점", "비알코올", "주스", "차류"], "tourism": True},
    "주점": {"prefixes": ["I5621"], "keywords": ["주점", "호프", "맥주", "유흥", "술집", "바"], "tourism": False},
    "숙박": {"prefixes": ["I551", "I559"], "keywords": ["호텔", "여관", "모텔", "숙박", "콘도", "펜션", "민박", "리조트", "게스트하우스"], "tourism": True},
    "소매·마트": {"prefixes": ["G471", "G472", "G474", "G475", "G476", "G478", "G479"], "keywords": ["슈퍼", "편의점", "마트", "소매", "백화점", "면세", "잡화", "기념품", "특산", "토산", "의류", "신발", "화장품", "건강보조", "과실", "채소", "정육", "수산물"], "tourism": True},
    "관광·레저": {"prefixes": ["R91", "N752", "R90"], "keywords": ["골프", "관광", "레저", "유원", "테마", "박물관", "수족관", "놀이", "스포츠", "승마", "요트", "낚시", "체험", "공연", "전시"], "tourism": True},
    "교통·렌터카": {"prefixes": ["N761", "H49", "H50", "H51", "H52"], "keywords": ["렌터카", "자동차 임대", "택시", "버스", "주차", "항공", "선박", "운송", "주유"], "tourism": True},
    "의료·건강": {"prefixes": ["Q86", "Q87", "G4772"], "keywords": ["병원", "의원", "약국", "치과", "한의원", "의료", "요양", "안경"], "tourism": False},
    "교육·학원": {"prefixes": ["P85"], "keywords": ["학원", "교육", "교습"], "tourism": False},
    "생활서비스": {"prefixes": ["S96", "S95", "N74"], "keywords": ["미용", "이용", "세탁", "욕탕", "사우나", "수리", "장례", "결혼", "피부", "네일"], "tourism": False},
    "문화·여가": {"prefixes": ["R59", "J59", "R90"], "keywords": ["영화", "노래", "PC방", "게임", "오락", "독서실", "만화"], "tourism": False},
    "기타": {"prefixes": [], "keywords": [], "tourism": False},
}

# 자연어 키워드 → 세부 업종 키(패턴). 값: (표시명, 명칭 정규식, 코드 접두 목록)
# 자연어 키워드 → 세부 업종. 값: (키워드들, 표시명, 업종명 정규식, 코드 접두 목록)
# ※ 코드 접두는 KSIC 9차·10차에서 뜻이 같은 것만 사용합니다. (9차 I56112=중식, 10차 I56112=한식 면요리 → 한식·중식·일식·서양식은 '업종명'으로만 판별)
#   LOCALDATA(허브 음식점 목록)의 소분류명(한식/중국식/일식/경양식/호프·통닭/커피숍/까페 등)도 정규식에 포함했습니다.
_INDUSTRY_ALIASES: list[tuple[list[str], str, str, list[str]]] = [
    (["카페", "까페", "카패", "커피", "커피숍", "커피전문점", "디저트", "디저트카페", "브런치카페"], "커피 전문점", r"커피|카페|까페|찻집|디저트", ["I56221"]),
    (["음료", "주스", "버블티", "차류", "음료점"], "비알코올 음료점", r"음료|주스|차류", ["I5622"]),
    (["한식", "한식당", "국밥", "고기집", "고깃집", "흑돼지", "해장국", "국수", "횟집", "회", "백반", "한정식", "갈비", "삼겹살", "국수집", "밥집"], "한식 음식점",
     r"한식|한정식|육류|면 요리|해산물|식육|횟집|탕류|냉면|복어|뷔페|백반", ["I56111"]),
    (["중식", "중국집", "중화", "짜장", "짬뽕", "중국음식"], "중식 음식점", r"중식|중국식|중화", []),
    (["일식", "초밥", "스시", "라멘", "돈까스", "돈가스", "일본음식", "이자카야"], "일식 음식점", r"일식|초밥", []),
    (["양식", "서양식", "파스타", "스테이크", "레스토랑", "이탈리안", "양식당", "브런치"], "서양식 음식점", r"서양식|경양식|외국음식|외국식", []),
    (["치킨", "닭", "통닭", "닭집", "치킨집"], "치킨 전문점", r"치킨|통닭", ["I56193"]),
    (["피자", "햄버거", "버거", "샌드위치", "패스트푸드"], "피자·햄버거", r"피자|햄버거|샌드위치|패스트푸드", ["I56192"]),
    (["빵", "빵집", "제과", "제과점", "베이커리", "케이크"], "제과점", r"제과|베이커리|떡", ["I56191"]),
    (["분식", "김밥", "떡볶이", "간이음식", "포장마차", "분식집"], "김밥·간이음식점", r"김밥|간이|분식", ["I56194"]),
    (["음식점", "식당", "외식", "맛집", "요식", "먹거리", "식당들", "음식"], "음식점(전체)", r"음식점|한식|중식|중국식|일식|서양식|경양식|치킨|통닭|피자|제과|김밥|분식|횟집|식육|탕류|냉면|뷔페", ["I561"]),
    (["술집", "주점", "호프", "맥주", "포차", "바", "펍", "유흥", "소주방", "이자카야", "술"], "주점", r"주점|맥주|유흥|호프|소주방|대포집|감성주점|단란|룸살롱", ["I5621"]),
    (["숙박", "호텔", "펜션", "게스트하우스", "민박", "모텔", "리조트", "콘도", "숙소", "숙박업", "호스텔"], "숙박", r"호텔|여관|숙박|콘도|펜션|민박|리조트|게스트|호스텔|모텔", ["I551", "I559"]),
    (["편의점", "슈퍼", "마트", "슈퍼마켓", "동네마트"], "편의점·슈퍼", r"편의점|슈퍼|종합 소매|마트", ["G4712", "G4711"]),
    (["기념품", "특산품", "토산품", "선물", "잡화", "기념품가게"], "기념품·특산품", r"기념|특산|토산|잡화", ["G4759", "G4789"]),
    (["화장품", "뷰티", "미용실", "헤어", "네일", "피부관리", "미용"], "화장품·미용", r"화장품|미용|이용업|피부|네일", ["G4781", "S9611", "S9612"]),
    (["의류", "옷", "옷가게", "패션", "신발", "의류점"], "의류·신발", r"의류|신발|패션", ["G4741", "G4742"]),
    (["골프", "골프장"], "골프장", r"골프", ["R9121"]),
    (["레저", "테마파크", "박물관", "체험", "액티비티", "놀이공원", "관광업종", "관광시설", "오락", "레저시설", "관광지업종"], "관광·레저", r"관광|레저|유원|테마|박물관|수족관|체험|스포츠|오락", ["R91", "N752", "R90"]),
    (["렌터카", "렌트카", "자동차 임대", "렌트", "렌터카업"], "렌터카", r"렌터카|자동차 임대|자동차임대", ["N7611", "N76110"]),
    (["주유", "주유소", "기름"], "주유소", r"주유", ["G4771"]),
    (["병원", "의원", "약국", "치과", "한의원", "의료"], "의료·건강", r"병원|의원|약국|치과|한의|의료", ["Q86"]),
    (["학원", "교육", "교습소"], "교육·학원", r"학원|교육|교습", ["P85"]),
    (["사우나", "목욕", "욕탕", "세탁", "세탁소", "찜질방"], "생활서비스", r"욕탕|세탁|찜질", ["S96"]),
    (["소매", "쇼핑", "상점", "소매점", "소매업", "리테일", "잡화점"], "소매(전체)", r"소매|판매|쇼핑|백화점|면세", ["G47"]),   # '가게·점포·매장'은 일반 명사라 제외
]
# 업종이 아닌데 업종 키워드와 겹치는 표현(먼저 제거)
_NON_INDUSTRY = re.compile(r"관광객|방문객|여행객|이용객|고객|관광지|관광 소비|관광소비|스마트|가게수|가게 수|매장수|매장 수|점포수|점포 수|술자리|옷차림")


@dataclass
class IndustryMatch:
    label: str                     # 표시명 (예: 커피 전문점)
    name_regex: str | None         # 업종명 매칭 정규식
    code_prefixes: list[str] = field(default_factory=list)
    keyword: str = ""              # 질문에서 잡힌 키워드

    def mask(self, codes, names):
        """pandas Series 두 개(코드, 명칭)에 대한 불리언 마스크 생성."""
        import pandas as pd
        m = pd.Series(False, index=names.index)
        if self.name_regex is not None:
            m = m | names.astype(str).str.contains(self.name_regex, regex=True, na=False)
        if self.code_prefixes and codes is not None:
            cs = codes.astype(str).str.upper().str.replace(" ", "", regex=False)
            for p in self.code_prefixes:
                m = m | cs.str.startswith(p.upper())
        return m


_EXPLICIT_ALL = re.compile(r"전체업종|모든업종|업종전체|업종무관|업종상관없이|전업종|업종구분없이|업종다|모든가게|전체가게|모든업태")


def is_explicit_all(text: str) -> bool:
    """'전체 업종'·'모든 업종'처럼 업종을 일부러 지정하지 않았음을 밝힌 표현인지."""
    return bool(_EXPLICIT_ALL.search(text.replace(" ", "")))


def resolve_industries(text: str) -> list[IndustryMatch]:
    """질문에서 업종 키워드를 찾아 매치 목록을 반환(구체적 키워드 우선). 없으면 빈 목록(=전체 업종)."""
    if is_explicit_all(text):
        return []
    # '관광객', '관광지', '스마트', '가게수' 등 업종이 아닌 표현은 먼저 제거
    cleaned = _NON_INDUSTRY.sub(" ", text)
    t = cleaned.replace(" ", "")
    text = cleaned
    hits: list[IndustryMatch] = []
    for keywords, label, regex, prefixes in _INDUSTRY_ALIASES:
        for kw in sorted(keywords, key=len, reverse=True):
            k = kw.replace(" ", "")
            if len(k) == 1:
                # 한 글자 키워드(바, 차, 회, 닭, 옷)는 오탐이 많아 단어 경계 조건 적용
                if re.search(rf"(^|[^가-힣]){k}([^가-힣]|$)", text):
                    hits.append(IndustryMatch(label, regex, prefixes, kw))
                    break
                continue
            if k in t:
                hits.append(IndustryMatch(label, regex, prefixes, kw))
                break
    # "음식점(전체)"는 더 구체적인 음식점 하위 업종이 있으면 제외
    labels = {h.label for h in hits}
    specific_food = {"커피 전문점", "한식 음식점", "중식 음식점", "일식 음식점", "서양식 음식점", "치킨 전문점", "피자·햄버거", "제과점", "김밥·간이음식점"}
    if "음식점(전체)" in labels and labels & specific_food:
        hits = [h for h in hits if h.label != "음식점(전체)"]
    if "소매(전체)" in labels and labels & {"편의점·슈퍼", "기념품·특산품", "화장품·미용", "의류·신발"}:
        hits = [h for h in hits if h.label != "소매(전체)"]
    # 중복 제거(표시명 기준)
    out: list[IndustryMatch] = []
    seen = set()
    for h in hits:
        if h.label not in seen:
            out.append(h)
            seen.add(h.label)
    return out


def group_of(code: str | None, name: str | None) -> str:
    """업종코드/명칭 → 업종 그룹명."""
    c = (str(code) if code is not None else "").upper().replace(" ", "")
    n = str(name) if name is not None else ""
    for g, spec in GROUPS.items():
        if g == "기타":
            continue
        if c and any(c.startswith(p.upper()) for p in spec["prefixes"]):
            return g
    for g, spec in GROUPS.items():
        if g == "기타":
            continue
        if n and any(k in n for k in spec["keywords"]):
            return g
    return "기타"


def is_tourism_group(group: str) -> bool:
    return bool(GROUPS.get(group, {}).get("tourism", False))


def describe(matches: list[IndustryMatch]) -> str:
    return ", ".join(m.label for m in matches) if matches else "전체 업종"

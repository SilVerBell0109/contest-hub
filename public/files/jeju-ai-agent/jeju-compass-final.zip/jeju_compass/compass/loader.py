"""CSV 적재·정규화·데이터함(DataStore).

- 센터 PC에서 내려받은 CSV(UTF-8, 영문 헤더, 구분자 쉼표, 결측 `NA`)와 허브 공개 CSV(한글 헤더) 모두 처리
- 레지스트리로 데이터셋 종류를 판정하고 표준 컬럼명으로 바꾼 뒤 파생 컬럼(업종그룹, 이용자그룹, 권역, 시)을 추가
- 같은 종류의 파일(예: 월별로 나뉜 카드 데이터)은 하나로 합쳐 관리
"""
from __future__ import annotations

import hashlib
import io
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from . import geo, industries
from .registry import DatasetSpec, Registry, get_registry

log = logging.getLogger(__name__)

NA_VALUES = ["NA", "N/A", "na", "null", "NULL", "", "-", "알수없음"]  # '알수없음'은 차원값으로는 유지하므로 수치열에만 적용
_ENCODINGS = ["utf-8-sig", "utf-8", "cp949", "euc-kr"]


@dataclass
class LoadedDataset:
    key: str
    spec: DatasetSpec | None
    df: pd.DataFrame
    origin: str                              # center | hub | sample | unknown
    files: list[str] = field(default_factory=list)
    mapping: dict[str, str] = field(default_factory=dict)
    unmapped: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def name(self) -> str:
        return self.spec.name if self.spec else f"미분류 표({self.key})"

    @property
    def rows(self) -> int:
        return int(len(self.df))

    @property
    def period(self) -> tuple[str | None, str | None]:
        if "ym" in self.df.columns and len(self.df):
            s = self.df["ym"].dropna()
            if len(s):
                return str(s.min()), str(s.max())
        return None, None

    @property
    def months(self) -> list[str]:
        if "ym" in self.df.columns:
            return sorted(self.df["ym"].dropna().unique().tolist())
        return []

    def summary(self) -> dict:
        p = self.period
        return {
            "key": self.key, "name": self.name, "origin": self.origin, "rows": self.rows,
            "period_start": p[0], "period_end": p[1], "months": len(self.months), "files": self.files,
            "columns": [c for c in self.df.columns], "unmapped": self.unmapped, "notes": self.notes, "warnings": self.warnings,
            "export": self.spec.export if self.spec else "unknown",
            "regions": int(self.df["bjd"].nunique()) if "bjd" in self.df.columns else 0,
        }


# ── 값 정규화 도우미 ────────────────────────────────────────────────────────
def _norm_ym(v) -> str | None:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    s = str(v).strip()
    m = re.match(r"^(\d{4})[.\-/년\s]*(\d{1,2})월?$", s)
    if m and 1 <= int(m.group(2)) <= 12:
        return f"{m.group(1)}{int(m.group(2)):02d}"
    m = re.match(r"^(\d{6})(\d{2})?(\.0)?$", s)
    if m:
        return m.group(1)
    # 날짜·일시형: 2026-01-01, 2026/01/15 00:00:00, 2026-01-01T00:00:00, 20260101
    m = re.match(r"^(\d{4})[.\-/]?(\d{2})[.\-/]?(\d{2})", s)
    if m and 1 <= int(m.group(2)) <= 12:
        return f"{m.group(1)}{m.group(2)}"
    # 영문 월 약어: Jan-26, 2026-Jan, Jan 2026
    mon = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}
    m = re.match(r"^([A-Za-z]{3})[a-z]*[\s\-/]?(\d{2,4})$", s) or re.match(r"^(\d{4})[\s\-/]([A-Za-z]{3})[a-z]*$", s)
    if m:
        a, b = m.group(1), m.group(2)
        name, year = (a, b) if a[:3].lower() in mon else (b, a)
        if name[:3].lower() in mon:
            y = int(year)
            y = y + 2000 if y < 100 else y
            return f"{y}{mon[name[:3].lower()]:02d}"
    return None


def _norm_date(v) -> str | None:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    s = str(v).strip()
    m = re.match(r"^(\d{4})[.\-/]?(\d{2})[.\-/]?(\d{2})", s)
    if m:
        return f"{m.group(1)}{m.group(2)}{m.group(3)}"
    return None


def _norm_age(v) -> str:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return "미상"
    s = str(v).strip().replace(" ", "")
    if s in ("", "nan", "NA", "알수없음", "미상"):
        return "미상"
    if "미만" in s or s in ("10세미만", "10대이하"):
        return "10대이하"
    m = re.match(r"^(\d{1,2})(\.0)?(대)?(이상)?$", s)
    if m:
        n = int(m.group(1))
        if n < 20:
            return "10대이하"
        if n >= 60:
            return "60대이상"
        return f"{n // 10 * 10}대"
    if s.startswith("60") or s.startswith("70") or s.startswith("80"):
        return "60대이상"
    return s


def _norm_gender(v) -> str:
    s = str(v).strip() if v is not None else ""
    if s in ("남", "남성", "M", "m", "male", "Male", "1"):
        return "남성"
    if s in ("여", "여성", "F", "f", "female", "Female", "2"):
        return "여성"
    if s in ("", "nan", "NA", "알수없음", "미상", "법인"):
        return "미상"
    return s


def _user_group(v) -> str:
    s = str(v).strip() if v is not None else ""
    if s in ("", "nan", "NA"):
        return "기타"
    if "도민" in s:
        return "제주도민"
    if s.startswith("내국인") or s in ("관광객", "내국인관광객", "개인"):
        return "내국인 관광객"
    if s in ("법인", "기업"):
        return "법인"
    if any(k in s for k in ("중국", "일본", "동남아", "외국", "미국", "유럽", "대만", "홍콩", "싱가포르", "말레이시아", "태국", "베트남", "필리핀", "인도네시아", "기타국")):
        return "외국인"
    return "기타"


def _norm_time_slot(v) -> str:
    """'9', '09', '9시', '09-12', '09~12', '오전' 등을 보기 좋은 구간 문자열로 통일."""
    s = str(v).strip() if v is not None else ""
    if s in ("", "nan", "NA"):
        return "미상"
    m = re.match(r"^(\d{1,2})\s*(시)?$", s)
    if m:
        h = int(m.group(1))
        return f"{h:02d}시"
    m = re.match(r"^(\d{1,2})\s*[~\-–]\s*(\d{1,2})", s)
    if m:
        return f"{int(m.group(1)):02d}-{int(m.group(2)):02d}시"
    return s


_DOW_MAP = {"1": "월", "2": "화", "3": "수", "4": "목", "5": "금", "6": "토", "7": "일", "0": "일",
            "mon": "월", "tue": "화", "wed": "수", "thu": "목", "fri": "금", "sat": "토", "sun": "일",
            "월요일": "월", "화요일": "화", "수요일": "수", "목요일": "목", "금요일": "금", "토요일": "토", "일요일": "일",
            "holiday": "공휴일", "공휴일": "공휴일", "휴일": "공휴일"}


def _norm_dow(v) -> str:
    s = str(v).strip() if v is not None else ""
    return _DOW_MAP.get(s.lower(), _DOW_MAP.get(s, s if s else "미상"))


def is_sample_name(name: str) -> bool:
    n = str(name).lower()
    return "sample" in n or "샘플" in n or "합성" in n


def read_csv_any(path: Path) -> pd.DataFrame:
    """인코딩을 바꿔 가며 CSV를 읽는다(UTF-8 → CP949)."""
    last = None
    for enc in _ENCODINGS:
        try:
            return pd.read_csv(path, encoding=enc, dtype=str, keep_default_na=False, na_values=[], low_memory=False)
        except UnicodeDecodeError as e:
            last = e
            continue
        except pd.errors.ParserError:
            # 세미콜론/탭 구분 등
            try:
                return pd.read_csv(path, encoding=enc, dtype=str, keep_default_na=False, na_values=[], sep=None, engine="python")
            except Exception as e:  # noqa: BLE001
                last = e
    raise ValueError(f"CSV 읽기 실패: {path.name} ({last})")


def normalize_frame(raw: pd.DataFrame, spec: DatasetSpec | None, mapping: dict[str, str], registry: Registry) -> tuple[pd.DataFrame, list[str]]:
    """원본 헤더를 표준명으로 바꾸고 값·형식을 정규화, 파생 컬럼 추가."""
    notes: list[str] = []
    df = raw.rename(columns=mapping).copy()
    # 중복 컬럼 방지
    df = df.loc[:, ~df.columns.duplicated()]

    # 시간 컬럼
    if "date" in df.columns:
        df["date"] = df["date"].map(_norm_date)
        if "ym" not in df.columns:
            df["ym"] = df["date"].map(lambda d: d[:6] if isinstance(d, str) else None)
    if "ym" in df.columns:
        raw_ym = df["ym"].copy()
        df["ym"] = df["ym"].map(_norm_ym)
        bad = int(df["ym"].isna().sum())
        if bad:
            if len(df) and bad / len(df) > 0.5:
                ex = ", ".join(map(str, raw_ym.dropna().astype(str).unique()[:3]))
                raise ValueError(f"연월(날짜) 열의 값을 해석하지 못했습니다(예: {ex}). 'YYYYMM' 또는 'YYYY-MM' 형식이어야 합니다. 담당자에게 보여 주세요.")
            notes.append(f"연월 해석 불가 행 {bad:,}건 제외")
            df = df[df["ym"].notna()]

    # 수치 컬럼
    for c in df.columns:
        cs = registry.library.get(c)
        if cs and cs.role in ("measure", "store", "pop"):
            df[c] = pd.to_numeric(df[c].replace({v: None for v in NA_VALUES}).astype(str).str.replace(",", "", regex=False).replace({"None": None, "nan": None}), errors="coerce")

    # 지역
    if "bjd" in df.columns:
        df["bjd"] = df["bjd"].map(geo.normalize_bjd)
        if "dstrct_se" in df.columns:
            mask = (df["bjd"] == "월평동") & df["dstrct_se"].astype(str).str.startswith("서귀포")
            if mask.any():
                df.loc[mask, "bjd"] = "월평동(서귀포)"
        else:
            df["dstrct_se"] = df["bjd"].map(geo.district_of)
        # 권역 값이 비어 있으면 사전으로 보완
        df["dstrct_se"] = df["dstrct_se"].where(df["dstrct_se"].notna() & (df["dstrct_se"].astype(str) != ""), df["bjd"].map(geo.district_of))
        df["city"] = df["bjd"].map(geo.city_of)
        unknown = df.loc[df["city"].isna(), "bjd"].dropna().unique().tolist()
        if unknown:
            notes.append(f"사전에 없는 지역명 {len(unknown)}개(예: {', '.join(map(str, unknown[:4]))}) — 권역·시 미배정, geo.py에 추가 가능")

    # 업종
    if "ksic_nm" in df.columns or "ksic_cd" in df.columns:
        codes = df["ksic_cd"] if "ksic_cd" in df.columns else pd.Series([None] * len(df), index=df.index)
        names = df["ksic_nm"] if "ksic_nm" in df.columns else pd.Series([None] * len(df), index=df.index)
        pairs = pd.DataFrame({"c": codes.astype(str), "n": names.astype(str)}).drop_duplicates()
        pairs["g"] = [industries.group_of(c, n) for c, n in zip(pairs["c"], pairs["n"])]
        gmap = {(c, n): g for c, n, g in zip(pairs["c"], pairs["n"], pairs["g"])}
        df["ind_grp"] = [gmap[(c, n)] for c, n in zip(codes.astype(str), names.astype(str))]

    # 레지스트리의 값 매핑(코드형 값 → 표준 라벨)이 있으면 먼저 적용
    vmaps = getattr(registry, "value_maps", {}) or {}
    for col, mp in vmaps.items():
        if col in df.columns and mp:
            df[col] = df[col].astype(str).str.strip().map(lambda v, mp=mp: mp.get(v, v))

    # 이용자·인구 차원
    if "user_se" in df.columns:
        df["user_se"] = df["user_se"].astype(str).str.strip()
        df["user_grp"] = df["user_se"].map(_user_group)
    if "age_se" in df.columns:
        df["age_se"] = df["age_se"].map(_norm_age)
    if "gender_se" in df.columns:
        df["gender_se"] = df["gender_se"].map(_norm_gender)
    if "time_se" in df.columns:
        df["time_se"] = df["time_se"].map(_norm_time_slot)
    if "dow_se" in df.columns:
        df["dow_se"] = df["dow_se"].map(_norm_dow)
    if "trip_se" in df.columns:
        df["trip_se"] = df["trip_se"].astype(str).str.strip().replace({"": "미상", "nan": "미상"})
    return df, notes


def diagnose(df: pd.DataFrame) -> list[str]:
    """값 체계가 예상과 다를 때(코드형 값 등) 담당자에게 보여줄 경고."""
    warn: list[str] = []
    n = len(df)
    if n == 0:
        return warn
    if "user_grp" in df.columns:
        r = float((df["user_grp"] == "기타").mean())
        if r > 0.5:
            ex = df.loc[df["user_grp"] == "기타", "user_se"].astype(str).unique()[:5].tolist()
            warn.append(f"이용자구분 값의 {r:.0%}가 사전에 없는 값입니다(예: {ex}). 코드형 값이면 datasets.yaml의 value_maps에 매핑을 추가하세요.")
    if "age_se" in df.columns:
        vals = df["age_se"].astype(str).unique().tolist()
        if len(vals) == 1 and vals[0] in ("10대이하", "미상"):
            warn.append(f"연령대 값이 모두 '{vals[0]}'로 해석됐습니다. 원본 값 체계(코드형 등)를 확인하고 value_maps를 설정하세요.")
    if "gender_se" in df.columns:
        bad = [v for v in df["gender_se"].astype(str).unique().tolist() if v not in ("남성", "여성", "미상")]
        if bad:
            warn.append(f"성별 값에 알 수 없는 값이 있습니다: {bad[:5]} (value_maps로 매핑 가능)")
    if "ym" in df.columns:
        months = df["ym"].dropna().unique()
        if len(months) and (max(months) > "203012" or min(months) < "200001"):
            warn.append("연월 값이 비정상 범위입니다. 연월 컬럼 매핑을 확인하세요.")
    return warn


# ── 데이터함 ────────────────────────────────────────────────────────────────
class UnknownDataset(ValueError):
    """센터·허브 데이터 형식이 아니어서 분석에 쓸 수 없는 파일."""

    def __init__(self, filename: str, columns: list[str], hint: str = ""):
        self.filename, self.columns = filename, columns
        cols = ", ".join(map(str, columns[:8])) + (" …" if len(columns) > 8 else "")
        msg = f"'{filename}'은(는) 센터·허브 데이터 형식으로 알아보지 못해 분석에 쓸 수 없어요 (열 이름: {cols})."
        super().__init__(msg + (" " + hint if hint else " 담당자에게 보여 주세요."))


class DataStore:
    def __init__(self, registry: Registry | None = None, allow_unknown: bool = False):
        self.registry = registry or get_registry()
        self.datasets: dict[str, LoadedDataset] = {}
        self._file_hashes: dict[str, str] = {}
        self.allow_unknown = allow_unknown          # 미분류 파일을 적재할지(기본: 거부하고 안내)
        self.last_dropped_samples: list[str] = []
        self.skipped: list[str] = []                # 폴더 읽기에서 건너뛴 파일 안내

    # 적재 ---------------------------------------------------------------
    def load_file(self, path: Path | str, origin: str | None = None) -> LoadedDataset:
        path = Path(path)
        raw = read_csv_any(path)
        return self.load_frame(raw, path.name, origin=origin, file_label=str(path))

    def load_bytes(self, data: bytes, filename: str, origin: str | None = None) -> LoadedDataset:
        if data[:2] == b"\x1f\x8b":          # gzip 압축(.csv.gz)
            import gzip
            data = gzip.decompress(data)
        last = None
        for enc in _ENCODINGS:
            try:
                raw = pd.read_csv(io.BytesIO(data), encoding=enc, dtype=str, keep_default_na=False, na_values=[], low_memory=False)
                break
            except UnicodeDecodeError as e:
                last = e
        else:
            raise ValueError(f"CSV 읽기 실패: {filename} ({last})")
        return self.load_frame(raw, filename, origin=origin, file_label=filename)

    def load_frame(self, raw: pd.DataFrame, filename: str, origin: str | None = None, file_label: str = "") -> LoadedDataset:
        if raw is None or len(raw) == 0:
            raise ValueError(f"'{file_label or filename}'에 데이터 행이 없습니다(머리글만 있거나 빈 파일).")
        det = self.registry.detect(raw.columns, filename)
        spec = det.spec
        if spec is None:
            if not self.allow_unknown:
                near, missing = self.registry.nearest(raw.columns)
                hint = ""
                if near is not None and missing:
                    names = ", ".join(f"{self.registry.label(c)}({c})" for c in missing)
                    hint = (f"'{near.name}' 형식과 비슷하지만 {names} 열을 알아보지 못했습니다"
                            + (f" (알 수 없는 열: {', '.join(map(str, det.unmapped[:5]))})" if det.unmapped else "")
                            + ". 담당자: compass/datasets.yaml의 aliases에 실제 열 이름을 추가하거나 scripts/check_csv.py로 확인하세요.")
                raise UnknownDataset(file_label or filename, list(map(str, raw.columns)), hint)
        key = spec.key if spec else f"unknown_{hashlib.md5(','.join(map(str, raw.columns)).encode()).hexdigest()[:6]}"
        df, notes = normalize_frame(raw, spec, det.mapping, self.registry)
        if origin is None:
            origin = spec.source if spec else "unknown"
        if is_sample_name(file_label or filename):
            origin = "sample"
            notes.append("파일명에 'sample/샘플'이 있어 연습용(가짜) 데이터로 표시합니다")
        notes.insert(0, f"판정: {spec.name if spec else '미분류'} ({det.reason})")
        if det.unmapped:
            notes.append(f"매핑되지 않은 컬럼 {len(det.unmapped)}개 유지: {', '.join(det.unmapped[:6])}{' …' if len(det.unmapped) > 6 else ''}")
        ds = LoadedDataset(key, spec, df, origin, [file_label or filename], det.mapping, det.unmapped, notes, diagnose(df))
        return self._merge(ds)

    def drop_samples(self) -> list[str]:
        """연습용(가짜) 데이터를 모두 뺀다. 실제 데이터와 섞여 '가짜 결과' 표시가 붙는 혼란을 막는다."""
        names = [d.name for d in self.datasets.values() if d.origin == "sample"]
        for k in [k for k, d in self.datasets.items() if d.origin == "sample"]:
            self.remove(k)
        return names

    def _merge(self, ds: LoadedDataset) -> LoadedDataset:
        if ds.origin != "sample" and ds.key not in ("",) and self.has_sample():
            dropped = self.drop_samples()
            if dropped:
                ds.notes.append(f"실제 데이터가 들어와 연습용 가짜 데이터 {len(dropped)}종을 뺐습니다")
                self.last_dropped_samples = dropped
        if ds.key in self.datasets:
            cur = self.datasets[ds.key]
            if cur.origin != ds.origin:
                # 샘플 데이터와 실제 데이터는 섞지 않는다 — 실제 데이터가 들어오면 샘플을 버림
                if cur.origin == "sample":
                    self.datasets[ds.key] = ds
                    ds.notes.append("샘플 데이터를 실제 데이터로 교체")
                    return ds
                if ds.origin == "sample":
                    cur.notes.append("실제 데이터가 있어 샘플 적재 생략")
                    return cur
            old = cur.df
            new = ds.df
            keys = [c for c in old.columns if c in new.columns and not pd.api.types.is_numeric_dtype(old[c])]
            if "ym" in old.columns and "ym" in new.columns and keys:
                overlap = sorted(set(old["ym"].dropna().unique()) & set(new["ym"].dropna().unique()))
                if overlap:
                    # 같은 달 자료가 이미 있으면 '같은 키(모든 차원 조합)'인 행만 새 값으로 바꾸고, 다른 지역·업종 행은 합친다
                    old_keys = old[keys].astype(str).agg("\u0001".join, axis=1)
                    new_keys = set(new[keys].astype(str).agg("\u0001".join, axis=1))
                    dup = old_keys.isin(new_keys)
                    n_rep, n_add = int(dup.sum()), int((~new[keys].astype(str).agg("\u0001".join, axis=1).isin(set(old_keys))).sum())
                    old = old[~dup]
                    if n_rep and n_add:
                        cur.warnings.append(f"같은 달({', '.join(overlap[:4])}{' …' if len(overlap) > 4 else ''}) 자료 중 겹치는 행 {n_rep:,}개는 새 파일 값으로 바꾸고, 새 행 {n_add:,}개는 합쳤습니다(지역·업종이 다른 분할 파일로 처리).")
                    elif n_rep:
                        cur.warnings.append(f"같은 달({', '.join(overlap[:4])}{' …' if len(overlap) > 4 else ''}) 자료가 이미 있어 겹치는 행 {n_rep:,}개를 새 파일의 값으로 바꿨습니다(이중 집계 방지).")
                    else:
                        cur.warnings.append(f"같은 달({', '.join(overlap[:4])}) 자료에 다른 지역·업종 행 {n_add:,}개를 합쳤습니다(분할 파일).")
            merged = pd.concat([old, new], ignore_index=True).drop_duplicates()
            cur.df = merged
            cur.files = list(dict.fromkeys(cur.files + ds.files))
            cur.notes = list(dict.fromkeys(cur.notes + [n for n in ds.notes if not n.startswith("판정")]))
            cur.warnings = list(dict.fromkeys(cur.warnings + diagnose(merged)))
            return cur
        self.datasets[ds.key] = ds
        return ds

    def scan_folder(self, folder: Path | str, origin: str | None = None) -> list[LoadedDataset]:
        folder = Path(folder)
        out = []
        if not folder.exists():
            return out
        for p in sorted(list(folder.rglob("*.csv")) + list(folder.rglob("*.csv.gz"))):
            file_origin = origin
            if file_origin is None and (p.parent / "README_SAMPLE.txt").exists():
                file_origin = "sample"
            with p.open("rb") as fh:
                head = fh.read(200000)
            h = hashlib.md5(head + str(p.stat().st_size).encode()).hexdigest()
            if self._file_hashes.get(str(p)) == h:
                continue
            try:
                ds = self.load_file(p, origin=file_origin)
                self._file_hashes[str(p)] = h
                out.append(ds)
            except UnknownDataset as e:
                self._file_hashes[str(p)] = h           # 같은 파일을 매번 다시 시도하지 않음
                self.skipped.append(str(e))
                log.warning("미분류 파일 건너뜀 %s: %s", p, e)
            except Exception as e:  # noqa: BLE001
                self.skipped.append(f"'{p.name}' 읽기 실패: {e}")
                log.warning("파일 적재 실패 %s: %s", p, e)
        return out

    # 조회 ---------------------------------------------------------------
    def get(self, key: str) -> LoadedDataset | None:
        return self.datasets.get(key)

    def has(self, *keys: str) -> bool:
        return all(k in self.datasets for k in keys)

    def first_available(self, keys: list[str]) -> LoadedDataset | None:
        for k in keys:
            if k in self.datasets:
                return self.datasets[k]
        return None

    def clear(self):
        self.datasets.clear()
        self._file_hashes.clear()

    def remove(self, key: str):
        ds = self.datasets.pop(key, None)
        files = set(ds.files) if ds else set()
        self._file_hashes = {p: h for p, h in self._file_hashes.items() if p not in files and key not in p}

    def summaries(self) -> list[dict]:
        return [d.summary() for d in self.datasets.values()]

    def latest_month(self) -> str | None:
        months = [d.period[1] for d in self.datasets.values() if d.period[1]]
        return max(months) if months else None

    def has_sample(self) -> bool:
        return any(d.origin == "sample" for d in self.datasets.values())

"""반출 기준 검수 게이트 (Statistical Disclosure Control, SDC).

제주빅데이터센터 데이터 반출 기준(2026.9.1 개정)의 핵심을 코드로 강제합니다.
  1) 단순집계 셀의 인원·건수가 임계값(기본 10) 미만이면 그대로 반출 불가
  2) 상위 범주로 다시 집계(범주처리)하여 모든 셀을 임계값 이상으로 만들면 인정
  3) 합계·다른 셀에서 역산 가능한 경우 반출 불가 → 2차 비공개 처리(secondary suppression)

처리 순서: 범주 상향(롤업/작은 셀 병합) → 1차 비공개(마스킹) → 2차 비공개(역산 방지: 행·열·전체 합계가 공개된다고
가정한 선형 역산 검사) → 비공개 행의 모든 수치 제거 → 상위 N 절단 → 검수 결과 기록
모든 결과는 `SDCResult.actions`에 남아 보고서의 '반출 검수 결과' 절에 그대로 인쇄됩니다.

한계(문서에도 명시): 역산 검사는 한 표 안에서 행·열·전체 합계가 공개된 경우를 가정한 선형 검사입니다. 서로 다른
보고서를 조합한 차분(differencing) 공격은 센터 반출 심사(사람)가 최종 확인합니다.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd

SUPPRESSED_LABEL = "비공개(<{n})"
SECONDARY_LABEL = "비공개(역산 방지)"      # 2차 비공개: 값 자체는 기준 이상이지만 다른 칸을 역산하지 못하게 가린 칸
MERGED_SUFFIX = "(기타 합계)"

# ── 롤업(범주 상향) 함수 ─────────────────────────────────────────────────────
def ym_to_quarter(ym: str) -> str:
    s = str(ym)
    if len(s) < 6 or not s[:6].isdigit():
        return s
    q = (int(s[4:6]) - 1) // 3 + 1
    return f"{s[:4]}Q{q}"


def ym_to_year(ym: str) -> str:
    s = str(ym)
    return s[:4] if s[:4].isdigit() else s


def age_to_band(age: str) -> str:
    a = str(age)
    if a in ("10대이하", "20대"):
        return "20대 이하"
    if a in ("30대", "40대"):
        return "30~40대"
    if a in ("50대", "60대이상"):
        return "50대 이상"
    return a


def time_to_band(t: str) -> str:
    s = str(t)
    try:
        h = int(s[:2])
    except ValueError:
        return s
    if h < 6:
        return "00-06시"
    if h < 12:
        return "06-12시"
    if h < 18:
        return "12-18시"
    return "18-24시"


def dow_to_band(d: str) -> str:
    return "평일" if str(d) in ("월", "화", "수", "목", "금") else "주말·공휴일"


def gender_to_all(_: str) -> str:
    return "전체"


@dataclass
class Rollup:
    column: str
    mapper: Callable[[str], str] | None
    label: str                      # 예: "연월→분기"
    new_column: str | None = None   # 다른 컬럼으로 승격(예: bjd→dstrct_se)
    merge_small: bool = False       # True면 전체를 바꾸지 않고 작은 셀의 범주만 '기타 합계'로 병합
    merge_label: str = "기타"


# 이웃 범주 병합을 적용할 수 있는 차원(시간 차원은 제외 — 분기·연도 상향이 따로 있음)
_MERGEABLE_DIMS = ("user_grp", "user_se", "ksic_nm", "ind_grp", "age_se", "gender_se", "bjd", "dstrct_se", "city", "nation")

STANDARD_ROLLUPS: dict[str, Rollup] = {
    "ym_quarter": Rollup("ym", ym_to_quarter, "연월→분기"),
    "ym_year": Rollup("ym", ym_to_year, "연월→연도"),
    "age_band": Rollup("age_se", age_to_band, "연령대→3구간"),
    "gender_all": Rollup("gender_se", gender_to_all, "성별→전체"),
    "nation_foreign": Rollup("user_se", None, "작은 국적→기타 외국인 합계", merge_small=True, merge_label="기타 외국인"),
    "time_band": Rollup("time_se", time_to_band, "시간대→6시간 구간"),
    "dow_band": Rollup("dow_se", dow_to_band, "요일→평일/주말·공휴일"),
    "industry_other": Rollup("ksic_nm", None, "작은 업종→기타 업종 합계", merge_small=True, merge_label="기타 업종"),
}


@dataclass
class SDCAction:
    kind: str          # rollup | merge | suppress | secondary | unverifiable | pass
    detail: str
    count: int = 0


@dataclass
class SDCResult:
    table: pd.DataFrame
    dims: list[str]
    measures: list[str]
    passed: bool
    min_cell: int
    actions: list[SDCAction] = field(default_factory=list)
    n_suppressed: int = 0
    n_secondary: int = 0
    verified: bool = True
    label: str | None = None      # 요약 문구를 직접 지정할 때(파생 지표표 등)
    rolled: bool = False          # 범주 상향/병합이 일어났는지
    plain_override: str = ""      # 파생 지표표 등에서 쉬운 말 배지를 직접 지정
    applied: list = field(default_factory=list)   # 적용된 범주 변환 기록 [(column, mapping|callable, new_column)] — 보고서 단위 연결표 검사용
    n_linked: int = 0             # 보고서 단위(연결표) 검사로 추가 비공개된 셀 수

    @property
    def summary(self) -> str:
        if self.label:
            return self.label
        if not self.verified:
            return "검수 불가(인원·건수 열 없음) — 반출 전 수동 확인 필요"
        if self.min_cell <= 0:
            return "공개 데이터 — 임계값 미적용"
        parts = []
        rl = [a.detail for a in self.actions if a.kind in ("rollup", "merge")]
        if rl:
            parts.append("범주처리: " + ", ".join(rl))
        if self.n_suppressed:
            parts.append(f"1차 비공개 {self.n_suppressed}셀")
        if self.n_secondary:
            parts.append(f"2차(역산 방지) 비공개 {self.n_secondary}셀")
        if self.n_linked:
            parts.append(f"보고서 내 다른 표와의 역산 방지 비공개 {self.n_linked}셀")
        if not parts:
            return f"모든 셀 {self.min_cell} 이상 — 반출 기준 충족"
        return " / ".join(parts) + (" — 처리 후 기준 충족" if self.passed else " — 기준 미충족")

    @property
    def plain(self) -> str:
        """비전공자용 한 줄 설명."""
        if self.plain_override:
            return self.plain_override
        if not self.verified:
            return "인원·건수 정보가 없어 자동 확인을 못 해 수치를 가렸습니다(담당자 확인 필요)"
        if self.min_cell <= 0:
            return "공개 데이터라 가릴 칸이 없습니다"
        n = self.n_suppressed + self.n_secondary + self.n_linked
        if n == 0 and not self.rolled:
            return f"{self.min_cell}명 미만인 칸이 없어 그대로 보여 드립니다"
        parts = []
        if self.rolled:
            parts.append("일부 항목을 큰 묶음으로 합쳤고")
        if n:
            parts.append(f"{n}칸은 개인정보 보호를 위해 가렸습니다")
        return " ".join(parts) if parts else "확인 완료"

    @property
    def has_hidden(self) -> bool:
        return bool(self.n_suppressed or self.n_secondary or self.n_linked)

    def to_dict(self) -> dict:
        return {"passed": self.passed, "verified": self.verified, "min_cell": self.min_cell, "summary": self.summary, "plain": self.plain,
                "actions": [{"kind": a.kind, "detail": a.detail, "count": a.count} for a in self.actions],
                "n_suppressed": self.n_suppressed, "n_secondary": self.n_secondary, "n_linked": self.n_linked, "rolled": self.rolled}


# ── 내부 도우미 ─────────────────────────────────────────────────────────────
def _small_mask(df: pd.DataFrame, count_cols: list[str], min_cell: int) -> pd.Series:
    m = pd.Series(False, index=df.index)
    for c in count_cols:
        if c in df.columns:
            v = pd.to_numeric(df[c], errors="coerce").fillna(0)
            m = m | (v < min_cell)
    return m


def _numeric_cols(df: pd.DataFrame, dims: list[str]) -> list[str]:
    return [c for c in df.columns if c not in dims and c != "_suppressed" and pd.api.types.is_numeric_dtype(df[c])]


def _regroup(df: pd.DataFrame, dims: list[str], sum_cols: list[str]) -> pd.DataFrame:
    dims = [d for d in dims if d in df.columns]
    cols = [m for m in sum_cols if m in df.columns]
    if not dims:
        return df[cols].sum().to_frame().T
    return df.groupby(dims, dropna=False, observed=True, as_index=False)[cols].sum()


def _uniquely_determined(sup_idx: list[int], groups: list[list[int]]) -> list[int]:
    """행·열·전체 합계가 공개된다고 가정할 때 유일하게 결정되는 비공개 셀 인덱스.

    각 그룹(행/열/전체)의 합이 알려지면, 그 그룹 안의 비공개 셀 합이 하나의 선형 방정식이 됩니다.
    비공개 셀 j가 방정식들의 선형 결합으로 표현되면(= e_j 가 행공간에 속하면) 역산 가능합니다.
    """
    if not sup_idx:
        return []
    pos = {j: i for i, j in enumerate(sup_idx)}
    rows = []
    for g in groups:
        vec = np.zeros(len(sup_idx))
        hit = False
        for j in g:
            if j in pos:
                vec[pos[j]] = 1.0
                hit = True
        if hit:
            rows.append(vec)
    if not rows:
        return []
    A = np.array(rows)
    rank_a = np.linalg.matrix_rank(A)
    out = []
    for j in sup_idx:
        e = np.zeros(len(sup_idx))
        e[pos[j]] = 1.0
        if np.linalg.matrix_rank(np.vstack([A, e])) == rank_a:
            out.append(j)
    return out


def _group_index_lists(df: pd.DataFrame, dims: list[str]) -> list[list[int]]:
    """전체 합계 그룹 + (2차원 이상이면) 각 차원을 고정한 행/열 그룹의 위치 인덱스 목록."""
    groups: list[list[int]] = [list(range(len(df)))]
    if len(dims) >= 2:
        for d in dims:
            others = [x for x in dims if x != d]
            for _, idx in df.groupby(others, dropna=False, observed=True).indices.items():
                if len(idx) >= 2:      # 셀이 하나뿐인 행/열의 합계는 그 셀 자체이므로 '공개 합계'로 보지 않는다(무한 연쇄 방지)
                    groups.append([int(i) for i in idx])
    return groups


# ── 메인 ───────────────────────────────────────────────────────────────────
def protect(table: pd.DataFrame, dims: list[str], measures: list[str], count_columns: list[str], min_cell: int = 10,
            rollups: list[Rollup] | None = None, secondary: bool = True, max_rows: int | None = None, sort_by: str | None = None,
            ascending: bool = False) -> SDCResult:
    """집계표를 반출 기준에 맞게 보호한다.

    table      : 차원(dims) + 측정값(measures)로 구성된 집계표(long format)
    count_cols : 임계값 검사 대상 열(이용자수·이용건수 등). 표에 하나도 없으면 '검수 불가'로 표시
    rollups    : 작은 셀이 있을 때 순서대로 시도할 범주 상향 규칙(전체 매핑 또는 작은 셀 병합)
    max_rows   : 상위 N 절단은 검수 **이후**에 적용(부분합이 상위 범주로 둔갑하는 것을 막음)
    """
    df = table.copy().reset_index(drop=True)
    dims = [d for d in dims if d in df.columns]
    measures = [m for m in measures if m in df.columns]
    counts = [c for c in count_columns if c in df.columns]
    actions: list[SDCAction] = []
    applied: list = []
    sum_cols = list(dict.fromkeys([*measures, *counts]))

    def _cut(d: pd.DataFrame) -> pd.DataFrame:
        if sort_by and sort_by in d.columns:
            key = pd.to_numeric(d[sort_by], errors="coerce")
            fill = -np.inf if not ascending else np.inf
            d = d.assign(_k=key.fillna(fill)).sort_values("_k", ascending=ascending, kind="stable").drop(columns="_k")
        if max_rows and len(d) > max_rows:
            d = d.head(max_rows)
        return d.reset_index(drop=True)

    if min_cell <= 0:
        df["_suppressed"] = False
        df["_kind"] = ""
        return SDCResult(_cut(df), dims, measures, True, min_cell, [SDCAction("pass", "반출 가능 데이터(임계값 미적용)")])
    if not counts:
        # 인원·건수 열이 없으면 임계값을 확인할 수 없다 → '표시'가 아니라 '차단': 모든 수치를 가리고 담당자 확인으로 넘긴다
        df["_suppressed"] = True
        df["_kind"] = "P"
        for c in _numeric_cols(df, dims):
            df[c] = df[c].astype(float)
            df[c] = np.nan
        return SDCResult(_cut(df), dims, measures, False, min_cell, [SDCAction("unverifiable", "인원·건수 열이 없어 임계값 검수를 할 수 없음 — 수치를 가리고 담당자 확인 필요", len(df))],
                         n_suppressed=len(df), verified=False)

    small = _small_mask(df, counts, min_cell)
    rolled = False
    # 1) 범주 상향 / 작은 셀 병합
    for r in (rollups or []):
        if not small.any():
            break
        if r.column not in df.columns:
            continue
        before = int(small.sum())
        if r.merge_small:
            small_cats = set(df.loc[small, r.column].astype(str))
            if not small_cats:
                continue
            small_cells = df.loc[small, dims].astype(str).to_dict("records")
            new_label = f"{r.merge_label}{MERGED_SUFFIX}"
            col = df[r.column].astype(str)
            df[r.column] = col.where(~col.isin(small_cats), new_label)
            df = _regroup(df, dims, sum_cols)
            small = _small_mask(df, counts, min_cell)
            actions.append(SDCAction("merge", f"{r.label}: {len(small_cats)}개 범주 → '{new_label}' (작은 셀 {before}→{int(small.sum())})", before - int(small.sum())))
            applied.append((r.column, {c: new_label for c in small_cats}, None, small_cells))
            rolled = True
        elif r.new_column and r.new_column in df.columns:
            new_dims = [d for d in dims if d != r.column]
            df = _regroup(df.drop(columns=[r.column]), new_dims, sum_cols)
            dims = new_dims
            small = _small_mask(df, counts, min_cell)
            actions.append(SDCAction("rollup", f"{r.label} (작은 셀 {before}→{int(small.sum())})", before - int(small.sum())))
            applied.append((r.column, None, r.new_column))
            rolled = True
        else:
            df[r.column] = df[r.column].map(r.mapper)
            df = _regroup(df, dims, sum_cols)
            small = _small_mask(df, counts, min_cell)
            actions.append(SDCAction("rollup", f"{r.label} (작은 셀 {before}→{int(small.sum())})", before - int(small.sum())))
            applied.append((r.column, r.mapper, None))
            rolled = True
    # 1.5) 이웃 범주 병합: 작은 셀이 특정 범주(예: '법인', '추자면')에 몰려 있으면 그 범주를 가장 작은 이웃 범주와 합친다.
    #      가리는 대신 합치면 수치가 남고(범주처리 인정), 2차 비공개가 연쇄되는 2차원 표의 문제도 피할 수 있다.
    if small.any() and len(df) > 1:
        for d in [x for x in dims if x in _MERGEABLE_DIMS]:
            for _round in range(6):
                small = _small_mask(df, counts, min_cell)
                if not small.any():
                    break
                cats = df[d].astype(str)
                if cats.nunique() < 2:
                    break
                bad = sorted(set(cats[small]))
                small_cells = df.loc[small, dims].astype(str).to_dict("records")
                totals = df.assign(_c=cats).groupby("_c")[counts[0]].sum().sort_values()
                mapping: dict[str, str] = {}
                for cat in bad:
                    if cat in mapping:
                        continue
                    partners = [c for c in totals.index if c != cat and c not in mapping and c not in bad]
                    if not partners:
                        partners = [c for c in totals.index if c != cat and c not in mapping]
                    if not partners:
                        continue
                    partner = partners[0]
                    base_a = cat.replace(MERGED_SUFFIX, "")
                    base_b = partner.replace(MERGED_SUFFIX, "")
                    label = f"{base_b}+{base_a}(병합)"
                    mapping[cat] = label
                    mapping[partner] = label
                if not mapping:
                    break
                df[d] = cats.map(lambda v: mapping.get(v, v))
                df = _regroup(df, dims, sum_cols)
                after = int(_small_mask(df, counts, min_cell).sum())
                actions.append(SDCAction("merge", f"{d}: 작은 범주를 이웃 범주와 병합({', '.join(sorted(set(mapping.values())))}) (작은 셀 {int(small.sum())}→{after})", int(small.sum()) - after))
                applied.append((d, dict(mapping), None, small_cells))
                rolled = True
            if not _small_mask(df, counts, min_cell).any():
                break
    df = df.reset_index(drop=True)
    small = _small_mask(df, counts, min_cell)

    # 2) 1차 비공개
    df["_suppressed"] = False
    df["_kind"] = ""           # P=임계값 미만(1차) / S=역산 방지(2차) / L=보고서 내 연결표 역산 방지
    n1 = int(small.sum())
    if n1:
        df.loc[small, "_suppressed"] = True
        df.loc[small, "_kind"] = "P"
        actions.append(SDCAction("suppress", f"임계값({min_cell}) 미만 셀 {n1}개 비공개 처리", n1))

    # 3) 2차 비공개(역산 방지): 행·열·전체 합계가 공개된다고 가정하고, 유일하게 결정되는 비공개 셀이 없어질 때까지 추가 비공개
    n2 = 0
    if secondary and n1 and len(df) > 1:
        key = counts[0]
        keyvals = pd.to_numeric(df[key], errors="coerce").fillna(0).values
        groups = _group_index_lists(df, dims)
        prev_det = None
        for _ in range(len(df)):
            sup_idx = [int(i) for i in np.flatnonzero(df["_suppressed"].values)]
            if len(sup_idx) >= len(df):
                break
            det = _uniquely_determined(sup_idx, groups)
            if not det:
                break
            if prev_det is not None and len(det) >= prev_det and n2 >= 2 * n1 + 4:
                break          # 추가해도 줄지 않으면 중단(표 전체가 가려지는 연쇄 방지) — 남은 위험은 보고서 단위 검사가 처리
            prev_det = len(det)
            sup = set(sup_idx)
            # 보완 셀 선택: (1) 역산되는 셀들 중 '비공개 셀이 하나뿐인 그룹(행/열)'을 가진 셀을 찾아 그 그룹에서 고르고,
            # (2) 새 단독 비공개 셀을 만들지 않는 셀(속한 모든 그룹에 이미 비공개 셀이 있음)을 우선, (3) 그다음 값이 작은 셀.
            # → 연쇄 비공개를 줄여 공개 셀을 최대한 보존한다.
            cand_groups: list[list[int]] = []
            for j in det:
                containing = [g for g in groups[1:] if j in g]
                deficient = [g for g in containing if sum(1 for i in g if i in sup) <= 1]
                if deficient:
                    cand_groups = deficient
                    break
            if not cand_groups:
                j = det[0]
                cand_groups = [g for g in groups[1:] if j in g] or [groups[0]]
            cands = {i for g in cand_groups for i in g if i not in sup}
            if not cands:
                cands = {i for i in range(len(df)) if i not in sup}
            if not cands:
                break

            def _score(i: int) -> tuple[int, float]:
                new_singletons = sum(1 for g in groups[1:] if i in g and not any(x in sup for x in g))
                return (new_singletons, float(keyvals[i]))

            pick = min(cands, key=_score)
            df.at[pick, "_suppressed"] = True
            df.at[pick, "_kind"] = "S"
            n2 += 1
        if n2:
            actions.append(SDCAction("secondary", f"역산 방지를 위해 추가 {n2}개 셀 비공개", n2))

    # 4) 비공개 행의 모든 수치 제거(측정값·건수·파생 열 전부) — 숫자가 어디에도 남지 않도록
    if df["_suppressed"].any():
        for c in _numeric_cols(df, dims):
            df[c] = df[c].astype(float)
            df.loc[df["_suppressed"], c] = np.nan

    if not actions:
        actions.append(SDCAction("pass", f"모든 셀이 임계값({min_cell}) 이상"))
    return SDCResult(_cut(df), dims, measures, True, min_cell, actions, n_suppressed=n1, n_secondary=n2, rolled=rolled, applied=applied)


def blank_suppressed(res: SDCResult) -> None:
    """검수 이후에 파생 열(예: 전년 대비)을 추가했을 때 호출 — 비공개 행의 모든 수치를 다시 제거."""
    df = res.table
    if "_suppressed" in df.columns and df["_suppressed"].any():
        for c in _numeric_cols(df, res.dims):
            df[c] = df[c].astype(float)
            df.loc[df["_suppressed"], c] = np.nan


def display_frame(res: SDCResult, labels: dict[str, str] | None = None, fmt: dict[str, Callable] | None = None) -> pd.DataFrame:
    """보고서·화면 출력용: 비공개 셀을 라벨로 바꾸고 열 이름을 한글로."""
    df = res.table
    labels = labels or {}
    out = pd.DataFrame(index=df.index)
    for d in res.dims:
        out[labels.get(d, d)] = df[d].astype(str)
    sup = df["_suppressed"] if "_suppressed" in df.columns else pd.Series(False, index=df.index)
    kinds = df["_kind"] if "_kind" in df.columns else pd.Series("", index=df.index)
    for m in res.measures:
        col = labels.get(m, m)
        f = (fmt or {}).get(m)
        rendered = []
        for v, s, k in zip(df[m], sup, kinds):
            if s:
                rendered.append(SUPPRESSED_LABEL.format(n=res.min_cell) if k in ("P", "") else SECONDARY_LABEL)
            elif v is None or (isinstance(v, float) and math.isnan(v)):
                rendered.append("")
            else:
                rendered.append(f(v) if f else (f"{v:,.0f}" if isinstance(v, (int, float, np.integer, np.floating)) else str(v)))
        out[col] = rendered
    return out.reset_index(drop=True)


def numeric_frame(res: SDCResult, labels: dict[str, str] | None = None) -> pd.DataFrame:
    """재사용 가능한 수치형 표(비공개 셀은 빈칸 + 플래그 열) — CSV 저장용."""
    df = res.table
    labels = labels or {}
    out = pd.DataFrame(index=df.index)
    for d in res.dims:
        out[labels.get(d, d)] = df[d].astype(str)
    for m in res.measures:
        out[labels.get(m, m)] = pd.to_numeric(df[m], errors="coerce").round(2)
    out["비공개"] = df["_suppressed"].map({True: "Y", False: ""}) if "_suppressed" in df.columns else ""
    out["비공개_사유"] = df["_kind"].map({"P": "기준 미만", "S": "역산 방지", "L": "역산 방지(다른 표)", "": ""}) if "_kind" in df.columns else ""
    return out.reset_index(drop=True)


def safe_records(res: SDCResult, max_rows: int = 60) -> list[dict]:
    """LLM 전송·JSON 출력용: 차원 + 측정값만, 비공개 행은 수치 전부 null, 행 수 제한, 소수 2자리 반올림."""
    df = res.table
    cols = [*res.dims, *res.measures]
    sup = df["_suppressed"].tolist() if "_suppressed" in df.columns else [False] * len(df)
    recs = []
    for i, (_, r) in enumerate(df[cols].head(max_rows).iterrows()):
        rec = {}
        for c in cols:
            v = r[c]
            if c in res.measures:
                if sup[i] or v is None or (isinstance(v, float) and math.isnan(v)):
                    rec[c] = None
                else:
                    fv = float(v)
                    rec[c] = int(fv) if fv.is_integer() else round(fv, 2)
            else:
                rec[c] = None if v is None or (isinstance(v, float) and math.isnan(v)) else str(v)
        recs.append(rec)
    return recs

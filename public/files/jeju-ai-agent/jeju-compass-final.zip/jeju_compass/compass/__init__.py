"""제주 상권 나침반 (Jeju Commerce Compass) — 제주 카드소비·유동인구 데이터 분석 AI Agent.

패키지 구성
- geo / industries : 지역(법정동·권역)·업종(KSIC) 사전 및 자연어 해석
- registry / loader: 데이터셋 레지스트리, 컬럼 자동 매핑, CSV 적재
- planner / llm   : 질문 → 분석 계획(LLM + 규칙 기반 fallback), LLM 호출·전송 가드
- templates       : 분석 템플릿(도구)
- sdc             : 반출 기준 검수(통계적 비밀보호) 게이트
- charts / report : 차트·보고서(HTML/PDF/PNG)
- agent           : 오케스트레이터
"""

__version__ = "1.0.0"
APP_NAME = "제주 상권 나침반"

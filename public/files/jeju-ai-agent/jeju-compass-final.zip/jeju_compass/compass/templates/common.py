"""템플릿들이 공유하는 데이터 선택·표 보호·요약 문장 도우미."""
from __future__ import annotations

import pandas as pd

from ..loader import DataStore, LoadedDataset
from ..sdc import protect, display_frame
from ..registry import get_registry
from ..textutil import ym_label
from .base import Plan, Table, MissingData, agg, count_cols, min_cell, fmt_won, fmt_num, measure_cols

CARD_KEYS = ["card_emd", "hub_startup_mashup", "hub_card_industry"]
LABELS = dict(get_registry().labels)
LABELS.update({"user_grp": "이용자 그룹", "ind_grp": "업종 그룹", "city": "시", "share": "비중(%)", "avg_ticket": "건당 금액(원)",
               "yoy": "전년 대비(%)", "score": "종합점수", "stores_per_1e8": "매출 1억원당 매장수", "amt_per_visit": "방문인구 1인당 소비(원)",
               "stores": "매장수", "visit_pop": "방문인구", "nation": "국적", "quarter": "분기", "year": "연도", "opened": "개업", "closed": "폐업",
               "stores_per_1k_visit": "방문인구 1,000명당 매장수", "demand": "수요 점수", "growth": "성장 점수", "tourist": "관광객 점수",
               "competition": "경쟁여유 점수", "footfall": "유동인구 점수", "rank": "순위", "raw_yoy": "전년 대비(%)", "raw_tourist": "관광객 비중(%)",
               "raw_density": "매출 1억원당 매장수", "raw_visit": "월평균 방문인구", "raw_amt": "카드 이용금액(원)", "user_cnt": "이용자수(월별 합산)", "ym": "연월", "island_rank_txt": "제주 전체 순위"})
FMT = {"use_amt": lambda v: f"{v:,.0f}", "user_cnt": lambda v: f"{v:,.0f}", "use_cnt": lambda v: f"{v:,.0f}",
       "avg_ticket": lambda v: f"{v:,.0f}", "share": lambda v: f"{v:.1f}%", "yoy": lambda v: f"{v:+.1f}%", "score": lambda v: f"{v:.1f}",
       "stores_per_1e8": lambda v: f"{v:.2f}", "stores_per_1k_visit": lambda v: f"{v:.2f}", "amt_per_visit": lambda v: f"{v:,.0f}",
       "demand": lambda v: f"{v:.0f}", "growth": lambda v: f"{v:.0f}", "tourist": lambda v: f"{v:.0f}", "competition": lambda v: f"{v:.0f}", "footfall": lambda v: f"{v:.0f}",
       "raw_yoy": lambda v: f"{v:+.1f}%", "raw_tourist": lambda v: f"{v:.1f}%", "raw_density": lambda v: f"{v:.2f}", "raw_visit": lambda v: f"{v:,.0f}", "raw_amt": lambda v: f"{v:,.0f}"}


def pick_card_dataset(store: DataStore, plan: Plan, need_region: bool = True) -> LoadedDataset:
    """카드 데이터 선택: 센터 카드(읍면동) > 허브 매쉬업(읍면동) > 허브 업종별(지역 없음, 지역 조건 없을 때만)."""
    for k in CARD_KEYS:
        ds = store.get(k)
        if ds is None:
            continue
        if need_region and plan.regions and "bjd" not in ds.df.columns:
            continue
        return ds
    raise MissingData(["card_emd"], "카드 이용 현황 데이터가 없습니다")


def pretty_period(v) -> str:
    """'202608' → '2026년 8월', '2026Q3' → '2026년 3분기', '2026' → '2026년'."""
    s = str(v)
    if len(s) == 6 and s.isdigit():
        return ym_label(s)
    if len(s) == 6 and s[4] == "Q" and s[:4].isdigit():
        return f"{s[:4]}년 {s[5]}분기"
    if len(s) == 4 and s.isdigit():
        return f"{s}년"
    return s


def secure(t: Table, top_n: int | None = None) -> Table:
    """표에 반출 검수 게이트를 적용(정렬·상위 N 절단은 검수 이후)하고 표시용 프레임을 만든다."""
    t.sdc = protect(t.df, t.dims, t.measures, t.count_cols, t.min_cell, t.rollups, max_rows=top_n, sort_by=t.sort_by, ascending=t.ascending)
    t.dims = list(t.sdc.dims)      # 범주 상향으로 차원이 줄었을 수 있음(예: 성별→전체 → 성별 차원 제거)
    refresh_display(t)
    return t


def refresh_display(t: Table) -> None:
    t.display = display_frame(t.sdc, LABELS, FMT)
    col = LABELS.get("ym", "ym")
    if col in t.display.columns:
        t.display[col] = t.display[col].map(pretty_period)


def make_table(name: str, df: pd.DataFrame, dims: list[str], ds: LoadedDataset, measures: list[str] | None = None,
               rollups=None, note: str = "", sort_by: str | None = None, ascending: bool = False, top_n: int | None = None, hidden: bool = False,
               order: list[str] | None = None) -> Table:
    meas = measures or measure_cols(df)
    g = agg(df, dims, meas)
    if order and dims:
        sort_by = None
    t = Table(name=name, df=g.reset_index(drop=True), dims=dims, measures=meas, count_cols=count_cols(ds, g), min_cell=min_cell(ds),
              rollups=list(rollups or []), note=note, sort_by=sort_by, ascending=ascending, hidden=hidden,
              source=df, source_key=ds.key, orig_dims=[d for d in dims if d in df.columns])
    secure(t, top_n=top_n)
    if order and dims and t.sdc is not None and dims[0] in t.sdc.table.columns:
        pos = {v: i for i, v in enumerate(order)}
        key = t.sdc.table[dims[0]].astype(str).map(lambda v: pos.get(v, 999)).values
        idx = sorted(range(len(key)), key=lambda i: key[i])
        t.sdc.table = t.sdc.table.iloc[idx].reset_index(drop=True)
        refresh_display(t)
    return t


def safe_series(t: Table, measure: str) -> pd.DataFrame:
    """SDC 통과 표에서 비공개 셀을 제외한 (dims + measure) 프레임."""
    df = t.sdc.table
    df = df[~df["_suppressed"]] if "_suppressed" in df.columns else df
    return df[[*t.dims, measure]].copy()


def kpi_block(df: pd.DataFrame, ds: LoadedDataset, prev: pd.DataFrame | None = None, matched_label: str = "") -> tuple[list[dict], bool]:
    """전체 합계 KPI(임계값 검사 포함). 반환: (kpis, suppressed)

    - 인원·건수 열이 하나도 없는데 임계값이 적용되는 데이터면 '검수 불가'를 KPI에 명시한다(수치는 표시하지 않음).
    - 전년 대비는 양쪽 모두 임계값을 넘을 때만 계산하고, 비교 기간(matched_label)을 라벨에 함께 적는다.
    """
    mc = min_cell(ds)
    cc = count_cols(ds, df)
    tot = {c: float(df[c].sum()) for c in measure_cols(df)}
    kpis: list[dict] = []
    if mc > 0 and not cc:
        kpis.append({"label": "집계 결과", "value": "검수 불가", "unit": "", "note": "인원·건수 열이 없어 반출 임계값을 확인할 수 없습니다(담당자 확인 필요)", "verified": False})
        return kpis, True
    small = any(tot.get(c, 0) < mc for c in cc) if mc > 0 else False
    if small:
        kpis.append({"label": "집계 결과", "value": f"비공개(<{mc})", "unit": "", "note": f"전체 인원·건수가 반출 기준({mc}) 미만이라 수치를 보여 드릴 수 없습니다", "min_cell": mc})
        return kpis, True

    def prev_ok() -> bool:
        if prev is None or prev.empty:
            return False
        return not (mc > 0 and any(float(prev[k].sum()) < mc for k in cc if k in prev.columns))

    def delta(c):
        if not prev_ok() or c not in prev.columns:
            return None
        p = float(prev[c].sum())
        if p <= 0:
            return None
        return round((tot[c] - p) / p * 100.0, 1)

    dl = f"작년 같은 기간보다({matched_label}만 비교)" if matched_label else "작년 같은 기간보다"
    if "use_amt" in tot:
        kpis.append({"label": "카드 이용금액", "value": fmt_won(tot["use_amt"]), "unit": "", "delta": delta("use_amt"), "delta_label": dl, "raw": tot["use_amt"]})
    if "use_cnt" in tot:
        kpis.append({"label": "이용건수", "value": fmt_num(tot["use_cnt"]) + "건", "unit": "", "delta": delta("use_cnt"), "delta_label": dl, "raw": tot["use_cnt"]})
    if "user_cnt" in tot:
        kpis.append({"label": "이용자수(월별 합산)", "value": fmt_num(tot["user_cnt"]) + "명", "unit": "", "delta": delta("user_cnt"), "delta_label": dl, "raw": tot["user_cnt"],
                     "note": "달마다 센 인원의 합계(같은 사람이 여러 달에 포함될 수 있음)"})
    if "use_amt" in tot and "use_cnt" in tot and tot["use_cnt"] > 0:
        at = tot["use_amt"] / tot["use_cnt"]
        pat = None
        if prev_ok() and float(prev["use_cnt"].sum()) > 0:
            pat = float(prev["use_amt"].sum()) / float(prev["use_cnt"].sum())
        kpis.append({"label": "건당 이용금액", "value": f"{at:,.0f}원", "unit": "", "delta": (round((at - pat) / pat * 100.0, 1)) if pat else None, "delta_label": dl, "raw": at})
    for c, lab, note in (("visit_pop", "방문인구(칸 합산)", "시간대·연령·성별 칸의 합계라 실제 인원과 다를 수 있음(상대 비교용)"),
                         ("flow_pop", "유동인구(칸 합산)", "칸 합계(상대 비교용)"), ("store_cnt", "매장수", "")):
        if c in tot:
            k = {"label": lab, "value": fmt_num(tot[c]) + ("명" if "pop" in c else "개"), "unit": "", "delta": delta(c), "delta_label": dl, "raw": tot[c]}
            if note:
                k["note"] = note
            kpis.append(k)
    return kpis, False


def top_entry(t: Table, measure: str, dim: str) -> tuple[str, float] | None:
    s = safe_series(t, measure)
    if s.empty:
        return None
    row = s.sort_values(measure, ascending=False).iloc[0]
    return str(row[dim]), float(row[measure])


def region_scope_note(plan: Plan) -> str:
    if plan.region_scope == "all":
        return "제주도 전체"
    return f"{plan.region_label}"


def josa(word: str, pair: str = "으로/로") -> str:
    """받침에 따라 조사 선택: josa('억원','으로/로') → '으로', josa('카페','은/는') → '는'."""
    a, b = pair.split("/")
    if not word:
        return b
    ch = word[-1]
    code = ord(ch)
    if 0xAC00 <= code <= 0xD7A3:
        jong = (code - 0xAC00) % 28
        if jong == 0:
            return b
        if pair == "으로/로" and jong == 8:
            return b
        return a
    if ch.isdigit():
        return a if ch in "013678" else b
    return a


def hidden_note(t: Table) -> str:
    """비공개·병합이 있는 표의 문장에 붙이는 단서."""
    if t.sdc is not None and t.sdc.has_hidden:
        return "(가린 칸 제외 기준)"
    return ""


def scope_title(plan, sep: str = " ") -> str:
    """제목용 '동네 업종' 표현. 업종이 없으면 '모든 업종'('제주시 전체 전체 업종' 같은 중복을 피함)."""
    ind = plan.industry_label if plan.industries else "모든 업종"
    return f"{plan.region_label}{sep}{ind}"


def share_sentence(t: Table, measure: str = "use_amt", prefix: str = "이용금액 비중") -> str:
    """표의 공개 행 기준 비중 문장. 병합된 범주('외국인+법인(병합)')는 그 이름 그대로 적어 오해를 막는다.
    가린 행이 있으면 '공개된 N개 그룹 기준'을 밝히고 가린 그룹명을 적는다."""
    df = t.sdc.table
    dim = t.dims[0]
    pub = df[~df["_suppressed"]] if "_suppressed" in df.columns else df
    hid = df[df["_suppressed"]] if "_suppressed" in df.columns else df.iloc[0:0]
    tot = float(pd.to_numeric(pub[measure], errors="coerce").sum()) if len(pub) else 0.0
    if tot <= 0 or len(pub) == 0:
        return ""
    parts = []
    for _, r in pub.sort_values(measure, ascending=False).iterrows():
        parts.append(f"{r[dim]} {float(r[measure]) / tot * 100:.1f}%")
    txt = f"{prefix}: " + ", ".join(parts)
    if len(hid):
        names = ", ".join(str(v) for v in hid[dim].astype(str).tolist()[:4])
        txt += f" (공개된 {len(pub)}개 그룹 기준 — {names}{'은(는)' if names else ''} 개인정보 보호로 가려 비중 계산에서 제외)"
    return txt + "."


def tourist_share_sentence(t: Table, measure: str = "use_amt") -> str:
    """관광객(내국인 관광객+외국인) vs 제주도민 비중 — 병합 라벨·가린 행을 반영."""
    df = t.sdc.table
    dim = t.dims[0]
    pub = df[~df["_suppressed"]] if "_suppressed" in df.columns else df
    hid = df[df["_suppressed"]] if "_suppressed" in df.columns else df.iloc[0:0]
    tot = float(pd.to_numeric(pub[measure], errors="coerce").sum()) if len(pub) else 0.0
    if tot <= 0:
        return ""
    labels = pub[dim].astype(str).tolist()
    vals = pd.to_numeric(pub[measure], errors="coerce").fillna(0).tolist()
    tour = sum(v for l, v in zip(labels, vals) if ("관광객" in l or "외국인" in l) and "제주도민" not in l)
    resi = sum(v for l, v in zip(labels, vals) if "제주도민" in l and "관광객" not in l and "외국인" not in l)
    mixed = [l for l in labels if "제주도민" in l and ("관광객" in l or "외국인" in l)]
    merged = [l for l in labels if "(병합)" in l or "(기타 합계)" in l]
    if mixed:
        return f"이용금액 비중: " + ", ".join(f"{l} {v / tot * 100:.1f}%" for l, v in zip(labels, vals)) + " (일부 그룹이 합쳐져 관광객·도민을 나누어 계산할 수 없습니다)."
    txt = f"이용금액 기준 관광객(내국인 관광객+외국인) 비중은 {tour / tot * 100:.1f}%, 제주도민 비중은 {resi / tot * 100:.1f}%"
    rest = tot - tour - resi
    if rest / tot * 100 >= 0.05:
        txt += f", 그 외(법인·미상)는 {rest / tot * 100:.1f}%"
    txt += "입니다."
    if merged:
        txt += f" ({', '.join(merged)}은(는) 개인정보 보호를 위해 합친 그룹)"
    if len(hid):
        txt += f" (가린 그룹 {', '.join(hid[dim].astype(str).tolist()[:3])} 제외)"
    return txt

"""T5. 유동인구 — 지역의 거주·근무·방문 인구 구조와 (카드 데이터가 있으면) 방문인구 1인당 소비."""
from __future__ import annotations

import pandas as pd

from .base import Plan, TemplateResult, ChartSpec, Finding, Table, MissingData, filter_frame, coverage_label, standard_rollups, region_rollup, data_used_entry, agg, min_cell, fmt_num
from .common import make_table, kpi_block, safe_series, secure, pick_card_dataset, pretty_period, hidden_note

KEY = "footfall"
NAME = "유동인구 분석"
DESCRIPTION = "지역의 유동인구(거주·근무·방문) 월별 추이, 연령·성별 구성, 시간대 분포, 카드 소비와의 결합(방문인구 1인당 소비)"
NEEDS = ["footfall_emd"]
PARAMS = {"regions": "지역", "period": "기간", "industries": "소비 결합 시 업종"}

_POPS = ["resd_pop", "work_pop", "visit_pop", "flow_pop"]


def run(store, plan: Plan) -> TemplateResult:
    ds = store.first_available(["footfall_emd", "hub_footfall_api"])
    if ds is None:
        raise MissingData(["footfall_emd"], "유동인구 데이터가 없습니다")
    base = ds.df
    df = filter_frame(base, plan, use_industry=False)
    pops = [c for c in _POPS if c in df.columns]
    plabel = coverage_label(base, plan)
    res = TemplateResult(title=f"{plan.region_label} 유동인구 분석", subtitle=f"기간: {plabel} · 데이터: {ds.name}", plan=plan)
    res.data_used.append(data_used_entry(ds, plan))
    if df.empty or not pops:
        res.ok = False
        res.findings.append(Finding("조건에 해당하는 유동인구 데이터가 없습니다.", "warn"))
        return res
    res.kpis, suppressed = kpi_block(df, ds)
    if suppressed:
        return res
    main = "visit_pop" if "visit_pop" in pops else pops[0]
    multi_region = "bjd" in df.columns and df["bjd"].nunique() > 1

    if "ym" in df.columns and df["ym"].nunique() > 1:
        t = make_table("월별 유동인구", df, ["ym"], ds, measures=pops, rollups=standard_rollups("ym_quarter"), sort_by="ym", ascending=True)
        res.tables.append(t)
        res.charts.append(ChartSpec("multiline_wide", t.name, "ym", pops, "월별 유동인구(거주·근무·방문)", filename="pop_trend"))
        s = safe_series(t, main)
        if len(s) >= 2:
            peak = s.sort_values(main, ascending=False).iloc[0]
            unit = "달" if not t.sdc.rolled else "기간"
            res.findings.append(Finding(f"방문인구가 가장 많은 {unit}은 {pretty_period(peak['ym'])}({fmt_num(peak[main])}명)입니다. {hidden_note(t)}".strip(), "key"))
    if "age_se" in df.columns and "gender_se" in df.columns:
        sub = df[(df["age_se"] != "미상") & (df["gender_se"] != "미상")]
        if len(sub):
            t = make_table("연령대·성별 방문인구", sub, ["age_se", "gender_se"], ds, measures=[main], rollups=standard_rollups("age_band", "gender_all"), sort_by="age_se", ascending=True)
            res.tables.append(t)
            res.charts.append(ChartSpec("groupbar", t.name, "age_se", main, "연령대·성별 방문인구", series="gender_se", filename="pop_age"))
            s = safe_series(t, main)
            if len(s):
                by = s.groupby("age_se")[main].sum().sort_values(ascending=False)
                res.findings.append(Finding(f"방문인구는 {by.index[0]} 비중이 가장 높습니다({by.iloc[0] / by.sum() * 100:.1f}%). {hidden_note(t)}".strip(), "info"))
    if "time_se" in df.columns and df["time_se"].nunique() > 1:
        t = make_table("시간대별 방문인구", df, ["time_se"], ds, measures=[main], rollups=standard_rollups("time_band"), sort_by="time_se", ascending=True)
        res.tables.append(t)
        res.charts.append(ChartSpec("bar", t.name, "time_se", main, "시간대별 방문인구", filename="pop_time"))
    if multi_region:
        t = make_table(f"지역별 방문인구 상위 {plan.top_n}", df, ["bjd"], ds, measures=pops, rollups=[region_rollup()], sort_by=main, top_n=plan.top_n)
        res.tables.append(t)
        res.charts.append(ChartSpec("barh", t.name, "bjd", main, "지역별 방문인구 상위", filename="pop_region"))

    # 카드 소비 결합 (지역이 2개 이상일 때 비교 지표로)
    try:
        cds = pick_card_dataset(store, plan)
    except MissingData:
        cds = None
    if cds is not None and "bjd" in cds.df.columns and "bjd" in df.columns:
        cdf = filter_frame(cds.df, plan)
        if not cdf.empty:
            ca = agg(cdf, ["bjd"], ["use_amt", *[c for c in ("use_cnt", "user_cnt") if c in cdf.columns]])
            fa = agg(df, ["bjd"], [main])
            m = ca.merge(fa, on="bjd", how="inner")
            m = m[m[main] > 0]
            if len(m):
                m["amt_per_visit"] = m["use_amt"] / m[main]
                tv = Table("방문인구 1인당 카드 소비", m.reset_index(drop=True), ["bjd"],
                           ["use_amt", main, "amt_per_visit"], count_cols=[c for c in ("use_cnt", "user_cnt") if c in m.columns] + [main], min_cell=max(min_cell(ds), min_cell(cds)), sort_by="amt_per_visit",
                           note="방문인구 1인당 소비 = 기간 카드 이용금액 ÷ 기간 방문인구(칸 합산). 지역 간 상대 비교용 지표입니다.")
                secure(tv)
                res.tables.append(tv)
                res.data_used.append(data_used_entry(cds, plan))
                if len(m) >= 2:
                    res.charts.append(ChartSpec("barh", tv.name, "bjd", "amt_per_visit", f"방문인구 1인당 {plan.industry_label} 카드 소비(원)", filename="amt_per_visit"))
                best = tv.sdc.table.dropna(subset=["amt_per_visit"]).sort_values("amt_per_visit", ascending=False)
                if len(best) >= 2:
                    res.findings.append(Finding(f"방문인구 1인당 {plan.industry_label} 소비가 가장 높은 지역은 {best.iloc[0]['bjd']}({best.iloc[0]['amt_per_visit']:,.0f}원)입니다.", "key"))
                elif len(best) == 1:
                    res.findings.append(Finding(f"{best.iloc[0]['bjd']}의 방문인구 1인당 {plan.industry_label} 카드 소비는 {best.iloc[0]['amt_per_visit']:,.0f}원입니다(지역 간 비교용 지표).", "info"))

    res.method = "통신 기반 유동인구를 지역·기간으로 필터링해 월별·연령·성별·시간대별로 합산했습니다. 카드 데이터가 있으면 지역별로 결합해 1인당 소비를 계산했습니다."
    res.caveats += ["유동인구는 통신사 기지국 기반 추정치로 실제 인원과 차이가 있을 수 있습니다.",
                    "방문인구 합계는 시간대·연령·성별 칸을 모두 더한 값이라 실제 방문자 수보다 클 수 있습니다. 지역·기간 간 상대 비교에 사용하세요."]
    if ds.origin == "sample":
        res.caveats.insert(0, "※ 현재 결과는 연습용 가짜(합성) 데이터입니다.")
    return res

"""분석 템플릿 카탈로그 — 플래너(LLM/규칙)와 UI가 공통으로 참조."""
from __future__ import annotations

from . import market_summary, time_pattern, region_compare, tourist, footfall, competition, site_score, navigator
from .base import Plan, TemplateResult, Table, ChartSpec, Finding, MissingData

_MODULES = [market_summary, time_pattern, region_compare, tourist, footfall, competition, site_score, navigator]

CATALOG: dict[str, dict] = {
    m.KEY: {"key": m.KEY, "name": m.NAME, "description": m.DESCRIPTION, "needs": m.NEEDS, "params": m.PARAMS, "run": m.run}
    for m in _MODULES
}


def run_template(key: str, store, plan: Plan) -> TemplateResult:
    if key not in CATALOG:
        raise KeyError(f"알 수 없는 템플릿: {key}")
    return CATALOG[key]["run"](store, plan)


def catalog_for_llm() -> list[dict]:
    return [{"key": k, "name": v["name"], "description": v["description"], "params": v["params"]} for k, v in CATALOG.items()]


__all__ = ["CATALOG", "run_template", "catalog_for_llm", "Plan", "TemplateResult", "Table", "ChartSpec", "Finding", "MissingData"]

"""T1. 상권 요약 — 지역·업종·기간의 카드 소비 규모, 추이, 업종 구성, 이용자 구성."""
from __future__ import annotations

import pandas as pd

from ..textutil import add_months, period_label
from .base import Plan, TemplateResult, ChartSpec, Finding, filter_frame, yoy_frames, coverage_label, standard_rollups, region_rollup, data_used_entry, fmt_won, pct, min_cell, count_cols
from .common import scope_title, pick_card_dataset, make_table, kpi_block, safe_series, top_entry, pretty_period, josa, hidden_note, tourist_share_sentence

KEY = "market_summary"
NAME = "상권 요약"
DESCRIPTION = "특정 지역(법정동·읍면·권역)과 업종의 카드 소비 규모·월별 추이·업종 구성·이용자(도민/관광객/외국인, 연령·성별) 구성을 요약"
NEEDS = ["card_emd"]
PARAMS = {"regions": "법정동/읍면 목록(비우면 전체)", "industries": "업종 키워드(비우면 전체)", "period": "기간(기본 최근 12개월)", "yoy": "전년 동기 비교 여부"}


def run(store, plan: Plan) -> TemplateResult:
    ds = pick_card_dataset(store, plan)
    base = ds.df
    df = filter_frame(base, plan)
    plabel = coverage_label(base, plan)
    res = TemplateResult(title=f"{scope_title(plan)} 상권 요약", subtitle=f"기간: {plabel} · 데이터: {ds.name}", plan=plan)
    res.data_used.append(data_used_entry(ds, plan))
    if df.empty:
        res.ok = False
        avail = f"{pretty_period(base['ym'].min())}~{pretty_period(base['ym'].max())}" if "ym" in base.columns and len(base) else "-"
        res.findings.append(Finding(f"조건에 해당하는 데이터가 없습니다. 이 PC에 있는 자료 기간은 {avail}입니다. 지역·업종·기간을 바꿔 보세요.", "warn"))
        return res

    # 전년 동기(양쪽 데이터가 있는 달만 부분 비교)
    cur_m, prev, matched = yoy_frames(base, plan)
    matched_label = ""
    if prev is not None and matched:
        matched_label = f"{period_label(matched[0], matched[-1])} {len(matched)}개월"
    kpis, suppressed = kpi_block(cur_m if prev is not None else df, ds, prev, matched_label)
    if prev is not None and matched and not suppressed:
        tot_kpis, _ = kpi_block(df, ds, None)
        for k, tk in zip(kpis, tot_kpis):
            if k["label"] == tk["label"]:
                k["value"] = tk["value"]
                k["raw"] = tk.get("raw")
        if len(matched) < df["ym"].nunique():
            res.caveats.append(f"전년 동기 대비 증감률은 양쪽 모두 데이터가 있는 {len(matched)}개월({period_label(matched[0], matched[-1])}) 기준입니다. 합계는 요청 기간 전체 기준입니다.")
    res.kpis = kpis
    if suppressed:
        if any(k.get("verified") is False for k in kpis):
            res.findings.append(Finding("이 데이터에는 인원·건수 열이 없어 반출 기준(10 미만 여부)을 자동으로 확인할 수 없습니다. 담당자 확인 전에는 수치를 보여 드리지 않습니다.", "warn"))
        else:
            mc = max((k.get("min_cell") or 0) for k in kpis) or 10
            res.findings.append(Finding(f"조건 범위의 전체 이용 인원·건수가 반출 기준({mc}명) 미만이라 수치를 보여 드릴 수 없습니다. 기간을 늘리거나 지역·업종 범위를 넓혀 주세요.", "warn"))
        return res

    multi_month = df["ym"].nunique() > 1
    # 1) 월별 추이
    if multi_month:
        t = make_table("월별 추이", df, ["ym"], ds, rollups=standard_rollups("ym_quarter"), sort_by="ym", ascending=True)
        res.tables.append(t)
        res.charts.append(ChartSpec("line", t.name, "ym", "use_amt", f"월별 카드 이용금액 — {plan.region_label} {plan.industry_label}", filename="trend"))
        s = safe_series(t, "use_amt")
        if len(s) >= 2:
            unit = "달" if not t.sdc.rolled else "기간"
            first, last = float(s.iloc[0]["use_amt"]), float(s.iloc[-1]["use_amt"])
            peak = s.sort_values("use_amt", ascending=False).iloc[0]
            low = s.sort_values("use_amt", ascending=True).iloc[0]
            txt = f"기간 중 이용금액이 가장 큰 {unit}은 {pretty_period(peak['ym'])}({fmt_won(peak['use_amt'])}), 가장 작은 {unit}은 {pretty_period(low['ym'])}({fmt_won(low['use_amt'])})입니다."
            # 첫 달·끝 달 단순 비교는 계절 차이를 성장으로 오해하게 하므로 쓰지 않고, 12개월 전 같은 달이 있을 때만 비교한다
            if not t.sdc.rolled and "ym" in base.columns:
                last_ym = str(s.iloc[-1]["ym"])
                prev_ym = add_months(last_ym, -12)
                prev_rows = base[(base["ym"] == prev_ym)]
                prev_rows = filter_frame(prev_rows, plan, use_period=False) if len(prev_rows) else prev_rows
                cnt_ok = all(float(prev_rows[c].sum()) >= min_cell(ds) for c in count_cols(ds, prev_rows)) if len(prev_rows) else False
                if len(prev_rows) and cnt_ok:
                    pv = float(prev_rows["use_amt"].sum())
                    ch = pct(last, pv)
                    if ch is not None:
                        txt += f" {pretty_period(last_ym)}은 1년 전 같은 달({pretty_period(prev_ym)})보다 {ch:+.1f}%입니다."
            res.findings.append(Finding((txt + " " + hidden_note(t)).strip(), "key"))

    # 2) 업종 구성 (세부 업종 상위 N)
    if "ksic_nm" in df.columns and df["ksic_nm"].nunique() > 1:
        t = make_table(f"업종별 상위 {plan.top_n}", df, ["ksic_nm"], ds, rollups=standard_rollups("industry_other"), sort_by="use_amt", top_n=plan.top_n)
        res.tables.append(t)
        res.charts.append(ChartSpec("barh", t.name, "ksic_nm", "use_amt", f"업종별 카드 이용금액 상위 {plan.top_n}", filename="industry_top"))
        te = top_entry(t, "use_amt", "ksic_nm")
        if te:
            tot = float(df["use_amt"].sum())
            res.findings.append(Finding(f"업종별로는 '{te[0]}'의 이용금액이 {fmt_won(te[1])}{josa(fmt_won(te[1]), '으로/로')} 가장 크며 전체의 {te[1] / tot * 100:.1f}%를 차지합니다.", "key"))
    applied = sorted(df["ksic_nm"].astype(str).unique().tolist()) if "ksic_nm" in df.columns else []
    if plan.industries and applied and len(applied) <= 12:
        res.caveats.append("이 분석에 포함된 업종명: " + ", ".join(applied))
    if "ind_grp" in df.columns and df["ind_grp"].nunique() > 1:
        t = make_table("업종 그룹별", df, ["ind_grp"], ds, sort_by="use_amt", hidden=True)
        res.tables.append(t)
        res.charts.append(ChartSpec("donut", t.name, "ind_grp", "use_amt", "업종 그룹별 이용금액 비중", filename="industry_group"))

    # 3) 이용자 구성
    if "user_grp" in df.columns:
        t = make_table("이용자 그룹별", df, ["user_grp"], ds, sort_by="use_amt")
        res.tables.append(t)
        res.charts.append(ChartSpec("bar", t.name, "user_grp", "use_amt", "이용자 그룹별 카드 이용금액", filename="user_group"))
        txt = tourist_share_sentence(t)
        if txt:
            res.findings.append(Finding(txt, "key"))
        if multi_month and df["user_grp"].nunique() > 1:
            t2 = make_table("이용자 그룹별 월별 추이", df, ["ym", "user_grp"], ds, rollups=standard_rollups("ym_quarter"), sort_by="ym", ascending=True, hidden=True)
            res.tables.append(t2)
            res.charts.append(ChartSpec("multiline", t2.name, "ym", "use_amt", "이용자 그룹별 월별 이용금액", series="user_grp", filename="user_group_trend"))
        fr = df[df["user_grp"] == "외국인"] if "user_se" in df.columns else pd.DataFrame()
        if len(fr) and fr["user_se"].nunique() > 1:
            t3 = make_table("외국인 국적별", fr, ["user_se"], ds, rollups=standard_rollups("nation_foreign"), sort_by="use_amt")
            res.tables.append(t3)
            res.charts.append(ChartSpec("bar", t3.name, "user_se", "use_amt", "외국인 국적별 카드 이용금액", filename="nation"))

    # 4) 연령대 × 성별
    if "age_se" in df.columns and "gender_se" in df.columns:
        sub = df[(df["age_se"] != "미상") & (df["gender_se"] != "미상")]
        if len(sub):
            t = make_table("연령대·성별", sub, ["age_se", "gender_se"], ds, rollups=standard_rollups("age_band", "gender_all"), sort_by="age_se", ascending=True)
            res.tables.append(t)
            res.charts.append(ChartSpec("groupbar", t.name, "age_se", "use_amt", "연령대·성별 카드 이용금액", series="gender_se", filename="age_gender"))
            s = safe_series(t, "use_amt")
            if len(s):
                byage = s.groupby("age_se")["use_amt"].sum().sort_values(ascending=False)
                res.findings.append(Finding(f"연령대별로는 {byage.index[0]}의 이용금액이 가장 큽니다({byage.iloc[0] / byage.sum() * 100:.1f}%). {hidden_note(t)}".strip(), "info"))

    # 5) 지역이 여러 개면 지역별
    if "bjd" in df.columns and df["bjd"].nunique() > 1:
        t = make_table(f"법정동·읍면별 상위 {plan.top_n}", df, ["bjd"], ds, rollups=[region_rollup()], sort_by="use_amt", top_n=plan.top_n)
        res.tables.append(t)
        res.charts.append(ChartSpec("barh", t.name, "bjd", "use_amt", f"법정동·읍면별 이용금액 상위 {plan.top_n}", filename="region_top"))
        te = top_entry(t, "use_amt", "bjd")
        if te:
            res.findings.append(Finding(f"지역별로는 {te[0]}의 이용금액이 {fmt_won(te[1])}{josa(fmt_won(te[1]), '으로/로')} 가장 큽니다.", "info"))

    # 핵심 문장 (맨 앞)
    for k in res.kpis:
        if k.get("label") == "카드 이용금액":
            if k.get("delta") is not None:
                res.findings.insert(0, Finding(f"{plabel} {plan.region_label} {plan.industry_label} 카드 이용금액은 {k['value']}이며, 작년 같은 기간과 비교할 수 있는 {matched_label} 기준으로는 {k['delta']:+.1f}%입니다.", "key"))
            else:
                res.findings.insert(0, Finding(f"{plabel} {plan.region_label} {plan.industry_label} 카드 이용금액은 {k['value']}입니다.", "key"))
            break

    res.method = ("센터 카드 이용 현황 데이터를 지역·업종·기간 조건으로 필터링한 뒤 이용자수·이용건수·이용금액을 합산했습니다. "
                  "모든 표는 반출 기준(셀당 인원·건수 ≥ 임계값, 역산 방지)을 자동 검수했으며, 작은 셀은 상위 범주로 합치거나 비공개 처리했습니다.")
    res.caveats += ["카드 데이터는 특정 카드사 가맹점 결제 기준으로 현금·타사 결제는 포함되지 않습니다.",
                    "이용자구분(제주도민/내국인/외국인)은 카드 발급 정보 기준의 추정 구분입니다.",
                    "이용자수는 달마다 센 인원의 합계이며 고유 인원(순방문자)이 아닙니다."]
    if ds.origin == "sample":
        res.caveats.insert(0, "※ 현재 결과는 명세 구조를 따른 연습용 가짜(합성) 데이터입니다. 실제 센터 데이터로 교체해 다시 실행하세요.")
    return res

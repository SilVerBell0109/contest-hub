"""T4. 관광객 소비 — 도민/내국인 관광객/외국인(국적별) 소비 추이와 업종·지역 구성."""
from __future__ import annotations

import pandas as pd

from .base import Plan, TemplateResult, ChartSpec, Finding, filter_frame, coverage_label, standard_rollups, region_rollup, data_used_entry, fmt_won, pct
from .common import share_sentence, pick_card_dataset, make_table, kpi_block, safe_series, top_entry, pretty_period, josa, hidden_note

KEY = "tourist"
NAME = "관광객 소비"
DESCRIPTION = "제주도민·내국인 관광객·외국인(중국/일본/동남아 등) 카드 소비의 월별 추이, 국적 구성, 외국인이 많이 쓰는 업종·지역"
NEEDS = ["card_emd"]
PARAMS = {"regions": "지역(비우면 전체)", "industries": "업종(비우면 전체)", "period": "기간", "focus": "관심 그룹(외국인/중국/일본/내국인 관광객)"}


def run(store, plan: Plan) -> TemplateResult:
    ds = pick_card_dataset(store, plan)
    base = ds.df
    if "user_grp" not in base.columns:
        raise ValueError("이용자구분(user_se) 컬럼이 있는 카드 데이터가 필요합니다")
    df = filter_frame(base, plan)
    focus = plan.options.get("focus", "")
    plabel = coverage_label(base, plan)
    ind = plan.industry_label if plan.industries else "모든 업종"
    res = TemplateResult(title=f"{plan.region_label} {ind} 관광객 소비 분석", subtitle=f"기간: {plabel} · 데이터: {ds.name}", plan=plan)
    res.data_used.append(data_used_entry(ds, plan))
    if df.empty:
        res.ok = False
        res.findings.append(Finding("조건에 해당하는 데이터가 없습니다.", "warn"))
        return res
    res.kpis, suppressed = kpi_block(df, ds)
    if suppressed:
        return res

    # 그룹별 합계
    t = make_table("이용자 그룹별", df, ["user_grp"], ds, sort_by="use_amt")
    res.tables.append(t)
    res.charts.append(ChartSpec("bar", t.name, "user_grp", "use_amt", "이용자 그룹별 카드 이용금액", filename="group"))
    txt = share_sentence(t, "use_amt", "이용금액 비중")
    if txt:
        res.findings.append(Finding(txt, "key"))

    # 월별 추이(그룹별)
    if df["ym"].nunique() > 1:
        t2 = make_table("이용자 그룹별 월별 추이", df, ["ym", "user_grp"], ds, rollups=standard_rollups("ym_quarter"), sort_by="ym", ascending=True)
        res.tables.append(t2)
        res.charts.append(ChartSpec("multiline", t2.name, "ym", "use_amt", "이용자 그룹별 월별 카드 이용금액", series="user_grp", filename="group_trend"))
        s2 = safe_series(t2, "use_amt")
        fr = s2[s2["user_grp"] == "외국인"].sort_values("ym")
        if len(fr) >= 2:
            peak = fr.sort_values("use_amt", ascending=False).iloc[0]
            unit = "달" if not t2.sdc.rolled else "기간"
            ch = pct(float(fr.iloc[-1]["use_amt"]), float(fr.iloc[0]["use_amt"]))
            txt = f"외국인 소비가 가장 많았던 {unit}은 {pretty_period(peak['ym'])}({fmt_won(peak['use_amt'])})입니다."
            if ch is not None and not t2.sdc.rolled:
                txt += f" {pretty_period(fr.iloc[-1]['ym'])}은 {pretty_period(fr.iloc[0]['ym'])}보다 {ch:+.1f}%입니다."
            res.findings.append(Finding((txt + " " + hidden_note(t2)).strip(), "key"))

    # 외국인 국적
    fr = df[df["user_grp"] == "외국인"]
    if len(fr) and "user_se" in fr.columns and fr["user_se"].nunique() > 1:
        t3 = make_table("외국인 국적별", fr, ["user_se"], ds, rollups=standard_rollups("nation_foreign"), sort_by="use_amt")
        res.tables.append(t3)
        res.charts.append(ChartSpec("bar", t3.name, "user_se", "use_amt", "외국인 국적별 카드 이용금액", filename="nation"))
        te = top_entry(t3, "use_amt", "user_se")
        if te:
            s3 = safe_series(t3, "use_amt")
            ftot = float(s3["use_amt"].sum())        # 공개된 국적 합계 기준(가린 국적의 금액이 비율로 새지 않게)
            hid3 = t3.sdc.has_hidden
            res.findings.append(Finding(f"외국인 중에서는 {te[0]} 이용금액이 {fmt_won(te[1])}{josa(fmt_won(te[1]), '으로/로')} 가장 큽니다"
                                        + (f"(공개된 국적 합계의 {te[1] / ftot * 100:.1f}%)." if ftot > 0 and hid3 else f"(외국인 소비의 {te[1] / ftot * 100:.1f}%)." if ftot > 0 else ".")
                                        + (" " + hidden_note(t3) if hid3 else ""), "key"))
        if fr["ym"].nunique() > 1:
            t4 = make_table("국적별 월별 추이", fr, ["ym", "user_se"], ds, rollups=standard_rollups("ym_quarter", "nation_foreign"), sort_by="ym", ascending=True, hidden=True)
            res.tables.append(t4)
            res.charts.append(ChartSpec("multiline", t4.name, "ym", "use_amt", "외국인 국적별 월별 이용금액", series="user_se", filename="nation_trend"))

    # 관광객(외국인+내국인 관광객)이 많이 쓰는 업종·지역
    tour = df[df["user_grp"].isin(["외국인", "내국인 관광객"])]
    if focus and "중국" in focus and "user_se" in df.columns:
        tour = df[df["user_se"].astype(str).str.contains("중국")]
    elif focus and "일본" in focus and "user_se" in df.columns:
        tour = df[df["user_se"].astype(str).str.contains("일본")]
    elif focus and "외국" in focus:
        tour = df[df["user_grp"] == "외국인"]
    label = (focus + "인" if focus in ("중국", "일본") else focus) or "관광객(내국인 관광객+외국인)"
    if len(tour) and "ksic_nm" in tour.columns and tour["ksic_nm"].nunique() > 1:
        t5 = make_table(f"{label} 이용 업종 상위 {plan.top_n}", tour, ["ksic_nm"], ds, rollups=standard_rollups("industry_other"), sort_by="use_amt", top_n=plan.top_n)
        res.tables.append(t5)
        res.charts.append(ChartSpec("barh", t5.name, "ksic_nm", "use_amt", f"{label} 이용금액 상위 업종", filename="tour_industry"))
        te = top_entry(t5, "use_amt", "ksic_nm")
        if te:
            res.findings.append(Finding(f"{label}이 가장 많이 쓰는 업종은 '{te[0]}'({fmt_won(te[1])})입니다.", "info"))
    if len(tour) and "bjd" in tour.columns and tour["bjd"].nunique() > 1:
        t6 = make_table(f"{label} 이용 지역 상위 {plan.top_n}", tour, ["bjd"], ds, rollups=[region_rollup()], sort_by="use_amt", top_n=plan.top_n)
        res.tables.append(t6)
        res.charts.append(ChartSpec("barh", t6.name, "bjd", "use_amt", f"{label} 이용금액 상위 지역", filename="tour_region"))
        te = top_entry(t6, "use_amt", "bjd")
        if te:
            res.findings.append(Finding(f"{label} 소비가 가장 집중된 지역은 {te[0]}({fmt_won(te[1])})입니다.", "key"))

    res.method = "이용자구분을 제주도민/내국인 관광객/외국인(국적)으로 그룹화해 월별·업종별·지역별로 합산했습니다. 국적별 작은 셀은 '기타 외국인 합계'로 합쳤습니다."
    res.caveats += ["이용자구분은 카드 발급 정보에 따른 추정이며 해외 간편결제 등은 포함 범위가 다를 수 있습니다(데이터 명세서 참조).",
                    "내국인 관광객과 제주도민 구분은 카드사 기준(거주지)입니다."]
    if ds.origin == "sample":
        res.caveats.insert(0, "※ 현재 결과는 연습용 가짜(합성) 데이터입니다.")
    return res

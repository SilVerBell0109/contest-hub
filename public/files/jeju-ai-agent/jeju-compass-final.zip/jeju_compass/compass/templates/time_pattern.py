"""T2. 시간대·요일 패턴 — 손님이 몰리는 시간대와 요일(공휴일 포함)."""
from __future__ import annotations

from .base import Plan, TemplateResult, ChartSpec, Finding, MissingData, filter_frame, coverage_label, standard_rollups, data_used_entry
from .common import scope_title, make_table, kpi_block, safe_series, hidden_note

KEY = "time_pattern"
NAME = "시간대·요일 패턴"
DESCRIPTION = "특정 지역·업종의 시간대별·요일별(공휴일 포함) 카드 이용 분포 — 피크 시간대, 평일/주말 비중"
NEEDS = ["card_time", "card_dow"]
PARAMS = {"regions": "법정동/읍면 목록", "industries": "업종 키워드", "period": "기간"}

_DOW_ORDER = ["월", "화", "수", "목", "금", "토", "일", "공휴일", "평일", "주말·공휴일"]
_WEEKEND = {"토", "일", "공휴일", "주말·공휴일"}


def run(store, plan: Plan) -> TemplateResult:
    ds_time = store.get("card_time")
    ds_dow = store.get("card_dow")
    if ds_time is None and ds_dow is None:
        raise MissingData(["card_time", "card_dow"], "시간대/요일별 카드 이용 현황 데이터가 없습니다")
    names = " + ".join(d.name for d in (ds_time, ds_dow) if d is not None)
    anyds = ds_time or ds_dow
    plabel = coverage_label(anyds.df, plan)
    res = TemplateResult(title=f"{scope_title(plan)} 시간대·요일 패턴", subtitle=f"기간: {plabel} · 데이터: {names}", plan=plan)
    produced = False

    if ds_time is not None:
        df = filter_frame(ds_time.df, plan)
        res.data_used.append(data_used_entry(ds_time, plan))
        if df.empty:
            res.findings.append(Finding("시간대 데이터에 조건에 맞는 행이 없습니다.", "warn"))
        else:
            kpis, suppressed = kpi_block(df, ds_time)
            for k in kpis:
                k["note"] = ((k.get("note") + " · ") if k.get("note") else "") + "시간대 자료 기준(상권 요약의 숫자와 조금 다를 수 있음)"
            if not res.kpis:
                res.kpis = kpis
            if not suppressed:
                t = make_table("시간대별", df, ["time_se"], ds_time, rollups=standard_rollups("time_band"), sort_by="time_se", ascending=True)
                res.tables.append(t)
                produced = True
                res.charts.append(ChartSpec("bar", t.name, "time_se", "use_amt", "시간대별 카드 이용금액", filename="time_slot"))
                s = safe_series(t, "use_amt")
                if len(s) >= 2:
                    tot = float(s["use_amt"].sum())
                    top3 = s.sort_values("use_amt", ascending=False).head(min(3, len(s)))
                    if t.sdc.has_hidden or len(s) <= 3:
                        txt = f"손님이 가장 많은 시간대는 {', '.join(top3['time_se'].astype(str))} 순입니다. {hidden_note(t)}".strip()
                    else:
                        txt = f"손님이 가장 많은 시간대는 {', '.join(top3['time_se'].astype(str))} 순이며, 이 3개 시간대가 전체 이용금액의 {top3['use_amt'].sum() / tot * 100:.1f}%를 차지합니다."
                    res.findings.append(Finding(txt, "key"))
                if "user_grp" in df.columns and df["user_grp"].nunique() > 1:
                    t2 = make_table("시간대·이용자 그룹별", df, ["time_se", "user_grp"], ds_time, rollups=standard_rollups("time_band"), sort_by="time_se", ascending=True, hidden=True)
                    res.tables.append(t2)
                    res.charts.append(ChartSpec("multiline", t2.name, "time_se", "use_amt", "시간대별 이용금액 — 이용자 그룹", series="user_grp", filename="time_slot_group"))
            else:
                res.findings.append(Finding("시간대 데이터의 전체 인원·건수가 반출 기준(10명) 미만이라 수치를 보여 드릴 수 없습니다.", "warn"))

    if ds_dow is not None:
        df = filter_frame(ds_dow.df, plan)
        res.data_used.append(data_used_entry(ds_dow, plan))
        if df.empty:
            res.findings.append(Finding("요일별 데이터에 조건에 맞는 행이 없습니다.", "warn"))
        else:
            kpis, suppressed = kpi_block(df, ds_dow)
            for k in kpis:
                k["note"] = ((k.get("note") + " · ") if k.get("note") else "") + "요일 자료 기준(상권 요약의 숫자와 조금 다를 수 있음)"
            if not res.kpis:
                res.kpis = kpis
            if not suppressed:
                t = make_table("요일별", df, ["dow_se"], ds_dow, rollups=standard_rollups("dow_band"), order=_DOW_ORDER)
                res.tables.append(t)
                produced = True
                res.charts.append(ChartSpec("bar", t.name, "dow_se", "use_amt", "요일별 카드 이용금액", filename="dow", options={"order": _DOW_ORDER}))
                s = safe_series(t, "use_amt")
                if len(s) >= 2:
                    tot = float(s["use_amt"].sum())
                    labels = set(s["dow_se"].astype(str))
                    wk = float(s[s["dow_se"].astype(str).isin(_WEEKEND)]["use_amt"].sum())
                    best = s.sort_values("use_amt", ascending=False).iloc[0]
                    best_name = str(best["dow_se"]) + ("요일" if str(best["dow_se"]) in ("월", "화", "수", "목", "금", "토", "일") else "")
                    if t.sdc.has_hidden:
                        res.findings.append(Finding(f"요일 중에서는 {best_name} 이용금액이 가장 큽니다. {hidden_note(t)}", "key"))
                    elif labels <= {"평일", "주말·공휴일"}:
                        res.findings.append(Finding(f"주말·공휴일 이용금액 비중은 {wk / tot * 100:.1f}%, 평일은 {100 - wk / tot * 100:.1f}%입니다.", "key"))
                    else:
                        res.findings.append(Finding(f"주말·공휴일 이용금액 비중은 {wk / tot * 100:.1f}%이고, 요일 중에서는 {best_name} 이용금액이 가장 큽니다.", "key"))
            else:
                res.findings.append(Finding("요일별 데이터의 전체 인원·건수가 반출 기준(10명) 미만이라 수치를 보여 드릴 수 없습니다.", "warn"))

    if not produced:
        res.ok = False
    res.method = "시간대별/요일별 카드 이용 현황을 지역·업종·기간으로 필터링해 합산했습니다. 작은 셀은 6시간 구간·평일/주말 구간으로 합쳐 반출 기준을 맞췄습니다."
    res.caveats.append("시간대는 결제 승인 시각 기준이며 매장 영업시간과 다를 수 있습니다.")
    res.caveats.append("이 결과는 '시간대/요일별' 자료 기준이라 같은 조건의 '상권 요약'(읍면동 자료)과 합계가 소폭 다를 수 있습니다.")
    if any(d.origin == "sample" for d in (ds_time, ds_dow) if d is not None):
        res.caveats.insert(0, "※ 현재 결과는 연습용 가짜(합성) 데이터입니다.")
    return res

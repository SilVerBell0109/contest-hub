"""T7. 입지 후보 스코어카드 — 후보 지역을 수요·성장·관광객·경쟁여유·유동인구 지표로 비교(참고 지표).

점수는 '제주 전체 지역 분포' 기준의 상대 점수(0~100, 100 = 제주에서 가장 높은 수준)이므로 후보가 2~3곳이어도
0/100 극단값이 나오지 않으며, 원지표(금액·증감률·비중·밀도·방문인구)를 점수와 함께 표시합니다.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from ..textutil import period_label
from .base import Plan, TemplateResult, ChartSpec, Finding, Table, MissingData, filter_frame, yoy_frames, coverage_label, data_used_entry, agg, count_cols, min_cell, fmt_won
from .common import pick_card_dataset, secure, josa

KEY = "site_score"
NAME = "입지 후보 스코어카드"
DESCRIPTION = "창업·출점 후보 지역들을 같은 업종 기준으로 수요(소비규모)·성장(전년대비)·관광객 비중·경쟁 여유(매장 밀도)·유동인구 5개 지표로 점수화해 비교(참고용)"
NEEDS = ["card_emd"]
PARAMS = {"compare_regions": "후보 지역 목록(없으면 권역/시/전체 안의 모든 법정동)", "industries": "업종(필수에 가까움)", "period": "기간", "weights": "지표 가중치(옵션)"}

DEFAULT_WEIGHTS = {"demand": 0.30, "growth": 0.20, "tourist": 0.15, "competition": 0.20, "footfall": 0.15}
KLABEL = {"demand": "수요(소비 규모)", "growth": "성장(전년 대비)", "tourist": "관광객 비중", "competition": "경쟁 여유", "footfall": "유동인구"}
RAW_OF = {"demand": "raw_amt", "growth": "raw_yoy", "tourist": "raw_tourist", "competition": "raw_density", "footfall": "raw_visit"}



def _sw_sentence(name: str, st: list[str], wk: list[str]) -> str:
    """강점·약점을 한 문장으로: '구좌읍의 강점은 A, B이고 약점은 C입니다.'"""
    if st and wk:
        return f"{name}의 강점은 {', '.join(st)}이고 약점은 {', '.join(wk)}입니다."
    if st:
        return f"{name}의 강점은 {', '.join(st)}이며 뚜렷한 약점은 없습니다."
    if wk:
        return f"{name}{josa(name, '은/는')} 두드러진 강점이 없고 약점은 {', '.join(wk)}입니다."
    return f"{name}{josa(name, '은/는')} 제주 전체와 비교해 두드러지게 높거나 낮은 지표가 없습니다."

def _scale(s: pd.Series, ref: pd.Series, invert: bool = False) -> pd.Series:
    """제주 전체 분포(ref)의 5~95 백분위를 0~100으로 보는 상대 점수."""
    s = pd.to_numeric(s, errors="coerce")
    ref = pd.to_numeric(ref, errors="coerce").dropna()
    if ref.empty:
        return pd.Series(np.nan, index=s.index)
    lo, hi = ref.quantile(0.05), ref.quantile(0.95)
    if hi == lo:
        return pd.Series(np.where(s.notna(), 50.0, np.nan), index=s.index)
    v = ((s - lo) / (hi - lo) * 100.0).clip(0, 100)
    return 100.0 - v if invert else v


def run(store, plan: Plan) -> TemplateResult:
    ds = pick_card_dataset(store, plan)
    base = ds.df
    if "bjd" not in base.columns:
        raise ValueError("입지 비교에는 법정동(bjd) 차원이 있는 카드 데이터가 필요합니다")
    cands = plan.compare_regions or plan.regions
    all_plan = Plan(**{**plan.__dict__, "regions": []})          # 제주 전체(기준 분포)
    df_all = filter_frame(base, all_plan)
    weights = {**DEFAULT_WEIGHTS, **(plan.options.get("weights") or {})}
    plabel = coverage_label(base, plan)
    res = TemplateResult(title=f"{plan.industry_label if plan.industries else '모든 업종'} {'입지 점수' if len(cands) == 1 else '입지 후보 비교'} — {plan.region_label if cands else '제주도 전체'}", subtitle=f"기간: {plabel} · 데이터: {ds.name}", plan=plan)
    res.data_used.append(data_used_entry(ds, Plan(**{**plan.__dict__, "regions": cands})))
    if df_all.empty:
        res.ok = False
        res.findings.append(Finding("조건에 해당하는 데이터가 없습니다.", "warn"))
        return res

    mc = min_cell(ds)
    cc = count_cols(ds, df_all)
    cur = agg(df_all, ["bjd"], ["use_amt", *cc])
    for c in cc:
        cur = cur[cur[c] >= mc] if mc > 0 else cur
    metrics = cur[["bjd", "use_amt"]].rename(columns={"use_amt": "raw_amt"}).copy()

    # 성장(양쪽 데이터가 있는 달만)
    cur_m, prev, matched = yoy_frames(base, all_plan)
    matched_label = f"{period_label(matched[0], matched[-1])} {len(matched)}개월" if prev is not None and matched else ""
    if prev is not None:
        pa = agg(prev, ["bjd"], ["use_amt", *cc])
        for c in cc:
            pa = pa[pa[c] >= mc] if mc > 0 else pa
        ca = agg(cur_m, ["bjd"], ["use_amt"]).rename(columns={"use_amt": "_cur"})
        m = metrics.merge(pa[["bjd", "use_amt"]].rename(columns={"use_amt": "_prev"}), on="bjd", how="left").merge(ca, on="bjd", how="left")
        metrics["raw_yoy"] = ((m["_cur"] - m["_prev"]) / m["_prev"] * 100.0).where(m["_prev"] > 0).clip(-50, 50).values
    # 관광객 비중 — 관광객·비관광객 양쪽의 인원이 모두 임계값 이상인 지역만(작은 집단의 비중이 새지 않게)
    if "user_grp" in df_all.columns:
        is_t = df_all["user_grp"].isin(["내국인 관광객", "외국인"])
        tg = df_all[is_t].groupby("bjd")["use_amt"].sum()
        tot = df_all.groupby("bjd")["use_amt"].sum()
        ratio = (tg.reindex(tot.index).fillna(0) / tot * 100.0)
        if cc and mc > 0:
            key = cc[0]
            t_cnt = df_all[is_t].groupby("bjd")[key].sum().reindex(tot.index).fillna(0)
            o_cnt = df_all[~is_t].groupby("bjd")[key].sum().reindex(tot.index).fillna(0)
            ratio = ratio.where((t_cnt >= mc) & (o_cnt >= mc))
        metrics["raw_tourist"] = ratio.reindex(metrics["bjd"]).values
    # 경쟁 여유(매장 밀도)
    sc = store.get("store_cnt")
    if sc is not None:
        sdf = filter_frame(sc.df, all_plan)
        if not sdf.empty:
            if "ym" in sdf.columns:
                sdf = sdf[sdf["ym"] == sdf["ym"].max()]
            st = agg(sdf, ["bjd"], ["store_cnt"])
            smc = min_cell(sc)
            if smc > 0:
                st = st[st["store_cnt"] >= smc]       # 매장수 자체가 임계값 미만인 지역은 밀도도 계산하지 않음(역산 방지)
            m = metrics.merge(st, on="bjd", how="left")
            metrics["raw_density"] = (m["store_cnt"] / (m["raw_amt"] / 1e8)).values
            res.data_used.append(data_used_entry(sc, Plan(**{**plan.__dict__, "regions": cands})))
    # 유동인구(월평균)
    ff = store.get("footfall_emd")
    if ff is not None and "visit_pop" in ff.df.columns:
        fdf = filter_frame(ff.df, all_plan, use_industry=False)
        if not fdf.empty:
            fa = agg(fdf, ["bjd"], ["visit_pop"])
            months = fdf["ym"].nunique() if "ym" in fdf.columns else 1
            fa["visit_pop"] = fa["visit_pop"] / max(months, 1)
            fmc = min_cell(ff)
            if fmc > 0:
                fa = fa[fa["visit_pop"] >= fmc]
            m = metrics.merge(fa, on="bjd", how="left")
            metrics["raw_visit"] = m["visit_pop"].values
            res.data_used.append(data_used_entry(ff, Plan(**{**plan.__dict__, "regions": cands})))

    # 제주 전체 분포 기준 점수화
    avail = []
    for k, raw in RAW_OF.items():
        if raw in metrics.columns and metrics[raw].notna().any():
            metrics[k] = _scale(metrics[raw], metrics[raw], invert=(k == "competition"))
            avail.append(k)
    wsum = sum(weights[k] for k in avail)
    metrics["score"] = sum(metrics[k].fillna(metrics[k].median() if metrics[k].notna().any() else 50.0) * (weights[k] / wsum) for k in avail).round(1)
    metrics = metrics.sort_values("score", ascending=False).reset_index(drop=True)
    metrics["island_rank"] = range(1, len(metrics) + 1)
    n_all = len(metrics)
    for k in avail:
        metrics[k] = metrics[k].round(0)

    sel = metrics[metrics["bjd"].isin(cands)] if cands else metrics
    excluded = sorted(set(cands) - set(metrics["bjd"])) if cands else []
    if sel.empty:
        res.ok = False
        res.findings.append(Finding("후보 지역의 이용 인원·건수가 반출 기준 미만이거나 데이터가 없어 점수를 계산할 수 없습니다.", "warn"))
        return res
    sel = sel.sort_values("score", ascending=False).reset_index(drop=True)
    sel.insert(0, "rank", range(1, len(sel) + 1))
    sel["island_rank_txt"] = sel["island_rank"].map(lambda r: f"{n_all}곳 중 {r}위")
    n_sel = min(plan.top_n, len(sel))
    out = sel.head(plan.top_n)
    score_cols = ["rank", "bjd", "island_rank_txt", "score", *avail]
    t = Table(f"입지 후보 점수표 (후보 {len(sel)}곳, 상위 {n_sel})", out[score_cols], ["rank", "bjd", "island_rank_txt"], ["score", *avail],
              count_cols=[], min_cell=0, sort_by="score", note="점수는 제주 전체 지역 분포 기준 0~100(100=제주에서 가장 높은 수준). 인원·건수 기준 미만 지역은 계산에서 제외.")
    secure(t)
    t.sdc.label = f"파생 지표표 — 인원·건수 {mc} 미만 지역은 계산에서 제외됨"
    t.sdc.plain_override = f"점수 계산용 표(인원·건수 {mc} 미만 지역은 제외)"
    t.display = t.display.rename(columns={"island_rank_txt": "제주 전체 순위"})
    res.tables.append(t)
    raw_cols = [RAW_OF[k] for k in avail]
    tr = Table("후보별 원지표 (점수의 근거)", out[["bjd", *raw_cols]], ["bjd"], raw_cols, count_cols=[], min_cell=0,
               note="카드 이용금액=기간 합계, 전년 대비=양쪽 자료가 있는 달 기준, 관광객 비중=이용금액 기준, 매출 1억원당 매장수=매장수÷(이용금액÷1억), 월평균 방문인구=기간 평균.")
    secure(tr)
    tr.sdc.label = "파생 지표표 — 임계값 미만 집단의 값은 계산에서 제외됨"
    tr.sdc.plain_override = f"점수 근거 표(인원·건수 {mc} 미만인 값은 비워 둠)"
    res.tables.append(tr)
    if len(out) >= 2:
        res.charts.append(ChartSpec("barh", t.name, "bjd", "score", f"{plan.industry_label} 입지 후보 종합점수(0~100, 제주 전체 기준)", filename="site_score"))

    # 쉬운 말 결론 (강점·약점, 근소한 차이는 '사실상 같은 수준')
    top = out.iloc[0]
    strengths = lambda row: [KLABEL[k] for k in avail if row[k] >= 60]  # noqa: E731
    weaknesses = lambda row: [KLABEL[k] for k in avail if row[k] <= 40]  # noqa: E731
    if len(out) == 1:
        res.findings.append(Finding(f"{top['bjd']}의 {plan.industry_label} 입지 종합점수는 {top['score']:.1f}점(제주 {top['island_rank_txt']})입니다. "
                                    + _sw_sentence(str(top["bjd"]), strengths(top), weaknesses(top)), "key"))
    else:
        second = out.iloc[1]
        gap = float(top["score"]) - float(second["score"])
        if gap < 1.0:
            res.findings.append(Finding(f"{top['bjd']}({top['score']:.1f}점)과 {second['bjd']}({second['score']:.1f}점)은 점수 차가 1점 미만이라 사실상 같은 수준입니다. "
                                        f"아래 강점·약점을 보고 판단하세요.", "key"))
        else:
            res.findings.append(Finding(f"후보 중 종합점수가 가장 높은 곳은 {top['bjd']}({top['score']:.1f}점, 제주 {top['island_rank_txt']})입니다.", "key"))
        parts = [_sw_sentence(str(r["bjd"]), strengths(r), weaknesses(r)) for _, r in out.head(3).iterrows()]
        res.findings.append(Finding("후보별로 보면 " + " ".join(parts), "key"))
        d = [k for k in avail if abs(float(out.iloc[0][k]) - float(out.iloc[1][k])) >= 20]
        if d:
            res.findings.append(Finding(f"{out.iloc[0]['bjd']}과 {out.iloc[1]['bjd']}의 차이가 큰 지표는 {', '.join(KLABEL[k] for k in d)}입니다.", "info"))
    res.findings.append(Finding(f"지표 설명: 수요는 카드 이용금액, 성장은 전년 동기 대비 증감률({matched_label or '비교 자료 없음'}), 관광객은 관광객 이용금액 비중, 경쟁 여유는 매출 1억원당 매장수가 적을수록 높고, 유동인구는 월평균 방문인구입니다.", "info"))
    res.kpis.append({"label": "비교 후보 수", "value": f"{len(sel)}곳", "unit": "", "note": f"점수 산정에 쓴 제주 전체 지역 {n_all}곳"})
    if excluded:
        res.caveats.append(f"이용 인원·건수가 반출 기준({mc}) 미만인 후보 {len(excluded)}곳({', '.join(excluded[:5])})은 점수 계산에서 제외했습니다.")
    res.findings.append(Finding("점수 계산: " + ", ".join(f"{KLABEL[k]} {weights[k] / wsum:.0%}" for k in avail) + " 가중 평균(제주 전체 분포 기준 0~100). 점수 차가 1점 미만이면 같은 수준으로 보세요.", "info"))
    res.method = ("각 지표를 제주 전체 지역 분포(5~95 백분위)를 기준으로 0~100점으로 환산한 뒤 가중합(" + ", ".join(f"{KLABEL[k]} {weights[k]:.0%}" for k in avail) + ")했습니다. "
                  "성장률은 ±50%로 제한, 경쟁 여유는 매출 1억원당 매장수의 역순입니다. 없는 지표는 가중치를 재배분했습니다.")
    res.caveats += ["이 점수는 데이터 기반 참고 지표이며 임대료·접근성·상권 성격 등 비데이터 요인은 포함하지 않습니다. 현장 조사와 함께 활용하세요.",
                    "점수가 높다고 반드시 좋은 입지는 아니며, 가중치에 따라 순위가 달라질 수 있습니다(담당자가 조정 가능)."]
    if ds.origin == "sample":
        res.caveats.insert(0, "※ 현재 결과는 연습용 가짜(합성) 데이터입니다.")
    return res

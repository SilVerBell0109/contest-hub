"""T3. 지역 비교·순위 — 같은 업종에 대해 여러 법정동·읍면의 소비 규모, 성장률, (가능 시) 방문인구 1인당 소비 비교."""
from __future__ import annotations

import pandas as pd

from ..sdc import blank_suppressed
from ..textutil import period_label
from .base import Plan, TemplateResult, ChartSpec, Finding, Table, filter_frame, yoy_frames, coverage_label, region_rollup, data_used_entry, fmt_won, agg, count_cols, min_cell
from .common import pick_card_dataset, make_table, kpi_block, safe_series, secure, refresh_display, josa, hidden_note

KEY = "region_compare"
NAME = "지역 비교·순위"
DESCRIPTION = "여러 법정동·읍면(또는 권역·시 전체)을 같은 업종·기간 기준으로 비교 — 이용금액 순위, 전년 대비 성장률, 방문인구 1인당 소비"
NEEDS = ["card_emd"]
PARAMS = {"regions": "비교할 지역 목록 또는 권역/시", "industries": "업종 키워드", "period": "기간", "top_n": "표시 개수"}


def run(store, plan: Plan) -> TemplateResult:
    ds = pick_card_dataset(store, plan)
    base = ds.df
    if "bjd" not in base.columns:
        raise ValueError("지역 비교에는 법정동(bjd) 차원이 있는 카드 데이터가 필요합니다")
    regions = plan.compare_regions or plan.regions
    sub_plan = Plan(**{**plan.__dict__, "regions": regions})
    df = filter_frame(base, sub_plan)
    scope = plan.region_label if regions else "제주도 전체"
    plabel = coverage_label(base, plan)
    res = TemplateResult(title=f"{scope} {plan.industry_label if plan.industries else '모든 업종'} 지역 비교", subtitle=f"기간: {plabel} · 데이터: {ds.name}", plan=plan)
    res.data_used.append(data_used_entry(ds, sub_plan))
    if df.empty:
        res.ok = False
        res.findings.append(Finding("조건에 해당하는 데이터가 없습니다.", "warn"))
        return res
    cur_m, prev, matched = yoy_frames(base, sub_plan)
    matched_label = f"{period_label(matched[0], matched[-1])} {len(matched)}개월" if prev is not None and matched else ""
    res.kpis, suppressed = kpi_block(df, ds, None)
    if suppressed:
        return res

    # 지역별 집계(검수 후 상위 N) + 전년 대비
    n_regions = df["bjd"].nunique()
    t = make_table(f"지역별 순위 (상위 {min(plan.top_n, n_regions)})", df, ["bjd"], ds, rollups=[region_rollup()], sort_by="use_amt", top_n=plan.top_n)
    if prev is not None and "bjd" in t.sdc.table.columns:
        pg = agg(prev, ["bjd"], ["use_amt", *[c for c in ("use_cnt", "user_cnt") if c in prev.columns]])
        cg = agg(cur_m, ["bjd"], ["use_amt"]).rename(columns={"use_amt": "_cur"})
        mc = min_cell(ds)
        for c in count_cols(ds, pg):
            pg = pg[pg[c] >= mc] if mc > 0 else pg
        pg = pg.merge(cg, on="bjd", how="inner")
        m = t.sdc.table.merge(pg[["bjd", "use_amt", "_cur"]].rename(columns={"use_amt": "_prev"}), on="bjd", how="left")
        yoy = ((m["_cur"] - m["_prev"]) / m["_prev"] * 100.0).where(m["_prev"] > 0)
        t.sdc.table["yoy"] = yoy.values
        t.sdc.measures = [*t.sdc.measures, "yoy"]
        t.measures = [*t.measures, "yoy"]
        blank_suppressed(t.sdc)          # 비공개 행의 파생 수치 제거
        refresh_display(t)
        t.note = f"전년 대비(%)는 양쪽 데이터가 있는 {matched_label} 기준" + ("" if len(matched) >= df["ym"].nunique() else " (합계는 요청 기간 전체)")
    res.tables.append(t)
    res.charts.append(ChartSpec("barh", t.name, "bjd", "use_amt", f"{plan.industry_label} 지역별 카드 이용금액 상위 {min(plan.top_n, n_regions)}", filename="region_rank"))

    s = safe_series(t, "use_amt").sort_values("use_amt", ascending=False)
    if len(s):
        tot = float(df["use_amt"].sum())
        top = s.iloc[0]
        line = f"{scope}에서 {plan.industry_label} 이용금액이 가장 큰 곳은 {top['bjd']}({fmt_won(top['use_amt'])}, 비중 {top['use_amt'] / tot * 100:.1f}%)"
        if len(s) > 1:
            line += f"이며, 2위는 {s.iloc[1]['bjd']}({fmt_won(s.iloc[1]['use_amt'])})입니다."
        else:
            line += "입니다."
        res.findings.append(Finding((line + " " + hidden_note(t)).strip(), "key"))
        if "yoy" in t.sdc.table.columns:
            y = t.sdc.table.dropna(subset=["yoy"]).sort_values("yoy", ascending=False)
            if len(y) >= 2:
                res.findings.append(Finding(f"작년 같은 기간({matched_label})과 비교하면 {y.iloc[0]['bjd']}이 {y.iloc[0]['yoy']:+.1f}%로 가장 많이 늘었고, {y.iloc[-1]['bjd']}은 {y.iloc[-1]['yoy']:+.1f}%입니다.", "key"))
                res.charts.append(ChartSpec("barh", t.name, "bjd", "yoy", f"지역별 전년 동기 대비 이용금액 증감률(%) — {matched_label} 기준", filename="region_yoy", options={"diverging": True}))
            elif len(y) == 1:
                res.findings.append(Finding(f"{y.iloc[0]['bjd']}의 작년 같은 기간({matched_label}) 대비 증감률은 {y.iloc[0]['yoy']:+.1f}%입니다.", "key"))

    # 방문인구 1인당 소비 (유동인구 데이터가 있으면)
    ff = store.get("footfall_emd")
    if ff is not None and "visit_pop" in ff.df.columns:
        fdf = filter_frame(ff.df, Plan(**{**sub_plan.__dict__, "industries": []}), use_industry=False)
        if not fdf.empty:
            fp = agg(fdf, ["bjd"], ["visit_pop"])
            m = s.merge(fp, on="bjd", how="inner")
            m = m[m["visit_pop"] > 0]
            if len(m):
                m["amt_per_visit"] = m["use_amt"] / m["visit_pop"]
                tv = Table("방문인구 1인당 소비", m[["bjd", "use_amt", "visit_pop", "amt_per_visit"]].reset_index(drop=True),
                           ["bjd"], ["use_amt", "visit_pop", "amt_per_visit"], count_cols=["visit_pop"], min_cell=min_cell(ff), sort_by="amt_per_visit",
                           note="방문인구 1인당 소비 = 기간 카드 이용금액 ÷ 기간 방문인구(칸 합산). 같은 사람이 여러 번 집계될 수 있어 지역 간 상대 비교용입니다.")
                secure(tv)
                res.tables.append(tv)
                res.data_used.append(data_used_entry(ff, sub_plan))
                res.charts.append(ChartSpec("barh", tv.name, "bjd", "amt_per_visit", "방문인구 1인당 카드 이용금액(원)", filename="amt_per_visit"))
                best = tv.sdc.table.dropna(subset=["amt_per_visit"]).sort_values("amt_per_visit", ascending=False)
                if len(best) >= 2:
                    res.findings.append(Finding(f"방문인구 1인당 소비는 {best.iloc[0]['bjd']}이 {best.iloc[0]['amt_per_visit']:,.0f}원으로 가장 높습니다(지역 간 상대 비교용 지표).", "info"))

    res.method = "비교 대상 지역의 카드 이용금액을 합산해 순위를 매기고, 전년 동기 데이터가 있으면 증감률을 계산했습니다. 작은 셀은 '기타 지역 합계'로 합치거나 비공개 처리했습니다."
    if ds.origin == "sample":
        res.caveats.insert(0, "※ 현재 결과는 연습용 가짜(합성) 데이터입니다.")
    return res

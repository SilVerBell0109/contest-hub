"""T6. 경쟁 밀도 — 지역·업종별 매장수와 수요(카드 소비·방문인구) 대비 밀도, 개·폐업 추이(공개 음식점 목록)."""
from __future__ import annotations

import re

import pandas as pd

from .. import geo
from .base import Plan, TemplateResult, ChartSpec, Finding, Table, MissingData, filter_frame, coverage_label, region_rollup, data_used_entry, agg, min_cell, fmt_num
from .common import scope_title, make_table, secure, pick_card_dataset, safe_series, kpi_block, pretty_period, hidden_note

KEY = "competition"
NAME = "경쟁 밀도"
DESCRIPTION = "지역·업종별 매장수, 카드 매출 1억원당·방문인구 1,000명당 매장수(경쟁 밀도), 공개 음식점 목록 기반 개·폐업 추이"
NEEDS = ["store_cnt", "hub_restaurants"]
PARAMS = {"regions": "지역", "industries": "업종", "period": "기간"}


def _bjd_from_address(addr: str) -> str | None:
    if not isinstance(addr, str):
        return None
    toks = addr.replace("제주특별자치도", "").split()
    for tok in toks[:4]:
        tok = re.sub(r"\d.*$", "", tok)
        if tok in geo.REGION_BY_NAME:
            return tok
    return None


def _restaurant_frame(ds) -> pd.DataFrame:
    df = ds.df.copy()
    addr_col = next((c for c in df.columns if "소재지전체주소" in str(c) or "지번주소" in str(c)), None)
    road_col = next((c for c in df.columns if "도로명전체주소" in str(c)), None)
    if addr_col is None and road_col is None:
        return pd.DataFrame()
    src = df[addr_col] if addr_col else df[road_col]
    df["bjd"] = src.map(_bjd_from_address)
    if road_col and addr_col:
        df["bjd"] = df["bjd"].fillna(df[road_col].map(_bjd_from_address))
    status_col = next((c for c in df.columns if "영업상태" in str(c) and "상세" not in str(c)), None)
    df["_open"] = df[status_col].astype(str).str.contains("영업|정상", regex=True) if status_col else True
    for col, name in (("인허가일자", "_open_year"), ("폐업일자", "_close_year")):
        c = next((x for x in df.columns if col in str(x)), None)
        df[name] = df[c].astype(str).str.extract(r"(\d{4})")[0] if c else None
    if "ksic_nm" not in df.columns:
        sub = next((c for c in df.columns if "소분류" in str(c)), None)
        if sub:
            df["ksic_nm"] = df[sub]
    return df


def run(store, plan: Plan) -> TemplateResult:
    sc = store.get("store_cnt")
    hr = store.get("hub_restaurants")
    if sc is None and hr is None:
        raise MissingData(["store_cnt", "hub_restaurants"], "매장수 데이터(센터 '업종별 매장 수' 또는 허브 '음식점 목록')가 없습니다")
    plabel = coverage_label(sc.df, plan) if sc is not None else (plan.period.label if plan.period else "-")
    res = TemplateResult(title=f"{scope_title(plan)} 경쟁 밀도", subtitle=f"기간: {plabel}", plan=plan)
    stores_by_bjd: pd.DataFrame | None = None
    single_region = len(plan.regions) == 1

    # ── 센터 매장수 (카드 가맹점 기준) ──
    if sc is not None:
        df = filter_frame(sc.df, plan)
        res.data_used.append(data_used_entry(sc, plan))
        if not df.empty:
            if "ym" in df.columns:
                last = df["ym"].max()
                cur = df[df["ym"] == last]
                if df["ym"].nunique() > 1 and single_region:
                    tt = make_table("월별 매장수 추이", df, ["ym"], sc, measures=["store_cnt"], sort_by="ym", ascending=True)
                    res.tables.append(tt)
                    res.charts.append(ChartSpec("line", tt.name, "ym", "store_cnt", "월별 매장수 추이(카드 가맹점 기준)", filename="store_trend"))
            else:
                cur, last = df, "-"
            kp, suppressed = kpi_block(cur, sc)
            for k in kp:
                if k["label"] == "매장수":
                    k["label"] = f"카드 가맹 매장수 ({pretty_period(last)})"
                    res.kpis.append(k)
                elif k["label"] == "집계 결과":
                    k["label"] = "카드 가맹 매장수"
                    res.kpis.append(k)
            if not suppressed:
                t = make_table(f"{'매장수' if single_region else '지역별 매장수'} ({pretty_period(last)})", cur, ["bjd"], sc, measures=["store_cnt"], rollups=[region_rollup()], sort_by="store_cnt", top_n=plan.top_n)
                res.tables.append(t)
                if not single_region:
                    res.charts.append(ChartSpec("barh", t.name, "bjd", "store_cnt", f"{plan.industry_label} 지역별 매장수(카드 가맹점 기준)", filename="stores"))
                stores_by_bjd = safe_series(t, "store_cnt").rename(columns={"store_cnt": "stores"})
                if len(stores_by_bjd):
                    top = stores_by_bjd.sort_values("stores", ascending=False).iloc[0]
                    if single_region:
                        res.findings.append(Finding(f"{pretty_period(last)} 기준 {plan.region_label}의 {plan.industry_label} 카드 가맹 매장은 {int(top['stores']):,}곳입니다.", "key"))
                    else:
                        res.findings.append(Finding(f"{plan.industry_label} 매장이 가장 많은 곳은 {top['bjd']}({int(top['stores']):,}곳, 카드 가맹점 기준)입니다. {hidden_note(t)}".strip(), "key"))

    # ── 허브 음식점 목록(공개, 인허가 기준) ──
    if hr is not None and (sc is None or plan.options.get("use_restaurants", True)):
        rf = _restaurant_frame(hr)
        res.data_used.append(data_used_entry(hr, plan, "영업상태·주소에서 법정동 추출"))
        if not rf.empty:
            if plan.regions:
                rf = rf[rf["bjd"].isin(plan.regions)]
            if plan.industries and "ksic_nm" in rf.columns:
                m = pd.Series(False, index=rf.index)
                for im in plan.industries:
                    m = m | im.mask(None, rf["ksic_nm"])
                rf = rf[m]
            act = rf[rf["_open"]]
            res.kpis.append({"label": "참고: 허가 목록상 영업 중 음식점", "value": f"{len(act):,}곳", "unit": "",
                             "note": "공개 인허가 목록(휴업·폐업 미신고 포함) 기준이라 카드 가맹 매장수와 다를 수 있음. 사업계획서에는 카드 가맹 매장수를 주로 쓰세요." if sc is not None else "공개 인허가 목록 기준(휴업·폐업 미신고 포함 가능)"})
            if len(act) and act["bjd"].notna().any():
                g = act.groupby("bjd", as_index=False).size().rename(columns={"size": "store_cnt"}).sort_values("store_cnt", ascending=False)
                t = Table(f"지역별 영업 중 음식점 수 (허가 목록, 상위 {plan.top_n})", g.reset_index(drop=True), ["bjd"], ["store_cnt"], count_cols=[], min_cell=0, sort_by="store_cnt")
                secure(t, top_n=plan.top_n)
                t.sdc.label = "공개 데이터(허브 음식점 목록) — 임계값 미적용"
                res.tables.append(t)
                if not single_region:
                    res.charts.append(ChartSpec("barh", t.name, "bjd", "store_cnt", "지역별 영업 중 음식점 수(공개 허가 목록)", filename="restaurants"))
                if stores_by_bjd is None:
                    stores_by_bjd = g.rename(columns={"store_cnt": "stores"})
                    top = g.iloc[0]
                    if single_region:
                        res.findings.append(Finding(f"공개 허가 목록 기준 {plan.region_label}에서 영업 중인 {plan.industry_label} 매장은 {int(top['store_cnt']):,}곳입니다.", "key"))
                    else:
                        res.findings.append(Finding(f"공개 허가 목록 기준 영업 중 매장이 가장 많은 곳은 {top['bjd']}({int(top['store_cnt']):,}곳)입니다.", "key"))
            years = sorted({y for y in rf["_open_year"].dropna().unique() if y.isdigit()})[-10:]
            if years:
                opened = rf[rf["_open_year"].isin(years)].groupby("_open_year").size()
                closed = rf[rf["_close_year"].isin(years)].groupby("_close_year").size()
                oc = pd.DataFrame({"year": years, "opened": [int(opened.get(y, 0)) for y in years], "closed": [int(closed.get(y, 0)) for y in years]})
                t = Table("연도별 개업·폐업 수(공개 허가 목록)", oc, ["year"], ["opened", "closed"], count_cols=[], min_cell=0)
                secure(t)
                t.sdc.label = "공개 데이터(허브 음식점 목록) — 임계값 미적용"
                res.tables.append(t)
                res.charts.append(ChartSpec("groupbar_wide", t.name, "year", ["opened", "closed"], "연도별 개업·폐업 수(공개 허가 목록)", filename="open_close"))
                if len(oc) >= 3:
                    recent = oc.tail(3)
                    o, c = int(recent["opened"].sum()), int(recent["closed"].sum())
                    res.findings.append(Finding(f"최근 {len(recent)}년({recent['year'].iloc[0]}~{recent['year'].iloc[-1]}) 동안 {o:,}곳이 새로 열고 {c:,}곳이 문을 닫았습니다(공개 허가 목록 기준).", "key"))
            res.caveats.append("공개 음식점 목록은 인허가 기준이라 실제 영업 여부·업종과 차이가 있을 수 있으며, 좌표가 없어 주소 문자열에서 법정동을 추출했습니다.")

    # ── 수요 대비 밀도 ──
    if stores_by_bjd is not None and len(stores_by_bjd):
        try:
            cds = pick_card_dataset(store, plan)
        except MissingData:
            cds = None
        if cds is not None and "bjd" in cds.df.columns:
            cdf = filter_frame(cds.df, plan)
            if not cdf.empty:
                ca = agg(cdf, ["bjd"], ["use_amt", *[c for c in ("use_cnt", "user_cnt") if c in cdf.columns]])
                m = stores_by_bjd.merge(ca, on="bjd", how="inner")
                m = m[m["use_amt"] > 0]
                if len(m):
                    m["stores_per_1e8"] = m["stores"] / (m["use_amt"] / 1e8)
                    tv = Table("매출 1억원당 매장수(경쟁 밀도)", m.reset_index(drop=True), ["bjd"], ["stores", "use_amt", "stores_per_1e8"],
                               count_cols=[c for c in ("use_cnt", "user_cnt") if c in m.columns], min_cell=min_cell(cds), sort_by="stores_per_1e8",
                               note="매출 1억원당 매장수 = 매장수 ÷ (기간 카드 이용금액 ÷ 1억원). 값이 클수록 매출에 비해 매장이 많아 경쟁이 치열합니다.")
                    secure(tv)
                    res.tables.append(tv)
                    res.data_used.append(data_used_entry(cds, plan))
                    d = tv.sdc.table.dropna(subset=["stores_per_1e8"]).sort_values("stores_per_1e8")
                    if len(d) >= 2:
                        res.charts.append(ChartSpec("barh", tv.name, "bjd", "stores_per_1e8", "카드 매출 1억원당 매장수 (높을수록 경쟁 치열)", filename="density"))
                        res.findings.append(Finding(f"매출 대비 경쟁이 가장 느슨한 곳은 {d.iloc[0]['bjd']}(1억원당 {d.iloc[0]['stores_per_1e8']:.1f}곳), 가장 치열한 곳은 {d.iloc[-1]['bjd']}({d.iloc[-1]['stores_per_1e8']:.1f}곳)입니다.", "key"))
                    elif len(d) == 1:
                        # 제주 전체 평균과 비교해 '많다/적다'의 기준을 준다 (전체 평균은 지역별 합계에서 계산)
                        ctx = ""
                        try:
                            all_plan = Plan(**{**plan.__dict__, "regions": [], "compare_regions": []})
                            sdf_all = filter_frame(sc.df, all_plan) if sc is not None else pd.DataFrame()
                            cdf_all = filter_frame(cds.df, all_plan)
                            if len(sdf_all) and len(cdf_all):
                                if "ym" in sdf_all.columns:
                                    sdf_all = sdf_all[sdf_all["ym"] == sdf_all["ym"].max()]
                                tot_stores = float(sdf_all["store_cnt"].sum())
                                tot_amt = float(cdf_all["use_amt"].sum())
                                if tot_amt > 0:
                                    avg = tot_stores / (tot_amt / 1e8)
                                    v = float(d.iloc[0]["stores_per_1e8"])
                                    rel = "많은" if v > avg * 1.15 else ("적은" if v < avg * 0.85 else "비슷한")
                                    ctx = f" 제주 전체 평균은 {avg:.1f}곳으로, 매출에 비해 매장이 {rel} 편입니다."
                        except Exception:  # noqa: BLE001
                            ctx = ""
                        res.findings.append(Finding(f"{d.iloc[0]['bjd']}은 카드 매출 1억원당 매장이 {d.iloc[0]['stores_per_1e8']:.1f}곳입니다.{ctx}", "key" if ctx else "info"))
        ff = store.get("footfall_emd")
        if ff is not None and "visit_pop" in ff.df.columns:
            fdf = filter_frame(ff.df, plan, use_industry=False)
            if not fdf.empty:
                fa = agg(fdf, ["bjd"], ["visit_pop"])
                months = fdf["ym"].nunique() if "ym" in fdf.columns else 1
                fa["visit_pop"] = fa["visit_pop"] / max(months, 1)
                m = stores_by_bjd.merge(fa, on="bjd", how="inner")
                m = m[m["visit_pop"] > 0]
                if len(m) >= 2:
                    m["stores_per_1k_visit"] = m["stores"] / (m["visit_pop"] / 1000.0)
                    tv = Table("월평균 방문인구 1,000명당 매장수", m.reset_index(drop=True), ["bjd"], ["stores", "visit_pop", "stores_per_1k_visit"],
                               count_cols=["visit_pop"], min_cell=min_cell(ff), sort_by="stores_per_1k_visit", note="월평균 방문인구(칸 합산) 1,000명당 매장수. 지역 간 상대 비교용.")
                    secure(tv)
                    res.tables.append(tv)
                    res.data_used.append(data_used_entry(ff, plan))
                    res.charts.append(ChartSpec("barh", tv.name, "bjd", "stores_per_1k_visit", "월평균 방문인구 1,000명당 매장수", filename="density_pop"))

    if not res.tables:
        res.ok = False
        res.findings.append(Finding("조건에 해당하는 매장 데이터가 없습니다.", "warn"))
    res.method = "매장수(센터 '업종별 매장 수'=카드 가맹점 기준, 또는 허브 공개 음식점 목록=인허가 기준)를 지역별로 세고, 같은 조건의 카드 매출·방문인구로 나눠 밀도를 계산했습니다."
    res.caveats.append("카드 가맹 매장수와 허가 목록 음식점 수는 기준이 달라 서로 다를 수 있습니다(가맹 여부·업종 분류 차이).")
    if (sc is not None and sc.origin == "sample") or (hr is not None and hr.origin == "sample"):
        res.caveats.insert(0, "※ 현재 결과는 연습용 가짜(합성) 데이터입니다.")
    return res

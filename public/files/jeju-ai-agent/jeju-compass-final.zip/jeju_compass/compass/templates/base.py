"""분석 템플릿 공통 구조: 계획(Plan), 표(Table), 차트 명세, 결과(TemplateResult), 필터·집계 도우미."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

import pandas as pd

from .. import geo
from ..industries import IndustryMatch
from ..loader import DataStore, LoadedDataset
from ..sdc import Rollup, SDCResult, STANDARD_ROLLUPS
from ..textutil import Period, months_between, add_months, period_label


# ── 계획 ───────────────────────────────────────────────────────────────────
@dataclass
class Plan:
    template: str
    question: str
    regions: list[str] = field(default_factory=list)      # bjd 목록 (빈 목록 = 전체)
    region_label: str = "제주도 전체"
    region_scope: str = "all"
    industries: list[IndustryMatch] = field(default_factory=list)
    period: Period | None = None
    compare_regions: list[str] = field(default_factory=list)  # 지역 비교·후보지 (T3/T7)
    top_n: int = 10
    yoy: bool = False
    options: dict[str, Any] = field(default_factory=dict)
    source: str = "rule"            # llm | rule | user
    reasoning: str = ""
    confidence: float = 0.5
    clarify: dict | None = None     # 되묻기 정보(지역 확인 등) — 있으면 UI가 선택지를 함께 보여줌

    @property
    def industry_label(self) -> str:
        return ", ".join(m.label for m in self.industries) if self.industries else "전체 업종"

    def to_dict(self) -> dict:
        return {
            "template": self.template, "question": self.question, "regions": self.regions, "region_label": self.region_label,
            "region_scope": self.region_scope, "industries": [m.label for m in self.industries],
            "period": {"start": self.period.start, "end": self.period.end, "label": self.period.label, "explicit": self.period.explicit,
                       "range_text": period_label(self.period.start, self.period.end), "note": self.period.note} if self.period else None,
            "compare_regions": self.compare_regions, "top_n": self.top_n, "yoy": self.yoy, "options": self.options,
            "source": self.source, "reasoning": self.reasoning, "confidence": self.confidence, "clarify": self.clarify,
            "region_note": self.options.get("region_note", ""), "region_warning": self.options.get("region_warning", ""),
        }


# ── 결과 구조 ───────────────────────────────────────────────────────────────
@dataclass
class Table:
    name: str
    df: pd.DataFrame
    dims: list[str]
    measures: list[str]
    count_cols: list[str]
    min_cell: int = 10
    rollups: list[Rollup] = field(default_factory=list)
    note: str = ""
    sort_by: str | None = None
    ascending: bool = False
    sdc: SDCResult | None = None
    display: pd.DataFrame | None = None
    hidden: bool = False          # 보고서 표에서는 숨기고 차트에만 사용
    source: pd.DataFrame | None = field(default=None, repr=False)   # 이 표를 만든 원천 행(필터된 데이터) — 보고서 단위 연결표 검사용
    source_key: str = ""          # 원천 데이터셋 키
    orig_dims: list[str] = field(default_factory=list)              # 범주 상향 전 차원


@dataclass
class ChartSpec:
    kind: str                    # bar | barh | line | stacked | multiline | donut
    table: str
    x: str
    y: str | list[str]
    title: str
    series: str | None = None    # 시리즈 차원(멀티라인/스택)
    filename: str = ""
    options: dict[str, Any] = field(default_factory=dict)


@dataclass
class Finding:
    text: str
    level: str = "info"          # key | info | warn


@dataclass
class TemplateResult:
    title: str
    subtitle: str
    plan: Plan
    kpis: list[dict] = field(default_factory=list)
    tables: list[Table] = field(default_factory=list)
    charts: list[ChartSpec] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)
    data_used: list[dict] = field(default_factory=list)
    method: str = ""
    guidance: dict | None = None     # 데이터 부족 시 안내(T8 형식)
    clarify: dict | None = None      # 되묻기(지역 확인 등): {"message", "options":[{"label","question"}]}
    ok: bool = True

    def table(self, name: str) -> Table | None:
        for t in self.tables:
            if t.name == name:
                return t
        return None


class MissingData(Exception):
    """필요한 데이터셋이 없을 때 — 에이전트가 데이터 안내(T8)로 전환한다."""

    def __init__(self, needed_keys: list[str], message: str = ""):
        super().__init__(message or f"필요 데이터 없음: {needed_keys}")
        self.needed_keys = needed_keys


# ── 필터·집계 도우미 ─────────────────────────────────────────────────────────
def filter_frame(df: pd.DataFrame, plan: Plan, use_period: bool = True, use_region: bool = True, use_industry: bool = True) -> pd.DataFrame:
    out = df
    if use_period and plan.period is not None and "ym" in out.columns:
        out = out[(out["ym"] >= plan.period.start) & (out["ym"] <= plan.period.end)]
    if use_region and plan.regions and "bjd" in out.columns:
        out = out[out["bjd"].isin(plan.regions)]
    if use_industry and plan.industries and ("ksic_nm" in out.columns or "ksic_cd" in out.columns):
        codes = out["ksic_cd"] if "ksic_cd" in out.columns else None
        names = out["ksic_nm"] if "ksic_nm" in out.columns else pd.Series([""] * len(out), index=out.index)
        m = pd.Series(False, index=out.index)
        for im in plan.industries:
            m = m | im.mask(codes, names)
        out = out[m]
    return out


def prev_year_period(period: Period) -> Period:
    s, e = add_months(period.start, -12), add_months(period.end, -12)
    return Period(s, e, f"전년 동기({period.label})", True)


def coverage(base: pd.DataFrame, plan: Plan) -> tuple[list[str], list[str]]:
    """(요청 기간의 달 목록, 그중 데이터가 있는 달 목록)."""
    if plan.period is None or "ym" not in base.columns:
        return [], []
    rs, re_ = plan.period.requested
    want = months_between(rs, re_)
    avail = set(base["ym"].dropna().unique())
    return want, [m for m in want if m in avail]


def coverage_label(base: pd.DataFrame, plan: Plan) -> str:
    """기간 라벨에 보유 월 수를 덧붙인다. 예: '2025년(보유 4~12월, 9개월분)'."""
    want, have = coverage(base, plan)
    if not want or not have or len(have) == len(want):
        return plan.period.label if plan.period else "-"
    if have[0][:4] == have[-1][:4] and len(have) > 1:
        span = f"{int(have[0][4:6])}~{int(have[-1][4:6])}월"
    elif len(have) == 1:
        span = f"{int(have[0][4:6])}월"
    else:
        span = period_label(have[0], have[-1])
    return f"{plan.period.label}(보유 {span}, {len(have)}개월분)"


def yoy_frames(base: pd.DataFrame, plan: Plan) -> tuple[pd.DataFrame, pd.DataFrame | None, list[str]]:
    """전년 동기 비교용 (올해 프레임, 작년 프레임, 매칭된 월 목록).

    양쪽 모두 데이터가 있는 달만 비교한다(부분 비교). 작년 데이터가 한 달도 없으면 (올해 전체, None, [])를 돌려준다.
    """
    cur = filter_frame(base, plan)
    if plan.period is None or "ym" not in base.columns:
        return cur, None, []
    avail = set(base["ym"].dropna().unique())
    cur_months = [m for m in months_between(plan.period.start, plan.period.end) if m in avail]
    matched = [m for m in cur_months if add_months(m, -12) in avail]
    if not matched:
        return cur, None, []
    prev_months = [add_months(m, -12) for m in matched]
    prev_plan = Plan(**{**plan.__dict__, "period": Period(min(prev_months), max(prev_months), "전년 동기", True)})
    prev = filter_frame(base, prev_plan)
    prev = prev[prev["ym"].isin(prev_months)]
    cur_m = cur[cur["ym"].isin(matched)]
    return cur_m, (prev if not prev.empty else None), matched


def agg(df: pd.DataFrame, dims: list[str], measures: list[str]) -> pd.DataFrame:
    dims = [d for d in dims if d in df.columns]
    meas = [m for m in measures if m in df.columns]
    if not dims:
        return df[meas].sum(numeric_only=True).to_frame().T
    return df.groupby(dims, dropna=False, observed=True, as_index=False)[meas].sum()


def measure_cols(df: pd.DataFrame) -> list[str]:
    return [c for c in ("user_cnt", "use_cnt", "use_amt", "sale_cnt", "store_cnt", "resd_pop", "work_pop", "visit_pop", "flow_pop") if c in df.columns]


def count_cols(ds: LoadedDataset, df: pd.DataFrame) -> list[str]:
    if ds.spec:
        cols = [c for c in ds.spec.sdc_count_columns if c in df.columns]
        if cols:
            return cols
    return [c for c in ("user_cnt", "use_cnt", "sale_cnt", "store_cnt", "visit_pop", "flow_pop") if c in df.columns]


def min_cell(ds: LoadedDataset) -> int:
    return ds.spec.sdc_min_cell if ds.spec else 10


def fmt_won(v: float) -> str:
    """원 단위를 억/만 단위로 읽기 쉽게."""
    if v is None or pd.isna(v):
        return "-"
    v = float(v)
    if abs(v) >= 1e8:
        return f"{v / 1e8:,.1f}억원"
    if abs(v) >= 1e4:
        return f"{v / 1e4:,.0f}만원"
    return f"{v:,.0f}원"


def fmt_num(v: float) -> str:
    if v is None or pd.isna(v):
        return "-"
    return f"{float(v):,.0f}"


def pct(a: float, b: float) -> float | None:
    if b in (0, None) or pd.isna(b) or pd.isna(a):
        return None
    return (a - b) / b * 100.0


def data_used_entry(ds: LoadedDataset, plan: Plan, extra: str = "") -> dict:
    p = ds.period
    return {"key": ds.key, "name": ds.name, "origin": ds.origin, "rows": ds.rows, "period": f"{p[0]}~{p[1]}" if p[0] else "-",
            "period_text": period_label(p[0], p[1]) if p[0] else "-",
            "filter": f"지역: {plan.region_label} / 업종: {plan.industry_label} / 기간: {plan.period.label if plan.period else '-'}" + (f" / {extra}" if extra else ""),
            "export": ds.spec.export if ds.spec else "unknown", "files": ds.files}


def share_table(df: pd.DataFrame, dim: str, measure: str, label: str = "비중(%)") -> pd.DataFrame:
    """비중 열 추가(합계 대비 %). SDC 이후 안전표에 대해 호출할 것."""
    out = df.copy()
    tot = pd.to_numeric(out[measure], errors="coerce").sum()
    out[label] = (pd.to_numeric(out[measure], errors="coerce") / tot * 100.0).round(1) if tot else None
    return out


def standard_rollups(*keys: str) -> list[Rollup]:
    return [STANDARD_ROLLUPS[k] for k in keys if k in STANDARD_ROLLUPS]


def region_rollup() -> Rollup:
    """작은 지역만 '기타 지역(기타 합계)'으로 병합 — 큰 지역의 값은 그대로 유지."""
    return Rollup("bjd", None, "작은 지역→기타 지역 합계", merge_small=True, merge_label="기타 지역")


def city_rollup() -> Rollup:
    return Rollup("dstrct_se", lambda d: str(d).split(" ")[0] if d else d, "권역→시")


def months_label(df: pd.DataFrame) -> str:
    if "ym" not in df.columns or df.empty:
        return "-"
    return f"{df['ym'].min()}~{df['ym'].max()} ({df['ym'].nunique()}개월)"

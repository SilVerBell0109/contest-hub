"""T8. 데이터 안내 / 도움말 — 질문에 필요한 데이터셋·받는 조건·적재 상태·예시 질문, 사용법, 답할 수 없는 질문 안내."""
from __future__ import annotations

from ..registry import get_registry
from ..textutil import months_between
from .base import Plan, TemplateResult, Finding
from .common import josa

KEY = "navigator"
NAME = "데이터 안내 · 도움말"
DESCRIPTION = "질문에 어떤 데이터가 필요한지, 센터·허브에서 무엇을 어떤 조건(기간·지역)으로 내려받아 어디에 넣어야 하는지 안내. 사용법(도움말)과 이 프로그램이 답할 수 없는 질문 안내 포함"
NEEDS: list[str] = []
PARAMS = {"needed_keys": "필요 데이터셋 키 목록(옵션)", "mode": "data | help | unsupported | howto"}

# 템플릿 → 필요한 데이터 (대체 가능 데이터 포함)
TEMPLATE_NEEDS = {
    "market_summary": [["card_emd", "hub_startup_mashup", "hub_card_industry"]],
    "time_pattern": [["card_time", "card_dow"]],
    "region_compare": [["card_emd", "hub_startup_mashup"]],
    "tourist": [["card_emd", "hub_card_industry", "hub_startup_mashup"]],
    "footfall": [["footfall_emd", "hub_footfall_api"]],
    "competition": [["store_cnt", "hub_restaurants"]],
    "site_score": [["card_emd", "hub_startup_mashup"]],
}
OPTIONAL_NEEDS = {
    "region_compare": ["footfall_emd"], "footfall": ["card_emd"], "competition": ["card_emd", "footfall_emd"], "site_score": ["store_cnt", "footfall_emd"],
}
REGION_ONLY_KEYS = {"card_emd", "card_time", "card_dow", "footfall_emd", "store_cnt", "hub_startup_mashup", "hub_restaurants", "hub_footfall_api"}

EXAMPLE_QUESTIONS = {
    "card_emd": ["애월읍 카페 상권 요약해줘", "노형동 한식 음식점 최근 6개월 소비 추이", "제주시 서부 읍면 중 카페 창업 후보지 비교"],
    "card_time": ["연동 주점은 몇 시에 손님이 많아?", "성산읍 음식점 시간대별·요일별 패턴"],
    "card_dow": ["중문동 숙박업 주말과 평일 매출 비교"],
    "footfall_emd": ["구좌읍 유동인구 월별 추이와 연령 구성", "방문인구 대비 소비가 높은 동네는?"],
    "store_cnt": ["한림읍 카페 경쟁 밀도 알려줘"],
    "hub_restaurants": ["서귀포시 동부 음식점 개폐업 추이"],
    "hub_card_industry": ["제주 전체 외국인 관광객 소비 추이(허브 공개 데이터)"],
}

HELP = {
    "what": "이 프로그램은 제주빅데이터센터의 카드 소비·유동인구·매장수 데이터로 ‘동네(법정동·읍면) × 업종’의 장사 현황을 분석해 보고서로 만들어 드립니다.",
    "can": ["동네·업종의 소비 규모와 월별 흐름, 작년 같은 기간과 비교 (예: 애월읍 카페 장사 잘 돼?)",
            "손님이 많은 시간대·요일 (예: 연동 주점은 몇 시에 손님이 많아?)",
            "여러 동네 비교·순위 (예: 노형동과 연동 카페 비교)",
            "관광객·외국인 소비 (예: 서귀포시 외국인 관광객 소비 추이)",
            "유동인구 (예: 구좌읍 유동인구 분석)",
            "매장 수·경쟁 정도·개폐업 (예: 한림읍 카페 경쟁 밀도)",
            "창업 후보지 비교 (예: 한림읍이랑 구좌읍 중에 카페 하기 어디가 좋아?)"],
    "cannot": ["월세·임대료·권리금·인테리어 비용 — 이 데이터에는 없습니다",
               "개별 가게의 매출 — 동네·업종 단위로만 집계됩니다(개인정보 보호)",
               "날씨, 메뉴별 매출, 온라인 매출 — 현재 버전에서는 다루지 않습니다",
               "미래 예측 — 과거 실적만 보여 드립니다"],
    "how": ["동네 이름(예: 애월읍, 노형동)과 업종(예: 카페, 한식, 숙박)을 넣어 질문하세요. 기간을 쓰지 않으면 최근 12개월입니다.",
            "결과 맨 위의 ‘프로그램이 이렇게 이해했어요’ 줄을 확인하고, 다르면 [고칠래요]를 누르세요.",
            "굵은 글씨가 핵심 결론입니다. 표의 ‘비공개(<10)’는 10명 미만이라 개인정보 보호를 위해 가린 칸입니다.",
            "보고서를 가져가려면 [📑 보고서 PDF 저장]을 누른 뒤, 센터 시스템에서 ‘반출 신청’을 하세요. 모르면 담당자를 불러 주세요."],
}
UNSUPPORTED_WORDS = {"월세": "임대료", "임대료": "임대료", "권리금": "권리금", "보증금": "보증금", "인테리어": "인테리어 비용", "날씨": "날씨", "기온": "날씨",
                     "메뉴별": "메뉴별 매출", "메뉴 매출": "메뉴별 매출", "온라인": "온라인 매출", "배달": "배달 매출", "예측": "미래 예측", "전망": "미래 예측",
                     "순이익": "순이익·원가", "마진": "순이익·원가", "원가": "순이익·원가", "인건비": "인건비", "주차": "주차 정보", "학군": "학군", "집값": "부동산 가격", "땅값": "부동산 가격",
                     "대출": "대출·금융", "융자": "대출·금융", "이자율": "대출·금융", "금리": "대출·금융", "프랜차이즈 본사": "프랜차이즈 정보", "가맹비": "프랜차이즈 정보", "리뷰": "온라인 평판", "평점": "온라인 평판"}


def run(store, plan: Plan) -> TemplateResult:
    reg = get_registry()
    mode = plan.options.get("mode", "data")
    needed = plan.options.get("needed_keys") or []
    target_template = plan.options.get("target_template")

    if mode == "help":
        res = TemplateResult(title="사용법 안내", subtitle="이 프로그램이 할 수 있는 것과 쓰는 법", plan=plan)
        res.guidance = {"kind": "help", "help": HELP, "example_questions": [q for qs in EXAMPLE_QUESTIONS.values() for q in qs][:8],
                        "loaded_now": [d["name"] for d in store.summaries()]}
        res.findings.append(Finding(HELP["what"], "key"))
        res.method = "도움말"
        return res

    if mode == "unsupported":
        topic = plan.options.get("unsupported_topic", "요청하신 정보")
        asked = plan.options.get("unsupported_word") or topic
        res = TemplateResult(title="이 프로그램이 알 수 없는 정보예요", subtitle=f"‘{asked}’{josa(asked, '은/는')} 센터 데이터에 없습니다", plan=plan)
        res.findings.append(Finding(f"‘{asked}’{josa(asked, '은/는')} 이 프로그램이 다루는 데이터(카드 소비·유동인구·매장수)에 없어서 답해 드릴 수 없습니다.", "warn"))
        res.findings.append(Finding("대신 같은 동네·업종의 소비 규모, 손님이 많은 시간, 경쟁 매장 수, 후보지 비교는 바로 볼 수 있어요. 아래 예시를 눌러 보세요.", "info"))
        res.guidance = {"kind": "help", "help": HELP, "example_questions": [q for qs in EXAMPLE_QUESTIONS.values() for q in qs][:6], "loaded_now": [d["name"] for d in store.summaries()]}
        res.method = "지원 범위 안내"
        return res

    if mode == "howto":
        res = TemplateResult(title="창업 준비, 이렇게 살펴보세요", subtitle="이 프로그램으로 차례대로 확인할 수 있는 것", plan=plan)
        ind = plan.industry_label if plan.industries else "카페"
        region = plan.region_label if plan.regions and plan.region_scope == "bjd" and len(plan.regions) == 1 else "애월읍"
        other = "한림읍" if region != "한림읍" else "구좌읍"
        examples = [f"{region} {ind} 상권 요약", f"{region} {ind} 몇 시에 손님이 많아?", f"{region} {ind} 경쟁 밀도", f"{region}이랑 {other} 중에 {ind} 하기 어디가 좋아?"]
        hint = "" if plan.industries else " (예시는 ‘카페’ 기준이니 본인 업종으로 바꿔 물어보세요)"
        steps = [f"① 후보 동네의 {ind} 소비 규모와 흐름 — 예: {examples[0]}{hint}",
                 f"② 손님이 몰리는 시간대·요일 — 예: {examples[1]}",
                 f"③ 경쟁 매장 수와 개·폐업 — 예: {examples[2]}",
                 f"④ 후보 동네 비교 — 예: {examples[3]}",
                 "⑤ 결과를 [📑 보고서 PDF 저장]으로 저장하고 센터 담당자에게 반출 신청 방법을 물어보세요."]
        res.findings += [Finding(s, "key" if i == 0 else "info") for i, s in enumerate(steps)]
        res.guidance = {"kind": "help", "help": HELP, "example_questions": examples, "loaded_now": [d["name"] for d in store.summaries()]}
        res.method = "분석 순서 안내"
        return res

    res = TemplateResult(title="필요한 데이터 안내", subtitle="이 분석을 하려면 어떤 데이터가 있어야 하는지", plan=plan)
    groups: list[list[str]] = []
    if target_template and target_template in TEMPLATE_NEEDS:
        groups = TEMPLATE_NEEDS[target_template]
    elif needed:
        groups = [needed]
    else:
        q = plan.question
        if any(k in q for k in ("시간대", "요일", "몇 시", "주말", "평일", "공휴일")):
            groups = TEMPLATE_NEEDS["time_pattern"]
        elif any(k in q for k in ("유동인구", "방문인구", "인구")):
            groups = TEMPLATE_NEEDS["footfall"]
        elif any(k in q for k in ("매장수", "경쟁", "개업", "폐업", "밀도")):
            groups = TEMPLATE_NEEDS["competition"]
        elif any(k in q for k in ("관광객", "외국인", "중국", "일본")):
            groups = TEMPLATE_NEEDS["tourist"]
        else:
            groups = TEMPLATE_NEEDS["market_summary"]
    optional = OPTIONAL_NEEDS.get(target_template or "", [])
    region_needed = bool(plan.regions)

    items = []
    for grp in groups:
        for i, k in enumerate(grp):
            spec = reg.datasets.get(k)
            if not spec:
                continue
            if region_needed and k not in REGION_ONLY_KEYS and len(grp) > 1:
                continue  # 동네별 분석에는 지역 차원이 없는 데이터는 대안이 못 됨
            loaded = store.get(k)
            items.append({"key": k, "name": spec.name, "source": spec.source, "export": spec.export, "category": spec.category,
                          "description": spec.description, "download_guide": spec.download_guide, "url": spec.url,
                          "loaded": loaded is not None, "origin": loaded.origin if loaded else None, "period": f"{loaded.period[0]}~{loaded.period[1]}" if loaded and loaded.period[0] else None,
                          "role": "이 중 하나만 있으면 됩니다" if len(grp) > 1 else "꼭 필요", "alternative": i > 0})
    for k in optional:
        spec = reg.datasets.get(k)
        if spec:
            loaded = store.get(k)
            items.append({"key": k, "name": spec.name, "source": spec.source, "export": spec.export, "category": spec.category, "description": spec.description,
                          "download_guide": spec.download_guide, "url": spec.url, "loaded": loaded is not None, "origin": loaded.origin if loaded else None,
                          "period": None, "role": "있으면 분석이 더 풍부해집니다(선택)", "alternative": False})

    months = months_between(plan.period.start, plan.period.end) if plan.period else []
    cond = {"period": plan.period.label if plan.period else "최근 12개월", "months": months, "regions": plan.regions, "region_label": plan.region_label,
            "note": "센터 데이터는 한 달 단위로 내려받습니다. 작년과 비교하려면 작년 같은 달도 함께 받으세요. 동네(읍면동)를 지정하지 않으면 제주 전체가 한 파일로 내려받아집니다."}
    steps = [
        "센터 담당자에게 “이 데이터가 필요해요”라고 아래 표를 보여 주세요. (담당자가 센터 PC의 데이터 검색 화면에서 받아 드립니다)",
        "받은 파일을 이 프로그램의 데이터 폴더(data/inbox)에 넣고 왼쪽의 [데이터 다시 읽기]를 누르거나, [데이터 파일 넣기]로 파일을 고릅니다.",
        "같은 질문을 다시 입력하면 분석이 실행됩니다.",
        "보고서를 밖으로 가져가려면 [📑 보고서 PDF 저장] 후 센터 시스템에서 ‘반출 신청’을 합니다. 보고서의 ‘개인정보 보호 확인’ 절이 심사에 도움이 됩니다.",
    ]
    examples = []
    for it in items:
        examples += EXAMPLE_QUESTIONS.get(it["key"], [])
    res.guidance = {"kind": "data", "items": items, "conditions": cond, "steps": steps, "example_questions": list(dict.fromkeys(examples))[:6],
                    "loaded_now": [d["name"] for d in store.summaries()]}
    missing_required = [it for it in items if not it["loaded"] and it["role"] != "있으면 분석이 더 풍부해집니다(선택)"]
    any_required_loaded = any(it["loaded"] for it in items if it["role"] != "있으면 분석이 더 풍부해집니다(선택)")
    if missing_required and not any_required_loaded:
        names = " 또는 ".join(dict.fromkeys(it["name"] for it in missing_required[:3]))
        res.findings.append(Finding(f"이 분석에는 ‘{names}’ 데이터가 필요한데 아직 들어 있지 않습니다. 담당자에게 요청해 주세요.", "warn"))
    else:
        res.findings.append(Finding("필요한 데이터가 들어 있습니다. 질문을 다시 입력하면 분석을 실행합니다.", "info"))
    if plan.period and not plan.period.explicit:
        res.findings.append(Finding("기간을 쓰지 않으면 들어 있는 데이터의 최근 12개월을 사용합니다.", "info"))
    res.method = "데이터셋 레지스트리(datasets.yaml)와 현재 데이터함 상태를 대조해 안내합니다."
    return res

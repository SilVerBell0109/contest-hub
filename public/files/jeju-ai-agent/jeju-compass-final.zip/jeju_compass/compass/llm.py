"""LLM 클라이언트 + 데이터 전송 가드(Privacy Gate) + 전송 내역 감사 로그.

원칙
- LLM에는 (1) 사용자 질문, (2) 데이터셋 메타데이터(컬럼명·설명·지역/업종 사전), (3) 반출 검수를 통과한 집계표만 보냅니다.
- 원본 행(row) 데이터, 파일, 비공개 처리된 셀의 값은 어떤 경우에도 전송하지 않습니다.
- 모든 호출은 logs/llm_audit.jsonl 에 기록됩니다(시각, 목적, 제공자, 모델, 전송 문자 수, 포함된 표 이름·행 수, 해시).
- API 키는 환경변수(.env)에서만 읽으며 코드·로그·보고서에 기록하지 않습니다.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

log = logging.getLogger(__name__)

PROVIDER_ENDPOINTS = {
    "openai": "https://api.openai.com/v1",
    "anthropic": "https://api.anthropic.com/v1",
    "gemini": "https://generativelanguage.googleapis.com/v1beta",
}
# 2026-11 기준 각사 '저가·소형' 모델. gpt-5-mini는 2026-12-11 API 종료 예정(공식 대체: gpt-5.6-terra).
# LLM_MODEL 환경변수로 언제든 바꿀 수 있다(예: gpt-6-luna, claude-sonnet-5-5, gemini-3.1-flash-lite).
DEFAULT_MODELS = {"openai": "gpt-5.6-terra", "anthropic": "claude-haiku-5-5", "gemini": "gemini-3.5-flash-lite"}


@dataclass
class LLMConfig:
    provider: str = "none"          # openai | anthropic | gemini | mock | none
    api_key: str = ""
    model: str = ""
    base_url: str = ""
    timeout: int = 60
    narrative: bool = True          # 결과 해설 생성에 LLM 사용 여부
    max_rows_per_table: int = 60
    max_tables: int = 4

    @property
    def enabled(self) -> bool:
        if self.provider in ("mock",):
            return True
        return self.provider in PROVIDER_ENDPOINTS and bool(self.api_key)


def load_config() -> LLMConfig:
    try:
        from dotenv import load_dotenv
        load_dotenv(override=False)
    except Exception:  # noqa: BLE001
        pass
    provider = (os.getenv("LLM_PROVIDER") or "none").strip().lower()
    key = (os.getenv("LLM_API_KEY") or os.getenv("OPENAI_API_KEY") or os.getenv("ANTHROPIC_API_KEY") or os.getenv("GEMINI_API_KEY") or "").strip()
    if provider == "none" and key:
        if os.getenv("OPENAI_API_KEY"):
            provider = "openai"
        elif os.getenv("ANTHROPIC_API_KEY"):
            provider = "anthropic"
        elif os.getenv("GEMINI_API_KEY"):
            provider = "gemini"
    model = (os.getenv("LLM_MODEL") or DEFAULT_MODELS.get(provider, "")).strip()
    return LLMConfig(provider=provider, api_key=key, model=model, base_url=(os.getenv("LLM_BASE_URL") or "").strip(),
                     timeout=int(os.getenv("LLM_TIMEOUT") or 60), narrative=(os.getenv("LLM_NARRATIVE", "true").lower() != "false"),
                     max_rows_per_table=int(os.getenv("LLM_MAX_ROWS") or 60))


# ── 전송 가드 ───────────────────────────────────────────────────────────────
_SENSITIVE_PATTERNS = [
    (re.compile(r"(?<![\d.])\d{13,19}(?![\d.])"), "[숫자열 마스킹]"),        # 카드·계좌 번호 형태(소수점 숫자는 제외)
    (re.compile(r"\b\d{6}-\d{7}\b"), "[주민번호 마스킹]"),
    (re.compile(r"(sk|key)-[A-Za-z0-9]{16,}"), "[키 마스킹]"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "[이메일 마스킹]"),
    (re.compile(r"\b01[016789]-?\d{3,4}-?\d{4}\b"), "[전화번호 마스킹]"),
]


def redact(text: str) -> tuple[str, int]:
    """자유 텍스트의 민감 패턴 마스킹."""
    n = 0
    for pat, rep in _SENSITIVE_PATTERNS:
        text, k = pat.subn(rep, text)
        n += k
    return text, n


def redact_obj(obj):
    """JSON 구조에서 문자열 값만 마스킹한다(숫자 값은 그대로 — 큰 금액이 카드번호로 오인되어 깨지지 않게)."""
    n = 0
    if isinstance(obj, str):
        return redact(obj)
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            v2, k2 = redact_obj(v)
            out[k] = v2
            n += k2
        return out, n
    if isinstance(obj, (list, tuple)):
        out = []
        for v in obj:
            v2, k2 = redact_obj(v)
            out.append(v2)
            n += k2
        return out, n
    return obj, 0


def _redact_text_or_json(text: str) -> tuple[str, int]:
    """JSON으로 해석되면 문자열 필드만, 아니면 전체 텍스트를 마스킹."""
    t = text.lstrip()
    if t[:1] in ("{", "["):
        try:
            obj = json.loads(text)
        except json.JSONDecodeError:
            return redact(text)
        obj, n = redact_obj(obj)
        return json.dumps(obj, ensure_ascii=False, default=str), n
    return redact(text)


class PrivacyViolation(Exception):
    pass


def serialize_safe_tables(tables, max_rows: int = 60, max_tables: int = 4) -> tuple[list[dict], list[dict]]:
    """반출 검수를 통과한 표만 LLM 전송용 레코드로 직렬화. (payload, meta)"""
    from .sdc import safe_records
    payload, meta = [], []
    for t in tables:
        if t.sdc is None:
            continue
        if not t.sdc.passed:
            continue
        if not t.sdc.verified and t.min_cell > 0:
            continue
        if len(payload) >= max_tables:
            break
        recs = safe_records(t.sdc, max_rows=max_rows)
        payload.append({"table": t.name, "rows": recs, "note": "null = 반출 기준에 따라 비공개 처리된 셀"})
        meta.append({"table": t.name, "rows": len(recs), "suppressed": t.sdc.n_suppressed + t.sdc.n_secondary})
    return payload, meta


# ── 클라이언트 ──────────────────────────────────────────────────────────────
class LLMClient:
    def __init__(self, cfg: LLMConfig | None = None, audit_path: Path | str = "logs/llm_audit.jsonl", mock_handler: Callable[[str, str, str], str] | None = None):
        self.cfg = cfg or load_config()
        self.audit_path = Path(audit_path)
        self.mock_handler = mock_handler
        self.last_error: str | None = None
        self._calls = 0
        self._errors = 0

    @property
    def available(self) -> bool:
        return self.cfg.enabled

    def status(self) -> dict:
        return {"provider": self.cfg.provider, "model": self.cfg.model, "enabled": self.available, "narrative": self.cfg.narrative,
                "key_present": bool(self.cfg.api_key), "last_error": self.last_error, "calls": self._calls, "errors": self._errors}

    # 감사 로그 ------------------------------------------------------------
    def _audit(self, purpose: str, payload: str, meta: list[dict], status: str, latency: float, redactions: int, response_chars: int = 0):
        self.audit_path.parent.mkdir(parents=True, exist_ok=True)
        rec = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "purpose": purpose, "provider": self.cfg.provider, "model": self.cfg.model,
               "chars_sent": len(payload), "sha256": hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16], "tables": meta,
               "redactions": redactions, "status": status, "latency_s": round(latency, 2), "response_chars": response_chars}
        with self.audit_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return rec

    def recent_audit(self, n: int = 20) -> list[dict]:
        if not self.audit_path.exists():
            return []
        lines = self.audit_path.read_text(encoding="utf-8").strip().splitlines()[-n:]
        out = []
        for ln in lines:
            try:
                out.append(json.loads(ln))
            except json.JSONDecodeError:
                continue
        return out

    # 호출 ---------------------------------------------------------------
    def complete(self, system: str, user: str, purpose: str, meta: list[dict] | None = None, json_mode: bool = False, max_tokens: int = 2000) -> str | None:
        if not self.available:
            return None
        user, n_red = _redact_text_or_json(user)
        system, n_red2 = redact(system)
        t0 = time.time()
        try:
            if self.cfg.provider == "mock":
                out = self.mock_handler(system, user, purpose) if self.mock_handler else "{}"
            elif self.cfg.provider == "openai":
                out = self._openai(system, user, json_mode, max_tokens)
            elif self.cfg.provider == "anthropic":
                out = self._anthropic(system, user, max_tokens)
            elif self.cfg.provider == "gemini":
                out = self._gemini(system, user, json_mode, max_tokens)
            else:
                return None
            self.last_error = None
            self._calls += 1
            self._audit(purpose, system + "\n" + user, meta or [], "ok", time.time() - t0, n_red + n_red2, len(out or ""))
            return out
        except Exception as e:  # noqa: BLE001
            self._calls += 1
            self._errors += 1
            self.last_error = f"{type(e).__name__}: {e}"[:300]
            log.warning("LLM 호출 실패(%s): %s", purpose, self.last_error)
            self._audit(purpose, system + "\n" + user, meta or [], f"error: {self.last_error}", time.time() - t0, n_red + n_red2)
            return None

    def _openai(self, system, user, json_mode, max_tokens):
        import requests
        base = self.cfg.base_url or PROVIDER_ENDPOINTS["openai"]
        body = {"model": self.cfg.model, "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        headers = {"Authorization": f"Bearer {self.cfg.api_key}", "Content-Type": "application/json"}
        # 2025년 이후 모델(gpt-5.x 계열)은 max_completion_tokens + reasoning_effort를 쓰고 temperature를 받지 않는다.
        # 구형·호환 서버(temperature/max_tokens)도 쓸 수 있게 400 응답의 파라미터 오류일 때만 다음 조합으로 재시도한다.
        attempts = [{"max_completion_tokens": max_tokens, "reasoning_effort": "low"},
                    {"max_completion_tokens": max_tokens},
                    {"max_tokens": max_tokens, "temperature": 0}]
        last = None
        for extra in attempts:
            r = requests.post(f"{base}/chat/completions", headers=headers, json={**body, **extra}, timeout=self.cfg.timeout)
            if r.status_code == 400 and any(k in r.text for k in ("max_tokens", "max_completion_tokens", "temperature", "reasoning_effort", "reasoning")):
                last = r
                continue
            if r.status_code in (404, 405) and not self.cfg.base_url:
                return self._openai_responses(system, user, json_mode, max_tokens)   # chat/completions가 사라진 경우 Responses API
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
        last.raise_for_status()
        return ""

    def _openai_responses(self, system, user, json_mode, max_tokens):
        import requests
        base = self.cfg.base_url or PROVIDER_ENDPOINTS["openai"]
        body = {"model": self.cfg.model, "instructions": system, "input": user, "max_output_tokens": max_tokens}
        if json_mode:
            body["text"] = {"format": {"type": "json_object"}}
        r = requests.post(f"{base}/responses", headers={"Authorization": f"Bearer {self.cfg.api_key}", "Content-Type": "application/json"}, json=body, timeout=self.cfg.timeout)
        r.raise_for_status()
        data = r.json()
        if data.get("output_text"):
            return data["output_text"]
        parts = []
        for item in data.get("output", []):
            for c in item.get("content", []) or []:
                if c.get("type") in ("output_text", "text"):
                    parts.append(c.get("text", ""))
        return "".join(parts)

    def _anthropic(self, system, user, max_tokens):
        import requests
        base = self.cfg.base_url or PROVIDER_ENDPOINTS["anthropic"]
        body = {"model": self.cfg.model, "max_tokens": max_tokens, "system": system, "messages": [{"role": "user", "content": user}]}   # temperature는 기본값 사용(일부 모델이 거부)
        r = requests.post(f"{base}/messages", headers={"x-api-key": self.cfg.api_key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"}, json=body, timeout=self.cfg.timeout)
        r.raise_for_status()
        data = r.json()
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")

    def _gemini(self, system, user, json_mode, max_tokens):
        import requests
        base = self.cfg.base_url or PROVIDER_ENDPOINTS["gemini"]
        body = {"systemInstruction": {"parts": [{"text": system}]}, "contents": [{"role": "user", "parts": [{"text": user}]}],
                "generationConfig": {"temperature": 0, "maxOutputTokens": max_tokens, **({"responseMimeType": "application/json"} if json_mode else {})}}
        # 키는 URL이 아니라 헤더로 보낸다(프록시·서버 로그에 키가 남지 않게)
        r = requests.post(f"{base}/models/{self.cfg.model}:generateContent", headers={"x-goog-api-key": self.cfg.api_key, "Content-Type": "application/json"}, json=body, timeout=self.cfg.timeout)
        r.raise_for_status()
        data = r.json()
        return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"])


def extract_json(text: str) -> dict | None:
    """LLM 응답에서 JSON 객체를 추출(코드블록·앞뒤 설명 허용)."""
    if not text:
        return None
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        try:
            cleaned = re.sub(r",\s*([}\]])", r"\1", m.group(0))
            return json.loads(cleaned)
        except json.JSONDecodeError:
            return None

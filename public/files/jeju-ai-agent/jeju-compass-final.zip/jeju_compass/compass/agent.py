"""오케스트레이터: 질문 → 계획 → (되묻기/데이터 확인) → 분석 템플릿 실행 → 반출 검수 → 차트 → (LLM 해설) → 보고서.

자율 수행 범위
- 한다: 템플릿 선택, 지역·업종·기간 해석, 작은 셀의 범주 상향/비공개 처리, 차트·표 선택, 해설 작성, 보고서 저장, 모호할 때 되묻기
- 하지 않는다: 원본 데이터 외부 전송, 반출 신청 제출, 원본 파일 수정, 적재된 실제 데이터와 샘플 데이터 혼합
"""
from __future__ import annotations

import itertools
import json
import logging
import re
import time
from dataclasses import dataclass
from pathlib import Path

from . import charts, report
from .llm import LLMClient, serialize_safe_tables
from .loader import DataStore
from .planner import make_plan, plan_from_override
from .linked import guard_report
from .templates.common import refresh_display
from .sdc import numeric_frame
from .templates import CATALOG, run_template, MissingData
from .templates.base import Plan, TemplateResult, Finding
from .templates.common import LABELS

log = logging.getLogger(__name__)
_seq = itertools.count(1)

_NARR_SYSTEM = """당신은 제주빅데이터센터에서 도민·기관·사업자의 데이터 분석을 돕는 분석가입니다.
아래 '집계표'와 '요약 문장'만을 근거로, 사업계획서나 현황자료에 바로 넣을 수 있는 한국어 해설을 작성하세요.
규칙:
- 표에 있는 수치만 사용하고, 없는 수치·비율을 추정하거나 지어내지 않습니다. null 셀은 '비공개'로만 언급합니다.
- 5~8문장, 두 단락 이내. 첫 문장은 핵심 결론. 마지막 문장은 활용 시 유의사항 한 줄.
- 과장·단정 표현을 피하고, 원인 추정은 '~로 보입니다' 수준으로만 씁니다.
- 숫자는 억/만 단위로 읽기 쉽게 표기합니다 (예: 3억 2,000만원, 12.3%). 연월은 '2026년 8월'처럼 씁니다."""


@dataclass
class AnalysisRun:
    run_id: str
    out_dir: Path
    payload: dict

    @property
    def html_path(self) -> Path:
        return self.out_dir / "report.html"


class Agent:
    def __init__(self, store: DataStore, llm: LLMClient | None = None, out_root: Path | str = "outputs"):
        self.store = store
        self.llm = llm or LLMClient()
        self.out_root = Path(out_root)
        self.out_root.mkdir(parents=True, exist_ok=True)
        self.runs: dict[str, AnalysisRun] = {}

    # ── 실행 ───────────────────────────────────────────────────────────────
    def ask(self, question: str, override: dict | None = None, base_plan: Plan | None = None, force: bool = False) -> AnalysisRun:
        """질문을 처리한다. force=True면 되묻기 없이 현재 해석으로 바로 분석한다."""
        t_start = time.time()
        question = (question or "").strip()
        if not question:
            raise ValueError("질문이 비어 있습니다")
        if override and base_plan is not None:
            plan = plan_from_override(base_plan, override, self.store)
        else:
            plan = make_plan(question, self.store, self.llm)
        if plan.clarify and not force and plan.template != "navigator":
            return self._clarify(plan, t_start)
        if not self.store.datasets and plan.template != "navigator":
            plan.options["target_template"] = plan.template
            plan.options["needed_keys"] = CATALOG[plan.template]["needs"]
            plan.template = "navigator"
        try:
            result = run_template(plan.template, self.store, plan)
        except MissingData as e:
            plan.options["target_template"] = plan.template
            plan.options["needed_keys"] = e.needed_keys
            plan.template = "navigator"
            result = run_template("navigator", self.store, plan)
        return self._finish(result, plan, t_start)

    def rerun(self, run_id: str, override: dict) -> AnalysisRun:
        prev = self.runs.get(run_id)
        if prev is None:
            raise KeyError(run_id)
        base = prev.payload["_plan_obj"]
        return self.ask(base.question, override=override, base_plan=base, force=True)

    # ── 되묻기 ─────────────────────────────────────────────────────────────
    def _clarify(self, plan: Plan, t_start: float) -> AnalysisRun:
        run_id = self._new_run_id("clarify")
        out_dir = self.out_root / run_id
        out_dir.mkdir(parents=True, exist_ok=True)
        c = plan.clarify or {}
        payload = {
            "run_id": run_id, "ok": True, "kind": "clarify", "title": "확인이 필요해요", "subtitle": f"질문: “{plan.question}”", "question": plan.question,
            "plan": {**plan.to_dict(), "template_name": CATALOG.get(plan.template, {}).get("name", plan.template), "period_label": plan.period.label if plan.period else "-", "industry_label": plan.industry_label},
            "clarify": c, "kpis": [], "findings": [{"text": c.get("message", ""), "level": "warn"}], "narrative": None, "charts": [], "tables": [],
            "method": "", "caveats": [], "data_used": [], "guidance": None, "sample": self.store.has_sample(), "sdc_overall": {"passed": True, "min_cell": 10, "tables": []},
            "llm_audit": [], "report_html": None, "elapsed_s": round(time.time() - t_start, 2), "generated_at": time.strftime("%Y-%m-%d %H:%M"),
        }
        (out_dir / "result.json").write_text(json.dumps(payload, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        payload["_plan_obj"] = plan
        run = AnalysisRun(run_id, out_dir, payload)
        self.runs[run_id] = run
        while len(self.runs) > 300:          # 메모리 상한: 오래된 실행 기록부터 비움(파일은 outputs/에 남아 있음)
            self.runs.pop(next(iter(self.runs)))
        return run

    def _new_run_id(self, suffix: str) -> str:
        return time.strftime("%Y%m%d_%H%M%S") + f"_{int(time.time() * 1000) % 1000:03d}{next(_seq) % 1000:03d}_" + re.sub(r"[^0-9A-Za-z가-힣]+", "", suffix)[:12]

    # ── 마무리: 차트·해설·보고서 ─────────────────────────────────────────
    def _finish(self, result: TemplateResult, plan: Plan, t_start: float) -> AnalysisRun:
        run_id = self._new_run_id(plan.template)
        out_dir = self.out_root / run_id
        out_dir.mkdir(parents=True, exist_ok=True)
        chart_dir = out_dir / "charts"
        # 지역·업종·기간 해석 보충 설명을 맨 앞에
        note = plan.options.get("region_note") or ""
        warn = plan.options.get("region_warning") or ""
        iwarn = plan.options.get("industry_warning") or ""
        ignored = plan.options.get("ignored_filters") or ""
        pnote = (plan.period.note if plan.period else "") or ""
        for text, level in ((pnote + "했습니다." if pnote else "", "info"), (ignored, "info"), (iwarn, "warn"), (warn, "warn"), (note, "info")):
            if text:
                result.findings.insert(0, Finding(text, level))
        for im in plan.industries:
            kw = getattr(im, "keyword", "") or ""
            if kw and kw.replace(" ", "") not in im.label.replace(" ", "") and kw not in ("카페", "커피", "한식", "치킨", "숙박", "음식점", "식당"):
                result.findings.insert(0, Finding(f"'{kw}'은(는) '{im.label}' 업종으로 보고 계산했습니다. 다른 업종을 원하면 [✏️ 고칠래요]에서 바꿔 주세요.", "info"))
        if not plan.industries and plan.template in ("market_summary", "time_pattern", "region_compare", "competition", "site_score") and result.ok:
            result.findings.insert(0, Finding("업종을 따로 정하지 않아 모든 업종을 합쳐서 계산했습니다. 특정 업종만 보려면 [✏️ 고칠래요]에서 업종을 넣어 주세요.", "info"))

        # 보고서 단위 연결표 검사: 다른 표·KPI와 조합해 가린 칸이 복원되지 않도록 추가 비공개
        kpi_public = not any(str(k.get("value", "")).startswith(("비공개", "검수 불가")) for k in result.kpis)
        extra, linked_note = guard_report(result.tables, kpi_public)
        for t in result.tables:
            if t.sdc is not None and t.sdc.n_linked:
                refresh_display(t)
        if extra:
            # 추가로 가린 표의 범주(공개 행 포함)를 언급하며 숫자를 말하는 문장은 뺀다 — 가리기 전에 계산된 비율·금액으로 값이 새지 않게
            affected = {e["table"] for e in extra}
            words = set()
            for t in result.tables:
                if t.name in affected and t.sdc is not None:
                    for d in t.sdc.dims:
                        words |= {str(v) for v in t.sdc.table[d].astype(str).tolist() if str(v) not in ("전체", "nan", "")}
            kept = []
            dropped = 0
            for f in result.findings:
                if any(w in f.text for w in words) and re.search(r"\d", f.text):
                    dropped += 1
                    continue
                kept.append(f)
            result.findings = kept
            result.findings.append(Finding(linked_note + (f" (관련 문장 {dropped}개 생략)" if dropped else "") + ".", "info"))

        # 모든 칸이 가려진 표는 표 대신 한 줄 설명으로
        for t in result.tables:
            if t.sdc is not None and not t.hidden and t.sdc.min_cell > 0 and len(t.sdc.table) and bool(t.sdc.table["_suppressed"].all()):
                t.hidden = True
                kinds = set(t.sdc.table["_kind"].astype(str).tolist()) if "_kind" in t.sdc.table.columns else {"P"}
                if kinds <= {"P", "", "nan"}:
                    why = f"인원·건수가 모두 {t.sdc.min_cell} 미만이라"
                else:
                    why = f"{t.sdc.min_cell} 미만인 칸과, 그 칸을 거꾸로 계산해 알아낼 수 있는 칸을 함께 가리고 나니 남는 칸이 없어"
                result.findings.append(Finding(f"'{t.name}' 표는 {why} 개인정보 보호를 위해 보여 드릴 수 없습니다.", "warn"))
        result.charts = [c for c in result.charts if not any(t.name == c.table and t.hidden and t.sdc is not None and bool(t.sdc.table["_suppressed"].all()) for t in result.tables)]

        tables_by_name = {t.name: t for t in result.tables}
        rendered = []
        for spec in result.charts:
            t = tables_by_name.get(spec.table)
            if t is None:
                continue
            r = charts.render(spec, t, chart_dir, LABELS)
            if r:
                rendered.append(r)

        narrative, narrative_meta = None, []
        if self.llm.available and self.llm.cfg.narrative and result.ok and result.tables and plan.template != "navigator":
            narrative, narrative_meta = self._narrate(result, plan)
            if narrative is None and self.llm.last_error:
                # AI 해설 실패는 숨기지 않고 알린다(숫자 분석은 정상) — 담당자가 모델명·키 문제를 바로 알 수 있게
                result.findings.append(Finding(f"AI 설명문을 만들지 못했습니다(원인: {self.llm.last_error[:120]}). 숫자·표·차트는 정상이며, 담당자가 .env의 모델명·키를 확인하면 됩니다.", "info"))

        audit_entries = [a for a in self.llm.recent_audit(10) if a.get("ts", "") >= time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t_start - 1))]
        sample = any(d.get("origin") == "sample" for d in result.data_used) or (self.store.has_sample() and plan.template != "navigator")
        sdc_tables = [{"name": t.name, "summary": t.sdc.summary if t.sdc else "-", "plain": t.sdc.plain if t.sdc else "-", "passed": bool(t.sdc.passed) if t.sdc else False,
                       "verified": bool(t.sdc.verified) if t.sdc else False, "detail": t.sdc.to_dict() if t.sdc else None} for t in result.tables]
        kpi_unverified = any(k.get("verified") is False for k in result.kpis)
        overall_pass = all(x["passed"] for x in sdc_tables) and not kpi_unverified if sdc_tables else not kpi_unverified
        min_cell = max([t.min_cell for t in result.tables] + [0]) or 10
        n_hidden = sum((t.sdc.n_suppressed + t.sdc.n_secondary) for t in result.tables if t.sdc)
        rolled = any(t.sdc.rolled for t in result.tables if t.sdc)
        if not overall_pass:
            plain = "자동 확인을 못 한 표가 있어 담당자 확인이 필요합니다"
        elif n_hidden == 0 and not rolled:
            plain = f"{min_cell}명 미만인 칸이 없어 모든 수치를 그대로 보여 드립니다"
        else:
            plain = ("일부 항목을 큰 묶음으로 합쳤고 " if rolled else "") + (f"{n_hidden}칸은 개인정보 보호를 위해 가렸습니다" if n_hidden else "모든 칸이 기준을 충족합니다")

        ctx = {
            "title": result.title, "subtitle": result.subtitle, "question": plan.question, "generated_at": time.strftime("%Y-%m-%d %H:%M"),
            "plan": {**plan.to_dict(), "template_name": CATALOG.get(plan.template, {}).get("name", plan.template), "period_label": plan.period.label if plan.period else "-", "industry_label": plan.industry_label},
            "kpis": result.kpis, "findings": [{"text": f.text, "level": f.level} for f in result.findings], "narrative": narrative,
            "charts": [{"title": c["title"], "b64": report.img_b64(c["path"]), "path": c["path"], "filename": c["filename"]} for c in rendered],
            "tables": [{"name": t.name, "html": report.table_html(t.display), "note": t.note, "sdc": {"passed": t.sdc.passed, "summary": t.sdc.summary, "plain": t.sdc.plain}} for t in result.tables if not t.hidden and t.display is not None],
            "method": result.method, "caveats": result.caveats, "data_used": result.data_used, "guidance": result.guidance, "sample": sample,
            "sdc_overall": {"passed": overall_pass, "min_cell": min_cell, "tables": sdc_tables, "plain": plain, "n_hidden": n_hidden}, "llm_audit": audit_entries,
        }
        html = report.render_html(ctx)
        (out_dir / "report.html").write_text(html, encoding="utf-8")

        payload = {
            "run_id": run_id, "ok": result.ok, "kind": "result", "title": result.title, "subtitle": result.subtitle, "question": plan.question, "plan": ctx["plan"],
            "kpis": result.kpis, "findings": ctx["findings"], "narrative": narrative,
            "charts": [{"title": c["title"], "url": f"/outputs/{run_id}/charts/{c['filename']}", "filename": c["filename"]} for c in rendered],
            "tables": [{"name": t.name, "columns": list(t.display.columns), "rows": t.display.values.tolist(), "sdc": t.sdc.to_dict(), "note": t.note} for t in result.tables if not t.hidden and t.display is not None],
            "method": result.method, "caveats": result.caveats, "data_used": result.data_used, "guidance": result.guidance, "sample": sample,
            "sdc_overall": ctx["sdc_overall"], "llm_audit": audit_entries, "report_html": f"/outputs/{run_id}/report.html", "report_dir": str(out_dir),
            "elapsed_s": round(time.time() - t_start, 2), "generated_at": ctx["generated_at"], "clarify": None,
        }
        (out_dir / "result.json").write_text(json.dumps(payload, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        # 집계표 CSV: 수치형(재사용용, 비공개 칸은 빈칸+플래그)
        for t in result.tables:
            if t.sdc is not None and not t.hidden:
                safe_name = re.sub(r"[^0-9A-Za-z가-힣_]+", "_", t.name)[:40]
                numeric_frame(t.sdc, LABELS).to_csv(out_dir / f"table_{safe_name}.csv", index=False, encoding="utf-8-sig")
        payload["_plan_obj"] = plan
        run = AnalysisRun(run_id, out_dir, payload)
        self.runs[run_id] = run
        while len(self.runs) > 300:          # 메모리 상한: 오래된 실행 기록부터 비움(파일은 outputs/에 남아 있음)
            self.runs.pop(next(iter(self.runs)))
        return run

    def _narrate(self, result: TemplateResult, plan: Plan) -> tuple[str | None, list[dict]]:
        tables, meta = serialize_safe_tables([t for t in result.tables if not t.hidden], self.llm.cfg.max_rows_per_table, self.llm.cfg.max_tables)
        if not tables:
            return None, []
        kpis = [{"항목": k["label"], "값": k["value"], "전년대비%": k.get("delta"), "비교기준": k.get("delta_label")} for k in result.kpis if not str(k.get("value", "")).startswith(("비공개", "검수 불가"))]
        user = json.dumps({"질문": plan.question, "분석": CATALOG[plan.template]["name"], "지역": plan.region_label, "업종": plan.industry_label,
                           "기간": plan.period.label if plan.period else "", "핵심지표": kpis,
                           "요약문장": [f.text for f in result.findings], "집계표": tables, "유의사항": result.caveats[:3]}, ensure_ascii=False, default=str)
        out = self.llm.complete(_NARR_SYSTEM, user, purpose="narrative", meta=meta, max_tokens=700)
        return (out.strip() if out else None), meta

    # ── PDF ────────────────────────────────────────────────────────────────
    def to_pdf(self, run_id: str) -> tuple[Path | None, str]:
        run = self.runs.get(run_id)
        html_path = (self.out_root / run_id / "report.html") if run is None else run.html_path
        if not html_path.exists():
            return None, "report.html 없음"
        # 파일 이름에 동네·업종·분석 종류·날짜를 넣어 여러 보고서를 구분할 수 있게 한다
        title = (run.payload.get("title") if run else None) or "보고서"
        safe = re.sub(r"[^0-9A-Za-z가-힣_·]+", "_", title).strip("_")[:50] or "보고서"
        pdf_path = html_path.parent / f"보고서_{safe}_{time.strftime('%Y-%m-%d')}.pdf"
        ok, how = report.html_to_pdf(html_path, pdf_path)
        return (pdf_path if ok else None), how

    def public_payload(self, run_id: str) -> dict | None:
        run = self.runs.get(run_id)
        if run is None:
            p = self.out_root / run_id / "result.json"
            return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
        return {k: v for k, v in run.payload.items() if not k.startswith("_")}

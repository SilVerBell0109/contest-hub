"""제주데이터허브 Open API 연동 (선택 기능).

- 허브 로그인 → 데이터 '프로젝트 담기' → 프로젝트 키 발급 → .env의 JEJU_HUB_PROJECT_KEY 에 입력
- 요청 형식: https://open.jejudatahub.net/api/proxy/{dataId}/{projectKey}?startDate=...&endDate=...  (일일 쿼터 1,000건)
- 응답 JSON에서 '레코드 목록'을 찾아 DataFrame으로 만들고 레지스트리로 종류를 판정해 데이터함에 넣습니다.
- 센터 PC에서 호출할 때는 센터 보안정책(허용 주소)의 영향을 받을 수 있으므로 기획서에 주소를 명시해 두었습니다.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

import pandas as pd

HUB_BASE = "https://open.jejudatahub.net/api/proxy"

# 레지스트리 키 → 허브 데이터 ID (허브 상세 페이지 '요청 URL'의 경로 값)
HUB_DATA_IDS = {
    "hub_footfall_api": "Daaa1t3at3tt8a8DD3t55538t35Dab1t",      # 읍면동 단위 내국인 유동인구 (#583, YYYYMMDD)
    "hub_tourist_card_api": "5D5a577taba7tbb71at1b1bt9tatata9",  # 내국인 관광객 지역·업종·성별·연령대별 카드 이용 (#597, YYYYMM)
}
DATE_FORMAT = {"hub_footfall_api": "YYYYMMDD", "hub_tourist_card_api": "YYYYMM"}


@dataclass
class HubFetchResult:
    key: str
    rows: int
    df: pd.DataFrame
    note: str


def _find_records(obj) -> list[dict] | None:
    """응답 JSON 어디에 있든 dict 목록을 찾는다."""
    if isinstance(obj, list):
        if obj and all(isinstance(x, dict) for x in obj):
            return obj
        for x in obj:
            r = _find_records(x)
            if r:
                return r
    elif isinstance(obj, dict):
        for k in ("data", "items", "list", "result", "results", "rows", "records"):
            if k in obj:
                r = _find_records(obj[k])
                if r:
                    return r
        for v in obj.values():
            r = _find_records(v)
            if r:
                return r
    return None


def fetch(key: str, start: str, end: str, params: dict | None = None, project_key: str | None = None, timeout: int = 60, max_pages: int = 50) -> HubFetchResult:
    import requests
    pk = project_key or os.getenv("JEJU_HUB_PROJECT_KEY", "").strip()
    if not pk:
        raise ValueError("JEJU_HUB_PROJECT_KEY 가 설정되지 않았습니다 (.env 참고)")
    if key not in HUB_DATA_IDS:
        raise ValueError(f"지원하지 않는 허브 데이터: {key}")
    url = f"{HUB_BASE}/{HUB_DATA_IDS[key]}/{pk}"
    q = {"startDate": start, "endDate": end, **(params or {})}
    frames: list[pd.DataFrame] = []
    note = ""
    page = 1
    while page <= max_pages:
        r = requests.get(url, params={**q, "number": page} if page > 1 else q, timeout=timeout)
        r.raise_for_status()
        try:
            data = r.json()
        except ValueError as e:
            raise ValueError(f"허브 응답이 JSON이 아닙니다: {r.text[:120]}") from e
        recs = _find_records(data)
        if not recs:
            if page == 1:
                note = f"응답에 레코드가 없습니다: {str(data)[:160]}"
            break
        frames.append(pd.DataFrame(recs))
        # 페이지 정보가 있으면 따라가고, 없으면 1페이지로 종료
        total_pages = None
        if isinstance(data, dict):
            for k in ("totalPages", "total_pages", "pageCount"):
                if k in data:
                    total_pages = int(data[k])
        if not total_pages or page >= total_pages:
            break
        page += 1
    df = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    return HubFetchResult(key, len(df), df, note or f"{page}페이지 수신")

"""플래너: 자연어 질문 → 분석 계획(Plan).

1) 규칙 기반 플래너(항상 실행): 지역·업종·기간·분석 유형을 사전과 패턴으로 해석 → API 키가 없어도 동작
2) LLM 플래너(키가 있을 때): 템플릿 선택과 질문 속 표현(지역/업종/기간 문구) 추출을 LLM에 맡기되,
   실제 매핑(법정동 코드, 업종 코드, 연월)은 항상 우리 사전·파서가 수행 → 결과가 검증 가능하고 재현됨
3) 되묻기: 지역을 모르거나('우리 동네', 사전에 없는 지명), 질문이 너무 짧거나, 답할 수 없는 정보(월세 등)면
   분석 대신 확인 질문/안내를 돌려준다(Plan.clarify).
"""
from __future__ import annotations

import json
import re

from . import geo, industries, textutil
from .llm import LLMClient, extract_json
from .loader import DataStore
from .templates import CATALOG, catalog_for_llm
from .templates.base import Plan
from .templates.navigator import UNSUPPORTED_WORDS

_TEMPLATE_RULES: list[tuple[str, list[str]]] = [
    ("site_score", ["입지", "후보지", "창업후보", "어디가좋", "어디가나", "어디가낫", "어디가유리", "어디에차릴", "어디에열", "어디다내", "어디다낼", "어디에낼", "출점", "추천해", "스코어",
                    "후보비교", "창업하기좋", "창업할만", "어디가유망", "2호점", "분점", "낼까", "차릴까", "열까", "어디가더", "어디로할", "어디서할"]),
    ("time_pattern", ["시간대", "몇시", "요일", "주말", "평일", "공휴일", "피크", "바쁜시간", "손님이많은시간", "시간별", "언제손님", "언제많", "몇시에",
                      "저녁장사", "아침장사", "점심장사", "밤장사", "야간", "새벽", "낮시간", "저녁에", "점심에", "아침에", "밤에"]),
    ("competition", ["매장수", "매장이몇", "경쟁", "밀도", "개업", "폐업", "포화", "경쟁업체", "가게수", "점포수", "너무많", "몇개", "몇곳", "몇군데", "얼마나많", "많은거아니", "많은건아니",
                     "망하", "망한", "문닫", "문을닫", "새로생", "새로연", "오픈", "개점"]),
    ("footfall", ["유동인구", "방문인구", "거주인구", "근무인구", "인구", "사람많이", "사람이많이", "사람이많", "붐비", "오가는사람", "지나다니"]),
    ("tourist", ["관광객", "외국인", "중국인", "일본인", "동남아", "국적", "도민과", "도민vs", "내국인관광", "관광소비", "외국사람"]),
    ("region_compare", ["비교", "순위", "랭킹", "어느동네", "어느지역", "어디가가장", "가장많은지역", "지역별", "동네별", "읍면별", "읍면동별", "어디서많이", "어디가제일", "제일많은곳", "가장큰곳",
                        "데가어디", "곳이어디", "동네가어디", "어디야", "어디예요", "어디에요", "어디인가", "어디입니까", "어디냐"]),
]
_HELP_WORDS = ("도움말", "사용법", "어떻게써", "어떻게사용", "뭘물어", "무엇을물어", "뭘할수있", "무엇을할수있", "help", "설명서", "사용방법", "어떻게하는", "처음인데", "뭐부터")
_HOWTO_WORDS = ("뭘봐야", "무엇을봐야", "뭘확인", "어떻게준비", "뭘알아봐야", "뭐를봐야", "어떤걸봐야", "뭘따져", "체크리스트")
_WHOLE_WORDS = ("제주전체", "제주도전체", "도전체", "전체지역", "모든지역", "제주도", "제주시", "서귀포", "섬전체", "전지역", "제주다합쳐", "제주전부")
# 지역 없이 '어디가/순위/높은 동네' 등을 물으면 제주 전체를 대상으로 한 순위·비교 질문으로 본다
_RANKING_CUE = re.compile(r"어디|순위|어느|상위|탑\d|top\d|(높은|많은|잘되는|잘되|좋은|센|큰)(동네|지역|곳|데)|동네는|지역은|곳은|데가|데는|랭킹", re.I)
# 업종이 꼭 필요한 분석(업종을 말하지 않으면 되묻기)
_INDUSTRY_TEMPLATES = ("market_summary", "time_pattern", "region_compare", "competition", "site_score")
_INDUSTRY_OPTIONS = ("카페", "한식 음식점", "치킨", "숙박", "음식점 전체", "전체 업종")
# 제주 밖 지명(사전에 없는 지명 중 흔한 것) → '볼 수 없어요' 안내
_NOT_JEJU = ("서울", "강남", "홍대", "부산", "대구", "인천", "광주", "대전", "울산", "세종", "경기", "강원", "충청", "충북", "충남", "전라", "전북", "전남", "경상", "경북", "경남",
             "수원", "성남", "용인", "고양", "창원", "청주", "천안", "전주", "포항", "김해", "일산", "분당", "판교", "해운대", "명동", "이태원", "건대", "신촌", "잠실")

_DATA_WORDS = ("어떤데이터", "데이터가필요", "필요한데이터", "데이터는어디", "데이터어디", "어디서받", "어디서다운", "다운로드", "데이터목록", "무슨데이터", "데이터안내",
               "어떤자료", "자료가필요", "필요한자료", "데이터를어떻게", "데이터준비", "데이터넣", "파일넣", "어떤파일", "데이터셋")


def _clean(q: str) -> str:
    return q.replace(" ", "")


def rule_based_plan(question: str, store: DataStore) -> Plan:
    q = _clean(question)
    latest = store.latest_month()
    earliest = None
    for d in store.datasets.values():
        p = d.period
        if p[0] and (earliest is None or p[0] < earliest):
            earliest = p[0]
    rm = geo.resolve_regions(question)
    inds = industries.resolve_industries(question)
    period = textutil.parse_period(question, latest, earliest)

    # 0) 도움말 / 분석 순서 안내 / 답할 수 없는 정보
    if any(w in q.lower() for w in _HELP_WORDS):
        return Plan(template="navigator", question=question, period=period, options={"mode": "help"}, source="rule", confidence=0.95, reasoning="도움말 요청")
    for word, topic in UNSUPPORTED_WORDS.items():
        if _unsupported_hit(word, q):
            return Plan(template="navigator", question=question, regions=rm.regions, region_label=rm.label, region_scope=rm.scope, industries=inds, period=period,
                        options={"mode": "unsupported", "unsupported_topic": topic, "unsupported_word": word}, source="rule", confidence=0.95, reasoning=f"지원하지 않는 정보({topic}) 요청")
    if any(w in q for w in _HOWTO_WORDS) or (("창업" in q or "개업" in q) and any(w in q for w in ("하려면", "하려는데", "준비", "시작"))):
        return Plan(template="navigator", question=question, regions=rm.regions, region_label=rm.label, region_scope=rm.scope, industries=inds, period=period,
                    options={"mode": "howto"}, source="rule", confidence=0.9, reasoning="분석 순서 안내 요청")
    if any(w in q for w in _DATA_WORDS):
        target = "market_summary"
        for key, kws in _TEMPLATE_RULES:
            if any(k in q for k in kws):
                target = key
                break
        return Plan(template="navigator", question=question, regions=rm.regions, region_label=rm.label, region_scope=rm.scope, industries=inds, period=period,
                    options={"mode": "data", "target_template": target}, source="rule", confidence=0.9, reasoning=f"필요 데이터 안내 요청({CATALOG[target]['name']})")

    template = "market_summary"
    confidence = 0.55
    for key, kws in _TEMPLATE_RULES:
        if any(k in q for k in kws):
            template = key
            confidence = 0.8
            break
    # 지역이 여러 개 명시되었고 비교 의도가 있으면 지역 비교 / 후보 선택 의도면 입지 점수
    if template == "market_summary" and rm.scope == "bjd" and rm.groups >= 2:
        template = "region_compare"
    if template == "market_summary" and rm.scope == "all" and _RANKING_CUE.search(question.replace(" ", "")):
        template = "region_compare"   # '장사 잘 되는 데가 어디야?' → 제주 전체 동네 순위
    if template == "region_compare" and rm.scope == "bjd" and rm.groups <= 1:
        template = "market_summary"   # 동네 하나만 언급된 '비교'는 작년 비교 등 시간 비교 → 상권 요약(전년 대비)
    if template == "site_score" and rm.scope == "bjd" and rm.groups <= 1 and not any(w in q for w in ("후보", "추천", "2호점", "분점", "점수", "스코어")):
        template = "market_summary"   # '애월읍 카페 입지 어때?'는 상권 요약, '입지 점수'를 콕 집어 물으면 점수표
    if template == "site_score" and not inds:
        confidence = 0.6

    compare = []
    if template in ("region_compare", "site_score"):
        compare = rm.regions if rm.scope != "all" else []
    focus = ""
    for k in ("중국인", "일본인", "동남아", "외국인", "내국인관광객", "내국인 관광객", "외국사람"):
        if k.replace(" ", "") in q:
            focus = {"중국인": "중국", "일본인": "일본", "외국사람": "외국인"}.get(k, k.replace("내국인관광객", "내국인 관광객"))
            break
    opts = {"focus": focus} if focus else {}
    reasoning = f"규칙 기반 해석 — 지역: {rm.label} / 업종: {industries.describe(inds)} / 기간: {period.label} / 분석: {CATALOG[template]['name']}"
    plan = Plan(template=template, question=question, regions=rm.regions, region_label=rm.label, region_scope=rm.scope, industries=inds,
                period=period, compare_regions=compare, top_n=textutil.extract_top_n(question), yoy=textutil.wants_yoy(question),
                options=opts, source="rule", confidence=confidence, reasoning=reasoning)
    plan.options["region_note"] = rm.note
    ignored = []
    if re.search(r"\d0대|청년|젊은|노인|어르신|시니어|중장년", q):
        ignored.append("연령")
    if re.search(r"여성|남성|여자|남자|여자손님|남자손님", q):
        ignored.append("성별")
    if ignored:
        plan.options["ignored_filters"] = f"{'·'.join(ignored)} 조건으로 거르는 기능은 아직 없어 전체 기준으로 계산했습니다(연령대·성별 구성은 표와 차트에서 볼 수 있어요)."
    plan.clarify = _clarify_if_needed(plan, rm, question)
    return plan


# 미지원 키워드가 일상어의 일부일 때(억원가량·2주차·전망대·주차장 아님)를 거르는 경계 규칙
_UNSUPPORTED_GUARD = {
    "원가": re.compile(r"(?<![억만천조\d])원가(?!량|까지|라고)"),
    "주차": re.compile(r"(?<!\d)주차(장|공간|가능|자리|할|는|가|시설|문제|없|힘들)"),
    "전망": re.compile(r"전망(?!대)(은|이|치|좋|밝|어두|어때|해|을)"),
    "금리": re.compile(r"(?<![가-힣])금리"),
}


def _unsupported_hit(word: str, q: str) -> bool:
    w = word.replace(" ", "")
    g = _UNSUPPORTED_GUARD.get(w)
    if g is not None:
        return bool(g.search(q))
    return w in q


def _mentions_whole_island(q: str) -> bool:
    if any(w in q for w in _WHOLE_WORDS) or ("제주" in q and "제주시" not in q and "제주밖" not in q):
        return True
    return bool(re.match(r"^(전체|전부|모든|다합쳐|통틀어|섬전체)", q))


def _strip_tokens(question: str, tokens: list[str]) -> str:
    out = question
    for w in tokens:
        out = out.replace(w, " ")
    return " ".join(out.split())


def _industry_clarify(plan: Plan, question: str) -> dict:
    return {"type": "industry", "message": "어떤 업종을 볼까요? 업종을 말하지 않으면 모든 업종을 합쳐서 계산해요.",
            "options": [{"label": n, "question": f"{question} {n}"} for n in _INDUSTRY_OPTIONS],
            "free_input": True, "free_label": "업종을 직접 쓰기 (예: 빵집, 횟집, 편의점)", "free_mode": "suffix", "free_prefix": question, "template": plan.template}


def _clarify_if_needed(plan: Plan, rm: geo.RegionMatch, question: str) -> dict | None:
    """동네·업종을 알 수 없으면 되묻기 정보를 만든다. (분석을 막는 것이 아니라 UI가 선택지를 보여줌)

    순서: ① '우리 동네' → ② 사전에 없는 지명(제주 밖 포함) → ③ 동네 없음(모든 분석 공통, '제주 전체'·순위 질문은 예외) → ④ 업종 없음(업종이 중요한 분석).
    """
    q = _clean(question)
    # 1) '우리 동네' 등 위치를 알 수 없는 표현
    if rm.here and rm.scope == "all":
        return {"type": "region", "message": "‘우리 동네’가 어디인지 알 수 없어요. 동네 이름을 골라 주시거나 입력해 주세요.",
                "options": [{"label": n, "question": question.replace("우리 동네", n).replace("우리동네", n).replace("여기", n)} for n in ("애월읍", "노형동", "연동", "서귀동")] +
                           [{"label": "제주도 전체로 보기", "question": "제주 전체 " + _strip_tokens(question, ["우리 동네", "우리동네", "여기"])}],
                "free_input": True, "free_mode": "prefix", "template": plan.template, "free_prefix": _strip_tokens(question, ["우리 동네", "우리동네", "여기"])}
    # 2) 사전에 없는 지명 (제주 밖 지명이면 그렇게 말해 준다)
    not_jeju = [x for x in _NOT_JEJU if x in q]
    if (rm.unknown or not_jeju) and rm.scope == "all":
        toks = list(dict.fromkeys(rm.unknown + not_jeju))
        w = " ".join(toks[:2])
        rest = _strip_tokens(question, toks)
        if not_jeju:
            msg = f"‘{w}’은(는) 제주 밖이라 이 프로그램으로는 볼 수 없어요. 제주 안의 동네를 골라 주세요."
        else:
            msg = f"‘{w}’은(는) 이 프로그램의 동네 목록(제주 법정동·읍면)에 없어요. 어느 동네를 말씀하시나요?"
        return {"type": "region", "message": msg,
                "options": [{"label": n, "question": f"{n} {rest}"} for n in ("애월읍", "노형동", "연동", "서귀동")] + [{"label": "제주도 전체로 보기", "question": f"제주 전체 {rest}"}],
                "free_input": True, "free_mode": "prefix", "template": plan.template, "free_prefix": rest}
    # 3) 동네 없이 물은 경우 → 모든 분석에서 되묻기 ('제주 전체'를 말했거나 순위·비교 질문이면 제외)
    if rm.scope == "all" and plan.template != "navigator" and not _mentions_whole_island(q) and not _RANKING_CUE.search(q):
        return {"type": "region", "message": "어느 동네를 볼까요? 동네(법정동·읍면)를 골라 주시거나 ‘제주 전체’로 볼 수 있어요.",
                "options": [{"label": n, "question": f"{n} {question}"} for n in ("애월읍", "노형동", "연동", "서귀동")] +
                           [{"label": "제주도 전체로 보기", "question": f"제주 전체 {question}"}],
                "free_input": True, "free_mode": "prefix", "template": plan.template, "free_prefix": question}
    # 4) 업종 없이 물은 경우 → 업종이 결론을 바꾸는 분석에서는 되묻기 ('전체 업종'을 말했으면 제외)
    if not plan.industries and plan.template in _INDUSTRY_TEMPLATES and not industries.is_explicit_all(question):
        return _industry_clarify(plan, question)
    return None


_PLANNER_SYSTEM = """당신은 제주빅데이터센터의 데이터 분석 에이전트 '제주 상권 나침반'의 플래너입니다.
사용자의 한국어 질문을 읽고, 아래 분석 템플릿 중 가장 알맞은 하나를 고르고 질문에서 지역·업종·기간 표현을 그대로 추출하세요.
규칙:
- 반드시 JSON 객체만 출력합니다. 설명 문장을 덧붙이지 마세요.
- region_text: 질문에 등장한 지역 표현을 원문 그대로(예: "애월읍", "제주시 서부 읍면", "노형동과 연동"). 없으면 "".
- industry_text: 업종 표현 원문(예: "카페", "한식 음식점", "숙박"). 없으면 "".
- period_text: 기간 표현 원문(예: "2026년 7월", "최근 6개월", "올해 여름"). 없으면 "".
- compare: 여러 지역을 비교·추천하는 질문이면 true.
- focus: 관광객 분석에서 관심 그룹("외국인", "중국", "일본", "내국인 관광객") 또는 "".
- top_n: 상위 N개 요청이 있으면 정수, 없으면 10.
- mode: 사용법/도움말 질문이면 "help", 창업 준비 순서를 묻는 질문이면 "howto", 월세·임대료·날씨 등 이 데이터에 없는 정보를 묻는 질문이면 "unsupported", 그 외 "".
- reasoning: 선택 이유 한 문장(한국어).
템플릿 목록(JSON): {catalog}
현재 적재된 데이터: {loaded}
지역 사전 예시: 법정동·읍면명(노형동, 애월읍 …), 권역(제주시 중부(동)/중부(서)/동부/서부, 서귀포시 중부/동부/서부), 시(제주시, 서귀포시).
출력 형식: {{"template": "...", "region_text": "...", "industry_text": "...", "period_text": "...", "compare": false, "focus": "", "top_n": 10, "mode": "", "reasoning": "..."}}"""


def llm_plan(question: str, store: DataStore, llm: LLMClient, base: Plan) -> Plan | None:
    loaded = [{"key": d.key, "name": d.name, "period": f"{d.period[0]}~{d.period[1]}" if d.period[0] else "-"} for d in store.datasets.values()]
    system = _PLANNER_SYSTEM.format(catalog=json.dumps(catalog_for_llm(), ensure_ascii=False), loaded=json.dumps(loaded, ensure_ascii=False))
    out = llm.complete(system, f"질문: {question}", purpose="plan", meta=[{"table": "(메타데이터만)", "rows": 0}], json_mode=True, max_tokens=400)
    data = extract_json(out or "")
    if not data or data.get("template") not in CATALOG:
        return None
    mode = str(data.get("mode") or "")
    if mode in ("help", "howto", "unsupported"):
        p = Plan(template="navigator", question=question, regions=base.regions, region_label=base.region_label, region_scope=base.region_scope, industries=base.industries,
                 period=base.period, options={"mode": mode, "unsupported_topic": data.get("reasoning", "요청하신 정보") if mode == "unsupported" else ""},
                 source="llm", confidence=0.9, reasoning=f"LLM 플래너 — {data.get('reasoning', '')}")
        return p
    rm = geo.resolve_regions(data.get("region_text") or question)
    if rm.scope == "all" and base.regions:
        rm = geo.resolve_regions(question)
    inds = industries.resolve_industries(data.get("industry_text") or "") or base.industries
    period = textutil.parse_period(data.get("period_text") or question, store.latest_month())
    if not period.explicit and base.period and base.period.explicit:
        period = base.period
    template = data["template"]
    compare = rm.regions if (data.get("compare") or template in ("region_compare", "site_score")) and rm.scope != "all" else []
    if template == "region_compare" and rm.scope == "bjd" and len(rm.regions) == 1:
        template = "market_summary"
    try:
        top_n = int(data.get("top_n") or base.top_n)
    except (TypeError, ValueError):
        top_n = base.top_n
    opts = dict(base.options)
    if data.get("focus"):
        opts["focus"] = str(data["focus"])
    opts["region_note"] = rm.note
    plan = Plan(template=template, question=question, regions=rm.regions, region_label=rm.label, region_scope=rm.scope, industries=inds, period=period,
                compare_regions=compare, top_n=max(1, min(50, top_n)), yoy=base.yoy, options=opts, source="llm", confidence=0.9,
                reasoning=f"LLM 플래너 — {data.get('reasoning', '')} (지역: {rm.label} / 업종: {industries.describe(inds)} / 기간: {period.label})")
    plan.clarify = _clarify_if_needed(plan, rm, question)
    return plan


def make_plan(question: str, store: DataStore, llm: LLMClient | None = None) -> Plan:
    base = rule_based_plan(question, store)
    if llm is not None and llm.available:
        p = llm_plan(question, store, llm, base)
        if p is not None:
            return p
    return base


def plan_from_override(base: Plan, override: dict, store: DataStore) -> Plan:
    """UI에서 사용자가 해석(지역/업종/기간/템플릿)을 고쳐 다시 실행할 때."""
    p = Plan(**{**base.__dict__})
    p.options = {k: v for k, v in base.options.items() if k not in ("region_warning", "region_note")}
    p.clarify = None
    if override.get("template") in CATALOG:
        p.template = override["template"]
    if override.get("region_text") is not None:
        txt = str(override["region_text"]).strip()
        rm = geo.resolve_regions(txt) if txt else geo.RegionMatch([], "제주도 전체", "all", [])
        p.regions, p.region_label, p.region_scope = rm.regions, rm.label, rm.scope
        p.options["region_note"] = rm.note
        if txt and rm.scope == "all":
            p.options["region_warning"] = f"‘{txt}’을(를) 동네 목록에서 찾지 못해 제주도 전체로 분석했습니다."
        if p.template in ("region_compare", "site_score"):
            p.compare_regions = rm.regions if rm.scope != "all" else []
    if override.get("industry_text") is not None:
        txt = str(override["industry_text"]).strip()
        p.industries = industries.resolve_industries(txt) if txt else []
        if txt and not p.industries and not industries.is_explicit_all(txt):
            p.options["industry_warning"] = f"‘{txt}’에 맞는 업종을 찾지 못해 모든 업종으로 계산했습니다. (예: 카페, 한식, 치킨, 숙박, 편의점)"
    if override.get("period_text"):
        earliest = min([d.period[0] for d in store.datasets.values() if d.period[0]] or [None]) if store.datasets else None
        p.period = textutil.parse_period(str(override["period_text"]), store.latest_month(), earliest)
    if override.get("top_n") is not None:
        try:
            p.top_n = max(1, min(50, int(override["top_n"])))
        except (TypeError, ValueError):
            pass
    p.source = "user"
    p.reasoning = f"사용자 수정 — 지역: {p.region_label} / 업종: {p.industry_label} / 기간: {p.period.label if p.period else '-'}"
    return p

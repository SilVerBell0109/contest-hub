"""데이터셋 레지스트리 로딩과 컬럼 자동 매핑.

CSV 헤더가 명세서 버전·언어에 따라 달라도 `datasets.yaml`의 aliases로 표준 컬럼명(canonical)에 대응시킵니다.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import yaml

_HERE = Path(__file__).parent
DEFAULT_REGISTRY_PATH = _HERE / "datasets.yaml"


def normalize_header(h: str) -> str:
    """헤더 비교용 정규화: 소문자, 공백/밑줄/하이픈/괄호 제거, BOM 제거."""
    if h is None:
        return ""
    s = str(h).replace("﻿", "").strip().lower()
    s = re.sub(r"\((원|명|건|개|회|%|천원|백만원|억원|월|일)\)", "", s)     # 단위 괄호 '이용금액(원)' → '이용금액'
    s = re.sub(r"[\s_\-\.]+", "", s)
    s = re.sub(r"[()\[\]{}]", "", s)
    return s


@dataclass
class ColumnSpec:
    canonical: str
    role: str
    aliases: list[str]
    kind: str = ""        # count | amount | '' (measure 전용)
    label: str = ""

    @property
    def norm_aliases(self) -> set[str]:
        return {normalize_header(a) for a in self.aliases} | {normalize_header(self.canonical)}


@dataclass
class DatasetSpec:
    key: str
    name: str
    source: str                     # center | hub
    category: str
    export: str                     # restricted | allowed
    period_unit: str
    description: str
    download_guide: str
    columns: list[str]              # canonical names
    required: list[str]
    required_any: list[str] = field(default_factory=list)
    exclude_if_present: list[str] = field(default_factory=list)
    signature_any: list[str] = field(default_factory=list)
    sdc_min_cell: int = 10
    sdc_count_columns: list[str] = field(default_factory=list)
    priority: int = 0
    url: str = ""
    api: dict = field(default_factory=dict)
    also_known_as: list[str] = field(default_factory=list)

    @property
    def is_restricted(self) -> bool:
        return self.export == "restricted"


@dataclass
class DetectResult:
    spec: DatasetSpec | None
    mapping: dict[str, str]          # 원본 헤더 → canonical
    unmapped: list[str]              # 매핑되지 않은 원본 헤더
    score: float
    reason: str


class Registry:
    def __init__(self, path: Path | str = DEFAULT_REGISTRY_PATH):
        self.path = Path(path)
        raw = yaml.safe_load(self.path.read_text(encoding="utf-8"))
        self.labels: dict[str, str] = raw.get("canonical_labels", {})
        self.value_maps: dict[str, dict[str, str]] = {k: {str(a): str(b) for a, b in (v or {}).items()} for k, v in (raw.get("value_maps") or {}).items()}
        self.library: dict[str, ColumnSpec] = {}
        for canon, spec in raw["column_library"].items():
            self.library[canon] = ColumnSpec(canon, spec["role"], list(spec.get("aliases", [])), spec.get("kind", ""), self.labels.get(canon, canon))
        self.datasets: dict[str, DatasetSpec] = {}
        for key, d in raw["datasets"].items():
            sdc = d.get("sdc", {}) or {}
            self.datasets[key] = DatasetSpec(
                key=key, name=d["name"], source=d["source"], category=d.get("category", ""), export=d.get("export", "restricted"),
                period_unit=d.get("period_unit", "month"), description=d.get("description", ""), download_guide=d.get("download_guide", ""),
                columns=list(d.get("columns", [])), required=list(d.get("required", [])), required_any=list(d.get("required_any", [])),
                exclude_if_present=list(d.get("exclude_if_present", [])), signature_any=list(d.get("signature_any", [])),
                sdc_min_cell=int(sdc.get("min_cell", 10)), sdc_count_columns=list(sdc.get("count_columns", [])),
                priority=int(d.get("priority", 0)), url=d.get("url", ""), api=d.get("api", {}) or {}, also_known_as=list(d.get("also_known_as", [])),
            )

    # ── 컬럼 매핑 ──────────────────────────────────────────────────────────
    def map_headers(self, headers: Iterable[str]) -> tuple[dict[str, str], list[str]]:
        """원본 헤더 목록을 canonical 이름으로 매핑. (mapping, unmapped)"""
        mapping: dict[str, str] = {}
        unmapped: list[str] = []
        taken: set[str] = set()
        norm_index: dict[str, str] = {}
        for canon, cs in self.library.items():
            for a in cs.norm_aliases:
                norm_index.setdefault(a, canon)
        for h in headers:
            n = normalize_header(h)
            canon = norm_index.get(n)
            if canon and canon not in taken:
                mapping[h] = canon
                taken.add(canon)
            else:
                unmapped.append(h)
        return mapping, unmapped

    def detect(self, headers: Iterable[str], filename: str = "") -> DetectResult:
        """헤더(와 파일명 힌트)로 데이터셋 종류를 판정."""
        headers = list(headers)
        mapping, unmapped = self.map_headers(headers)
        present = set(mapping.values())
        norm_headers = {normalize_header(h) for h in headers}
        fname = (filename or "").lower()
        best: tuple[float, DatasetSpec | None, str] = (-1.0, None, "")
        # 센터 데이터의 흔적(권역·관광구분·업종코드·연령·시간대 등)이 있거나 알아보지 못한 열이 남아 있으면,
        # '공개(허브)' 데이터셋으로는 판정하지 않는다 — 센터 파일이 공개 데이터로 분류되어 임계값이 빠지는 일을 막는다.
        center_marks = {"dstrct_se", "trip_se", "ksic_cd", "age_se", "time_se", "dow_se", "resd_pop", "work_pop", "visit_pop", "store_cnt"}
        looks_center = bool(present & center_marks) or any(w in fname for w in ("_v0", "센터", "center", "카드이용현황", "유동인구", "매장")) or bool(unmapped)
        for spec in self.datasets.values():
            if any(c in present for c in spec.exclude_if_present):
                continue
            if spec.export == "allowed" and looks_center and not spec.signature_any:
                continue
            if not all(c in present for c in spec.required):
                continue
            if spec.required_any and not any(c in present for c in spec.required_any):
                continue
            if spec.signature_any:
                sig_hit = any(normalize_header(s) in norm_headers for s in spec.signature_any) or any(s in present for s in spec.signature_any)
                if not sig_hit:
                    continue
            matched = len([c for c in spec.columns if c in present])
            score = matched + spec.priority / 100.0
            # 파일명 힌트 가점
            hint_words = [spec.name] + spec.also_known_as + [spec.key]
            if any(normalize_header(w)[:8] and normalize_header(w)[:8] in normalize_header(fname) for w in hint_words):
                score += 2
            if score > best[0]:
                best = (score, spec, f"매칭 컬럼 {matched}개")
        if best[1] is None:
            return DetectResult(None, mapping, unmapped, 0.0, "레지스트리의 어떤 데이터셋과도 필수 컬럼이 맞지 않음")
        return DetectResult(best[1], mapping, unmapped, best[0], best[2])

    def nearest(self, headers: Iterable[str]) -> tuple[DatasetSpec | None, list[str]]:
        """필수 열 조건을 무시하고 가장 비슷한 데이터셋과, 그 데이터셋에서 빠진 필수 열(표준명) 목록."""
        mapping, _ = self.map_headers(list(headers))
        present = set(mapping.values())
        best, best_n, missing = None, 0, []
        for spec in self.datasets.values():
            n = len([c for c in spec.columns if c in present])
            if n > best_n:
                best, best_n = spec, n
                missing = [c for c in spec.required if c not in present]
        return best, missing

    def label(self, canonical: str) -> str:
        return self.labels.get(canonical, canonical)

    def count_columns(self, spec: DatasetSpec) -> list[str]:
        return list(spec.sdc_count_columns)

    def describe_for_llm(self) -> list[dict]:
        """LLM 플래너에 넘길 메타데이터(데이터 값 없음)."""
        out = []
        for s in self.datasets.values():
            out.append({"key": s.key, "name": s.name, "source": s.source, "export": s.export, "columns": s.columns, "description": s.description})
        return out


_registry: Registry | None = None


def get_registry() -> Registry:
    global _registry
    if _registry is None:
        _registry = Registry()
    return _registry

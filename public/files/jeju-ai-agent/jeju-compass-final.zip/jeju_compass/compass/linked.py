"""보고서 단위 연결표(linked tables) 역산 검사.

한 보고서에는 같은 원천 행(필터된 데이터)에서 서로 다른 차원으로 집계한 표가 여러 개 들어간다
(월별·이용자 그룹별·국적별·연령×성별·업종별 … + 핵심 숫자(KPI) 합계). 표 하나 안에서는 `sdc.protect()`가
행·열·전체 합계 공개를 가정한 역산 방지를 하지만, **다른 표의 공개 셀을 조합**하면 가린 셀이 복원될 수 있다
(예: 법인 = KPI 합계 − 도민 − 관광객 − Σ국적별). 이 모듈은 보고서의 모든 표를 '원자 셀'(모든 차원의 교차 조합)
위의 선형 결합으로 보고, 공개된 모든 행(+KPI)의 행공간에 1차 비공개 셀이 속하는지(rank 검사)를 확인한 뒤,
속하면 공개 행을 추가로 가려(종류 'L') 복원이 불가능해질 때까지 반복한다.

검사 범위: 같은 원천 데이터셋에서 만든 표들 + KPI 합계. 서로 다른 데이터셋(예: 카드 vs 유동인구)은 셀이 다르므로 별개.
한계: 정확 역산(등식)만 검사하며 구간 추정(부등식)은 검사하지 않는다(문서에 명시).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
import pandas as pd

from .sdc import SDCAction

log = logging.getLogger(__name__)

MAX_EXTRA = 24           # 보고서당 추가 비공개 상한(이 안에 못 막으면 해당 표 전체 비공개)
MAX_ATOMS = 2_000_000    # 원자 셀 상한(초과 시 검사 생략 + 경고)


@dataclass
class LinkedRow:
    table: object          # templates.base.Table
    row_idx: int           # t.sdc.table 의 행 위치
    public: bool
    primary: bool
    count: float


def _apply_transforms(key: pd.DataFrame, applied: list, src: pd.DataFrame) -> tuple[pd.DataFrame, list[pd.Series]]:
    """표를 만들 때 적용된 범주 변환(롤업·병합)을 원천 행의 차원 열에 똑같이 적용한다.

    반환: (변환된 차원 프레임, 병합으로 사라진 '작은 셀'들의 원천 행 마스크 목록 — 연결표 검사의 보호 대상)
    """
    key = key.copy()
    small_masks: list[pd.Series] = []
    for rec in applied:
        col, mapping, new_col = rec[0], rec[1], rec[2]
        small_cells = rec[3] if len(rec) > 3 else None
        if small_cells:
            for cell in small_cells:
                m = pd.Series(True, index=key.index)
                for d, v in cell.items():
                    if d in key.columns:
                        m &= key[d].astype(str) == str(v)
                if m.any():
                    small_masks.append(m)
        if new_col:
            if col in key.columns:
                key = key.drop(columns=[col])
            if new_col not in key.columns and new_col in src.columns:
                key[new_col] = src[new_col].values
        elif callable(mapping):
            if col in key.columns:
                key[col] = key[col].map(mapping)
        elif isinstance(mapping, dict):
            if col in key.columns:
                key[col] = key[col].astype(str).map(lambda v: mapping.get(v, v))
    return key, small_masks


def _rank(a: np.ndarray) -> int:
    if a.size == 0:
        return 0
    return int(np.linalg.matrix_rank(a))


def _determined(A: np.ndarray, v: np.ndarray) -> bool:
    if A.shape[0] == 0:
        return False
    return _rank(np.vstack([A, v])) == _rank(A)


def guard_report(tables: list, kpi_public: bool) -> tuple[list[dict], str]:
    """보고서의 표들에 연결표 역산 검사를 적용하고 필요하면 추가 비공개한다.

    반환: (추가 비공개된 행 목록 [{'table','dims':{…}}], 요약 문구)
    """
    cand = [t for t in tables if t.sdc is not None and t.source is not None and t.sdc.min_cell > 0 and t.sdc.verified and t.orig_dims]
    if not cand:
        return [], ""
    extra: list[dict] = []
    notes: list[str] = []
    for key in sorted({t.source_key for t in cand}):
        group = [t for t in cand if t.source_key == key]
        try:
            added, note = _guard_group(group, kpi_public)
        except Exception as e:  # noqa: BLE001
            log.warning("연결표 검사 실패(%s): %s", key, e)
            added, note = [], f"연결표 검사를 수행하지 못했습니다({type(e).__name__})"
        extra += added
        if note:
            notes.append(note)
    return extra, "; ".join(notes)


def _guard_group(group: list, kpi_public: bool) -> tuple[list[dict], str]:
    # 1) 원천 행의 합집합(같은 데이터셋이므로 인덱스가 공통)
    srcs = [t.source for t in group]
    universe = pd.concat(srcs)
    universe = universe[~universe.index.duplicated(keep="first")]
    atomic_dims = sorted({d for t in group for d in t.orig_dims if d in universe.columns})
    if not atomic_dims:
        return [], ""
    atom = universe.groupby(atomic_dims, dropna=False, observed=True, sort=False).ngroup()
    if int(atom.max()) + 1 > MAX_ATOMS:
        return [], "원자 셀이 너무 많아 연결표 검사를 생략했습니다"

    # 2) 표별로 원자 셀 → 행 번호(공개/비공개 행 모두), -1 = 표에 없는 셀(상위 N 절단 등)
    rows: list[LinkedRow] = []
    pattern_cols = {}
    merged_targets: list[tuple[int, pd.Series]] = []     # (table index, 원천 행 마스크) — 병합으로 사라진 작은 셀
    for ti, t in enumerate(group):
        src = t.source
        key = src[[d for d in t.orig_dims if d in src.columns]]
        key, small_masks = _apply_transforms(key, t.sdc.applied, src)
        for m in small_masks:
            merged_targets.append((ti, m))
        dims = [d for d in t.sdc.dims if d in key.columns]
        if not dims:
            continue
        tbl = t.sdc.table
        tbl_keys = tbl[dims].astype(str).agg("\u0001".join, axis=1)
        row_of = {k: i for i, k in enumerate(tbl_keys.tolist())}
        kk = key[dims].astype(str).agg("\u0001".join, axis=1)
        rid = kk.map(row_of).fillna(-1).astype(int)
        pattern_cols[ti] = pd.Series(rid.values, index=src.index).reindex(universe.index).fillna(-1).astype(int)
        for i in range(len(tbl)):
            sup = bool(tbl["_suppressed"].iloc[i]) if "_suppressed" in tbl.columns else False
            kind = str(tbl["_kind"].iloc[i]) if "_kind" in tbl.columns else ""
            rows.append(LinkedRow(t, i, not sup, sup and kind == "P", 0.0))
    if not pattern_cols:
        return [], ""
    pat = pd.DataFrame({f"t{ti}": s for ti, s in pattern_cols.items()}, index=universe.index)
    pid = pat.groupby(list(pat.columns), sort=False).ngroup()
    n_pat = int(pid.max()) + 1
    # 패턴별 각 표의 행 번호
    pat_rows = pat.assign(_p=pid.values).drop_duplicates("_p").set_index("_p").sort_index()

    # 3) 공개 행 벡터(A)와 1차 비공개 목표 벡터
    def vec(ti: int, ridx: int) -> np.ndarray:
        v = np.zeros(n_pat)
        v[(pat_rows[f"t{ti}"] == ridx).values] = 1.0
        return v

    ti_of = {id(t): ti for ti, t in enumerate(group)}
    # 행별 건수(공개 행 후보 정렬용): sdc.table 의 건수 열 값
    def row_count(r: LinkedRow) -> float:
        tbl = r.table.sdc.table
        for c in ("user_cnt", "use_cnt", "visit_pop", "store_cnt", "flow_pop", *r.table.measures):
            if c in tbl.columns:
                v = pd.to_numeric(tbl[c].iloc[r.row_idx], errors="coerce")
                if pd.notna(v):
                    return float(v)
        return 0.0

    public = [r for r in rows if r.public and id(r.table) in ti_of]
    targets = [r for r in rows if r.primary and id(r.table) in ti_of]
    tvecs = [vec(ti_of[id(r.table)], r.row_idx) for r in targets]
    # 병합으로 사라진 작은 셀: 그 원자 셀들이 '통째로' 들어 있는 패턴들의 합이 목표 벡터
    pid_by_idx = pd.Series(pid.values, index=universe.index)
    pat_size = pid_by_idx.value_counts()
    for ti, m in merged_targets:
        idx = m[m].index
        sub = pid_by_idx.reindex(idx).dropna().astype(int)
        if sub.empty:
            continue
        inside = sub.value_counts()
        full = [p for p, c in inside.items() if c == pat_size.get(p, 0)]
        if not full or len(full) != len(inside):
            continue      # 일부 패턴에 다른 셀이 섞여 있으면 공격자도 분리할 수 없음
        v = np.zeros(n_pat)
        v[full] = 1.0
        tvecs.append(v)
        targets.append(LinkedRow(group[ti], -1, False, True, 0.0))
    if not targets:
        return [], ""
    A_rows = [vec(ti_of[id(r.table)], r.row_idx) for r in public]
    if kpi_public:
        A_rows.append(np.ones(n_pat))
    A_full = np.array(A_rows) if A_rows else np.zeros((0, n_pat))
    active = np.ones(A_full.shape[0], dtype=bool)        # 공개 행 활성 플래그(A_full과 인덱스가 항상 일치)
    n_public = len(public)

    extra: list[dict] = []
    for _ in range(MAX_EXTRA):
        A = A_full[active]
        det = [k for k, v in enumerate(tvecs) if _determined(A, v)]
        if not det:
            break
        v = tvecs[det[0]]
        # 후보: 활성 공개 행(KPI 제외)을 건수 오름차순으로 — 제거했을 때 목표가 결정되지 않게 되는 첫 행을 가린다
        order = sorted([i for i in range(n_public) if active[i]], key=lambda i: row_count(public[i]))
        pick = None
        for i in order:
            trial = active.copy()
            trial[i] = False
            if not _determined(A_full[trial], v):
                pick = i
                break
        if pick is None:
            pick = order[0] if order else None
        if pick is None:
            break
        r = public[pick]
        _suppress_row(r)
        extra.append({"table": r.table.name, "dims": {d: str(r.table.sdc.table[d].iloc[r.row_idx]) for d in r.table.sdc.dims}})
        active[pick] = False
    A = A_full[active]
    # 상한 안에 못 막았으면 목표 표 전체를 가린다(최후 수단)
    det = [k for k, v in enumerate(tvecs) if _determined(A, v)]
    for k in det:
        t = targets[k].table
        tbl = t.sdc.table
        for i in range(len(tbl)):
            if not bool(tbl["_suppressed"].iloc[i]):
                _suppress_row(LinkedRow(t, i, True, False, 0.0))
                extra.append({"table": t.name, "dims": {d: str(tbl[d].iloc[i]) for d in t.sdc.dims}})
    note = f"보고서 안 다른 표와 조합한 역산을 막기 위해 {len(extra)}칸을 추가로 가렸습니다" if extra else ""
    return extra, note


def _suppress_row(r: LinkedRow) -> None:
    t = r.table
    tbl = t.sdc.table
    tbl.loc[tbl.index[r.row_idx], "_suppressed"] = True
    if "_kind" in tbl.columns:
        tbl.loc[tbl.index[r.row_idx], "_kind"] = "L"
    for c in tbl.columns:
        if c in t.sdc.dims or c in ("_suppressed", "_kind"):
            continue
        if pd.api.types.is_numeric_dtype(tbl[c]):
            tbl[c] = tbl[c].astype(float)
            tbl.loc[tbl.index[r.row_idx], c] = np.nan
    t.sdc.n_linked += 1
    act = next((a for a in t.sdc.actions if a.kind == "linked"), None)
    if act is None:
        act = SDCAction("linked", "보고서 안 다른 표와의 역산 방지를 위해 추가 비공개", 0)
        t.sdc.actions.append(act)
    act.count = t.sdc.n_linked
    act.detail = f"보고서 안 다른 표와의 역산 방지를 위해 추가 비공개 {t.sdc.n_linked}셀"

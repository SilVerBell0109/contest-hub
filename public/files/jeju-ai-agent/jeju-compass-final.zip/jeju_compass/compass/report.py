"""보고서 생성: HTML(항상) → PDF(로컬 Chrome/Edge 헤드리스, 실패 시 reportlab) · 차트 PNG 동봉.

보고서에는 반출 검수를 통과한 표·차트·요약만 실리며, '반출 검수 결과' 절이 자동으로 붙습니다.
"""
from __future__ import annotations

import base64
import logging
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

from jinja2 import Template

from . import APP_NAME, __version__

log = logging.getLogger(__name__)

_TEMPLATE = Template(r"""<!DOCTYPE html>
<html lang="ko"><head><meta charset="utf-8">
<title>{{ r.title }}</title>
<style>
  /* 디자인: 무채색은 바다색 쪽으로 살짝 물들이고 강조색은 하나만, 측면 색 띠 없음, 글자 크기 단계 1.25배 이상 */
  @page { size: A4; margin: 16mm 15mm 18mm 15mm; @bottom-right { content: counter(page) " / " counter(pages); font-size: 7.5pt; color: #7f888c; font-family: "Malgun Gothic","Noto Sans CJK KR",sans-serif; } @bottom-left { content: "{{ app }} 자동 보고서 · {{ r.generated_at }}"; font-size: 7.5pt; color: #7f888c; font-family: "Malgun Gothic","Noto Sans CJK KR",sans-serif; } }
  :root { --ink:#1b2327; --ink2:#4d575b; --ink3:#7f888c; --line:#cad3d5; --line-soft:#e1e7e9; --surface:#f1f7f8; --accent:#006a7f; --accent-ink:#004e65; --accent-bg:#e2f4f8;
          --warn:#a56217; --warn-bg:#fff3df; --good:#24744d; --good-bg:#e5f8ec; --alert:#ba362e; }
  * { box-sizing: border-box; }
  body { font-family: "Malgun Gothic","맑은 고딕","Apple SD Gothic Neo","Noto Sans CJK KR","Noto Sans KR","NanumGothic",sans-serif; color: var(--ink);
         margin: 0; font-size: 10pt; line-height: 1.6; word-break: keep-all; overflow-wrap: break-word; font-variant-numeric: tabular-nums; }
  .page { max-width: 186mm; margin: 0 auto; padding: 10mm 0; }
  .eyebrow { font-size: 8.5pt; color: var(--ink2); letter-spacing: 0.02em; }
  h1 { font-size: 24pt; font-weight: 700; line-height: 1.2; margin: 6px 0 4px; letter-spacing: -0.02em; }
  h2 { font-size: 15.6pt; font-weight: 700; line-height: 1.3; margin: 26px 0 10px; padding-bottom: 6px; border-bottom: 1px solid var(--line);
       display: flex; align-items: baseline; gap: 9px; break-after: avoid; }
  h2 .no { color: var(--accent); }
  h3 { font-size: 12.5pt; font-weight: 700; margin: 14px 0 6px; break-after: avoid; }
  .sub { color: var(--ink2); font-size: 9.6pt; }
  .meta { display: flex; flex-wrap: wrap; gap: 4px 14px; font-size: 8.8pt; color: var(--ink2); margin: 10px 0 0; align-items: center; }
  .badge { display: inline-block; padding: 1px 8px; border-radius: 4px; font-size: 8.2pt; background: var(--surface); color: var(--ink2); }
  .badge.sample, .badge.warn { background: var(--warn-bg); color: var(--warn); }
  .badge.center { background: var(--accent-bg); color: var(--accent-ink); }
  .badge.hub, .badge.pass { background: var(--good-bg); color: var(--good); }
  .samplebar { background: var(--warn-bg); color: var(--warn); border-radius: 6px; padding: 9px 13px; font-weight: 700; margin: 12px 0 0; }
  .fill { display: flex; gap: 26px; margin: 14px 0 0; font-size: 9pt; color: var(--ink2); }
  .fill span { border-bottom: 1px solid var(--ink3); min-width: 150px; display: inline-block; }
  .wm { position: fixed; top: 42%; left: 8%; width: 84%; text-align: center; font-size: 44pt; color: rgba(165,98,23,0.09); transform: rotate(-22deg); font-weight: 800; pointer-events: none; z-index: 0; }
  /* 핵심 숫자: 상자 대신 세로 구분선 */
  .kpis { display: grid; grid-template-columns: repeat(4, 1fr); border-top: 1px solid var(--line); border-bottom: 1px solid var(--line); margin: 10px 0 12px; }
  .kpi { padding: 10px 12px 11px 0; break-inside: avoid; }
  .kpi + .kpi { padding-left: 12px; border-left: 1px solid var(--line-soft); }
  .kpi .l { font-size: 8.4pt; color: var(--ink2); }
  .kpi .v { font-size: 16pt; font-weight: 700; margin-top: 2px; letter-spacing: -0.01em; }
  .kpi .d { font-size: 8pt; color: var(--ink2); line-height: 1.45; margin-top: 2px; }
  .kpi .d.up { color: var(--good); } .kpi .d.down { color: var(--alert); }
  .findings { margin: 8px 0 0; padding-left: 18px; }
  .findings li { margin: 4px 0; }
  .findings li::marker { color: var(--ink3); }
  .findings li.key { font-weight: 700; }
  .findings li.warn { color: var(--warn); }
  .narr { background: var(--surface); padding: 11px 14px; border-radius: 6px; white-space: pre-wrap; }
  .charts { display: grid; grid-template-columns: 1fr; gap: 12px; }
  .chart { border: 1px solid var(--line-soft); border-radius: 6px; padding: 6px; break-inside: avoid; }
  .chart img { width: 100%; max-height: 105mm; object-fit: contain; display: block; }
  table { border-collapse: collapse; width: 100%; font-size: 8.9pt; margin: 6px 0 4px; line-height: 1.45; }
  th, td { padding: 4px 7px; text-align: right; }
  th { color: var(--ink2); font-weight: 600; font-size: 8.5pt; border-bottom: 1px solid var(--ink3); }
  td { border-bottom: 1px solid var(--line-soft); }
  th:first-child, td:first-child { text-align: left; }
  thead { display: table-header-group; }
  tr { break-inside: avoid; }
  .tbl { break-inside: avoid; margin-bottom: 14px; }
  .tbl .cap { display: flex; justify-content: space-between; align-items: baseline; gap: 10px; flex-wrap: wrap; }
  .tbl .cap h3 { margin-bottom: 2px; }
  .note { font-size: 8.4pt; color: var(--ink2); }
  .caveats li { color: var(--ink2); font-size: 9.2pt; margin: 3px 0; }
  .sdc { padding: 11px 14px; background: var(--surface); border-radius: 6px; break-inside: avoid; }
  .sdc ul { margin: 6px 0; padding-left: 18px; font-size: 8.9pt; color: var(--ink2); }
  .footer { margin-top: 26px; padding-top: 8px; border-top: 1px solid var(--line); font-size: 8.3pt; color: var(--ink3); }
  .mono { font-family: Consolas, "D2Coding", monospace; font-size: 8.4pt; overflow-wrap: anywhere; }
  .appendix h2 { color: var(--ink2); font-size: 12.5pt; }
  .keep { break-inside: avoid; }
  @media print { .page { max-width: none; padding: 0; } a { color: inherit; text-decoration: none; } }
</style></head>
<body>{% if r.sample %}<div class="wm">연습용 가짜 숫자 — 실제 자료 아님</div>{% endif %}<div class="page">
  <div class="eyebrow">{{ app }} v{{ version }} · 데이터 분석 자동 보고서</div>
  <h1>{{ r.title }}</h1>
  <div class="sub">{{ r.subtitle }}</div>
  <div class="meta">
    <span>생성: {{ r.generated_at }}</span>
    <span>질문: “{{ r.question }}”</span>
    {% for d in r.data_used %}<span class="badge {{ d.origin }}">{{ '연습용 가짜 데이터' if d.origin=='sample' else ('센터 데이터' if d.origin=='center' else '허브 공개 데이터') }}: {{ d.name }}</span>{% endfor %}
  </div>
  {% if r.sample %}<div class="samplebar">※ 이 보고서는 연습용 가짜(합성) 데이터로 만든 예시입니다. 실제 수치가 아니므로 사업계획서·보고서에 쓰지 마세요.</div>{% endif %}
  <div class="fill"><div>신청인(작성자): <span></span></div><div>용도: <span></span></div><div>작성일: {{ r.generated_at[:10] }}</div></div>
  {% if r.plan.region_note %}<p class="note">※ {{ r.plan.region_note }}</p>{% endif %}

  {% set ns = namespace(n=1) %}
  <h2><span class="no">{{ ns.n }}</span>핵심 요약</h2>
  {% if r.kpis %}<div class="kpis">{% for k in r.kpis %}<div class="kpi"><div class="l">{{ k.label }}</div><div class="v">{{ k.value }}</div>{% if k.get('delta') is not none %}<div class="d {{ 'up' if k.delta >= 0 else 'down' }}">{{ k.get('delta_label') or '전년 동기 대비' }} {{ '%+.1f'|format(k.delta) }}%</div>{% endif %}{% if k.get('note') %}<div class="d">{{ k.note }}</div>{% endif %}</div>{% endfor %}</div>{% endif %}
  <ul class="findings">{% for f in r.findings %}<li class="{{ f.level }}">{{ f.text }}</li>{% endfor %}</ul>
  {% if r.narrative %}<h3>AI 해설 <span class="badge">가린 칸 없는 집계값만 사용</span></h3><div class="narr">{{ r.narrative }}</div>{% endif %}

  {% if r.charts %}{% set ns.n = ns.n + 1 %}<h2><span class="no">{{ ns.n }}</span>차트</h2><div class="charts">{% for c in r.charts %}<div class="chart"><img src="data:image/png;base64,{{ c.b64 }}" alt="{{ c.title }}"></div>{% endfor %}</div>{% endif %}

  {% if r.tables %}{% set ns.n = ns.n + 1 %}<h2><span class="no">{{ ns.n }}</span>집계표</h2>
  {% for t in r.tables %}<div class="tbl"><div class="cap"><h3>{{ t.name }}</h3><span class="badge {{ 'pass' if t.sdc.passed else 'warn' }}">{{ t.sdc.plain }}</span></div>
    {{ t.html|safe }}{% if t.note %}<div class="note">{{ t.note }}</div>{% endif %}</div>{% endfor %}{% endif %}

  {% if r.guidance and r.guidance.get('kind') == 'data' %}<h2>필요한 데이터와 받는 방법</h2>
  <table><thead><tr><th style="text-align:left">데이터셋</th><th style="text-align:left">출처</th><th style="text-align:left">상태</th><th style="text-align:left">받는 방법</th></tr></thead>
  {% for it in r.guidance['items'] %}<tr><td>{{ it.name }}<br><span class="note">{{ it.role }}</span></td><td style="text-align:left">{{ '제주빅데이터센터(센터 PC)' if it.source=='center' else '제주데이터허브(공개)' }}</td><td style="text-align:left">{{ '들어 있음' if it.loaded else '없음' }}</td><td style="text-align:left">{{ it.download_guide }}</td></tr>{% endfor %}</table>
  <h3>권장 조회 조건</h3><p>기간: {{ r.guidance['conditions']['period'] }} ({{ r.guidance['conditions']['months']|length }}개 파일) · 지역: {{ r.guidance['conditions']['region_label'] }}</p>
  <p class="note">{{ r.guidance['conditions']['note'] }}</p>
  <h3>진행 순서</h3><ol>{% for s in r.guidance['steps'] %}<li>{{ s }}</li>{% endfor %}</ol>{% endif %}
  {% if r.guidance and r.guidance.get('kind') == 'help' %}<h2>이 프로그램으로 할 수 있는 것</h2><ul>{% for s in r.guidance['help']['can'] %}<li>{{ s }}</li>{% endfor %}</ul>
  <h3>할 수 없는 것</h3><ul>{% for s in r.guidance['help']['cannot'] %}<li>{{ s }}</li>{% endfor %}</ul><h3>쓰는 법</h3><ol>{% for s in r.guidance['help']['how'] %}<li>{{ s }}</li>{% endfor %}</ol>{% endif %}

  {% if r.method or r.caveats %}{% set ns.n = ns.n + 1 %}<h2><span class="no">{{ ns.n }}</span>분석 방법과 유의사항</h2>
  <p>{{ r.method }}</p>
  <ul class="caveats">{% for c in r.caveats %}<li>{{ c }}</li>{% endfor %}</ul>{% endif %}

  {% if r.tables %}{% set ns.n = ns.n + 1 %}<div class="keep"><h2><span class="no">{{ ns.n }}</span>개인정보 보호 확인 (반출 기준 검수 결과)</h2>
  <p class="note">이 보고서의 숫자가 특정 개인이나 가게를 알아볼 수 없게 처리되었는지 제주빅데이터센터 기준으로 자동 확인한 결과입니다. 센터의 반출 심사용 자료이며, 은행·거래처에 제출할 때는 이 절을 빼도 됩니다.</p>
  <div class="sdc">
    <div><span class="badge {{ 'pass' if r.sdc_overall.passed else 'warn' }}">{{ r.sdc_overall.plain }}</span>
      <span class="note"> · 기준: 표의 모든 칸이 인원·건수 {{ r.sdc_overall.min_cell }} 이상(제주빅데이터센터 반출 기준 2026.9.1) · 처리: 범주 합치기 → 가리기 → 역산 방지(가린 숫자를 다른 숫자로 거꾸로 계산해 낼 수 없도록 추가로 가리기)</span></div>
    <ul>{% for t in r.sdc_overall.tables %}<li><b>{{ t.name }}</b>: {{ t.summary }}</li>{% endfor %}</ul>
    <p class="note">반출 신청 시 이 절을 함께 제출하면 심사자가 처리 내역을 확인할 수 있습니다. 가린 칸의 수치는 보고서·차트·CSV·AI 해설 어디에도 포함되지 않았습니다. 역산 방지는 이 보고서 안의 표를 대상으로 한 검사이며, 여러 보고서를 조합한 추정은 센터 반출 심사에서 최종 확인합니다.</p>
  </div></div>{% endif %}

  {% if r.data_used %}<div class="keep">{% set ns.n = ns.n + 1 %}<h2><span class="no">{{ ns.n }}</span>데이터 출처와 조건</h2>
  <table><thead><tr><th style="text-align:left">데이터</th><th style="text-align:left">구분</th><th>자료 행 수</th><th style="text-align:left">보유 기간</th><th style="text-align:left">적용 조건</th></tr></thead>
  {% for d in r.data_used %}<tr><td>{{ d.name }}</td><td style="text-align:left">{{ '연습용 가짜' if d.origin=='sample' else ('센터(원본 반출 불가)' if d.export=='restricted' else '허브 공개') }}</td><td>{{ '{:,}'.format(d.rows) }}</td><td style="text-align:left">{{ d.period_text or d.period }}</td><td style="text-align:left">{{ d.filter }}</td></tr>{% endfor %}</table></div>{% endif %}

  <div class="appendix">
  <div class="keep"><h2>부록 A. 질문 해석 기록</h2>
  <table><thead><tr><th style="text-align:left">항목</th><th style="text-align:left">해석</th></tr></thead>
    <tr><td>분석 유형</td><td style="text-align:left">{{ r.plan.template_name }}</td></tr>
    <tr><td>지역</td><td style="text-align:left">{{ r.plan.region_label }}{% if r.plan.regions and r.plan.regions|length <= 8 and r.plan.regions|length > 1 %} ({{ r.plan.regions|join(', ') }}){% elif r.plan.regions and r.plan.regions|length > 8 %} ({{ r.plan.regions|length }}개 법정동·읍면){% endif %}</td></tr>
    <tr><td>업종</td><td style="text-align:left">{{ r.plan.industry_label }}</td></tr>
    <tr><td>기간</td><td style="text-align:left">{{ r.plan.period_label }}{% if r.plan.period and r.plan.period.note %} — {{ r.plan.period.note }}{% endif %}</td></tr>
  </table>
  <p class="note">프로그램이 질문을 이렇게 이해하고 계산했다는 기록입니다({{ '외부 AI가 해석' if r.plan.source=='llm' else ('이용자가 직접 고친 해석' if r.plan.source=='user' else '규칙으로 해석') }}). 은행·거래처 제출용에서는 빼도 됩니다.</p></div>
  {% if r.llm_audit %}<div class="keep"><h2>부록 B. 외부 LLM 전송 내역 (이 분석)</h2>
  <table><thead><tr><th style="text-align:left">목적</th><th style="text-align:left">제공자/모델</th><th>전송 문자 수</th><th style="text-align:left">포함된 표</th><th style="text-align:left">상태</th></tr></thead>
  {% for a in r.llm_audit %}<tr><td>{{ a.purpose }}</td><td style="text-align:left">{{ a.provider }}/{{ a.model }}</td><td>{{ '{:,}'.format(a.chars_sent) }}</td><td style="text-align:left">{% for t in a.tables %}{{ t.table }}({{ t.rows }}행) {% endfor %}</td><td style="text-align:left">{{ a.status }}</td></tr>{% endfor %}</table>
  <p class="note">원본 행 데이터는 전송되지 않습니다. 전송된 표는 모두 반출 검수를 통과한 집계값이며, 가린 칸은 값 없이(null) 전달됩니다.</p></div>{% endif %}
  </div>

  <div class="footer">출처: 제주빅데이터센터·제주데이터허브 데이터를 {{ app }}(v{{ version }})으로 집계·가공 · 생성 {{ r.generated_at }} · 본 보고서의 수치는 집계값이며 반출 기준 검수를 거쳤습니다. 개인 사업계획서·내부 자료로 활용할 수 있으며(출처 표기), 판매·출판 등 제3자 제공은 데이터 제공기관과 협의가 필요합니다.</div>
</div></body></html>""", autoescape=True)


def render_html(ctx: dict) -> str:
    return _TEMPLATE.render(r=ctx, app=APP_NAME, version=__version__)


def table_html(display_df) -> str:
    if display_df is None or display_df.empty:
        return "<p class='note'>표시할 행이 없습니다.</p>"
    return display_df.to_html(index=False, border=0, escape=True, na_rep="")


def img_b64(path: str) -> str:
    return base64.b64encode(Path(path).read_bytes()).decode("ascii")


# ── PDF ─────────────────────────────────────────────────────────────────────
def find_browser() -> str | None:
    env = os.getenv("PDF_BROWSER")
    if env and Path(env).exists():
        return env
    cands: list[str] = []
    sysname = platform.system()
    if sysname == "Windows":
        pf, pf86, local = os.getenv("ProgramFiles", r"C:\Program Files"), os.getenv("ProgramFiles(x86)", r"C:\Program Files (x86)"), os.getenv("LOCALAPPDATA", "")
        cands += [rf"{pf86}\Microsoft\Edge\Application\msedge.exe", rf"{pf}\Microsoft\Edge\Application\msedge.exe",
                  rf"{pf}\Google\Chrome\Application\chrome.exe", rf"{pf86}\Google\Chrome\Application\chrome.exe", rf"{local}\Google\Chrome\Application\chrome.exe"]
    elif sysname == "Darwin":
        cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge", "/Applications/Chromium.app/Contents/MacOS/Chromium"]
    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "msedge"):
        p = shutil.which(name)
        if p:
            cands.append(p)
    for c in cands:
        if c and Path(c).exists():
            return c
    return None


def html_to_pdf(html_path: Path, pdf_path: Path, timeout: int = 60) -> tuple[bool, str]:
    """HTML 보고서를 PDF로. 1순위 이 PC의 Edge/Chrome(headless), 2순위 reportlab 간이 변환.

    반환값 how: 'browser:msedge.exe' | 'reportlab:MalgunGothic' | 'error:...'. 'reportlab:'로 시작하면 UI가 간이 변환임을 알린다.
    """
    exe = find_browser()
    if exe:
        import shutil as _sh
        import tempfile
        # 사용자가 Edge/Chrome을 켜 둔 상태(기본 프로필 잠김)나 직전 변환이 중단된 경우에도 충돌하지 않도록
        # 변환마다 새 임시 프로필을 만들고 끝나면 지운다. 파일 하나를 그리는 일이라 네트워크·동기화·확장은 모두 끈다.
        # --incognito: 세션 저장·복원을 하지 않아(이전 변환 탭을 다시 여는 현상 방지) 변환이 항상 1~2초에 끝난다.
        profile = Path(tempfile.mkdtemp(prefix="compass_pdf_"))
        # Chromium 공통 --incognito에 Edge 전용 --inprivate를 함께 준다(모르는 옵션은 브라우저가 무시)
        private = "--incognito --inprivate" if "msedge" in Path(exe).name.lower() else "--incognito"
        cmd = [exe, "--headless=new", *private.split(), "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-extensions",
               f"--user-data-dir={profile}", "--disable-component-update", "--disable-background-networking", "--disable-sync",
               "--disable-default-apps", "--disable-session-crashed-bubble", "--hide-crash-restore-bubble",
               "--no-pdf-header-footer", "--run-all-compositor-stages-before-draw", "--virtual-time-budget=4000",
               f"--print-to-pdf={pdf_path}", html_path.resolve().as_uri()]
        if platform.system() == "Linux":
            cmd.insert(1, "--no-sandbox")
        try:
            cp = subprocess.run(cmd, capture_output=True, timeout=timeout, check=False)
            if pdf_path.exists() and pdf_path.stat().st_size > 1000:
                return True, f"browser:{Path(exe).name}"
            log.warning("브라우저 PDF 변환이 파일을 만들지 못함(rc=%s): %s", cp.returncode, (cp.stderr or b"")[-300:])
        except subprocess.TimeoutExpired:
            log.warning("브라우저 PDF 변환 시간 초과(%ss) — 간이 변환으로 대체", timeout)
        except Exception as e:  # noqa: BLE001
            log.warning("브라우저 PDF 변환 실패: %s", e)
        finally:
            _sh.rmtree(profile, ignore_errors=True)
    ok, how = _reportlab_pdf(html_path, pdf_path)
    return ok, how


def _find_ttf() -> tuple[str, str] | None:
    sysname = platform.system()
    cands = []
    if sysname == "Windows":
        w = os.getenv("WINDIR", r"C:\Windows")
        cands += [("MalgunGothic", rf"{w}\Fonts\malgun.ttf"), ("Gulim", rf"{w}\Fonts\gulim.ttc")]
    elif sysname == "Darwin":
        cands += [("AppleGothic", "/System/Library/Fonts/Supplemental/AppleGothic.ttf")]
    cands += [("NanumGothic", "/usr/share/fonts/truetype/nanum/NanumGothic.ttf"), ("WenQuanYi", "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc")]
    for name, p in cands:
        if Path(p).exists():
            return name, p
    return None


def _reportlab_pdf(html_path: Path, pdf_path: Path) -> tuple[bool, str]:
    """브라우저가 없을 때의 단순 PDF(텍스트·표·이미지). HTML을 완전히 재현하지는 않음."""
    try:
        import re
        from html import unescape
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
        from reportlab.lib.styles import ParagraphStyle
        font = _find_ttf()
        if font is None:
            return False, "no-korean-font"
        name, path = font
        pdfmetrics.registerFont(TTFont(name, path, subfontIndex=0) if path.endswith(".ttc") else TTFont(name, path))
        from reportlab.platypus import Table, TableStyle
        from reportlab.lib import colors
        html = html_path.read_text(encoding="utf-8")
        body = re.sub(r"<style.*?</style>", "", html, flags=re.S)
        imgs = re.findall(r'src="data:image/png;base64,([^"]+)"', body)
        # 표는 셀 텍스트만 뽑아 reportlab Table로 다시 그린다(간이 변환이지만 숫자는 그대로 전달)
        tables_txt = []
        for tb in re.findall(r"<table.*?</table>", body, flags=re.S):
            rows = []
            for tr in re.findall(r"<tr.*?</tr>", tb, flags=re.S):
                cells = [unescape(re.sub(r"<[^>]+>", "", c)).strip() for c in re.findall(r"<t[hd][^>]*>(.*?)</t[hd]>", tr, flags=re.S)]
                if cells:
                    rows.append(cells)
            if rows:
                tables_txt.append(rows[:60])
        text = re.sub(r"<(script|table).*?</\1>", "", body, flags=re.S)
        text = re.sub(r"<h1[^>]*>(.*?)</h1>", r"\n# \1\n", text, flags=re.S)
        text = re.sub(r"<h2[^>]*>(.*?)</h2>", r"\n## \1\n", text, flags=re.S)
        text = re.sub(r"<h3[^>]*>(.*?)</h3>", r"\n### \1\n", text, flags=re.S)
        text = re.sub(r"<li[^>]*>(.*?)</li>", r"\n• \1", text, flags=re.S)
        text = re.sub(r"<[^>]+>", " ", text)
        text = unescape(re.sub(r"[ \t]+", " ", text))
        doc = SimpleDocTemplate(str(pdf_path), pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=15 * mm, bottomMargin=15 * mm)
        st = ParagraphStyle("b", fontName=name, fontSize=9.5, leading=14)
        h1 = ParagraphStyle("h1", fontName=name, fontSize=16, leading=20, spaceAfter=6)
        h2 = ParagraphStyle("h2", fontName=name, fontSize=12, leading=16, spaceBefore=8, spaceAfter=4)
        flow = []
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith("# "):
                flow.append(Paragraph(line[2:], h1))
            elif line.startswith("## ") or line.startswith("### "):
                flow.append(Paragraph(line.lstrip("# "), h2))
            else:
                flow.append(Paragraph(line, st))
        import io
        for b in imgs:
            buf = io.BytesIO(base64.b64decode(b))
            flow.append(Spacer(1, 4 * mm))
            flow.append(Image(buf, width=170 * mm, height=92 * mm))
        cell = ParagraphStyle("c", fontName=name, fontSize=7.5, leading=9.5)
        for rows in tables_txt:
            ncol = max(len(r) for r in rows)
            data = [[Paragraph(c, cell) for c in r] + [""] * (ncol - len(r)) for r in rows]
            tbl = Table(data, repeatRows=1, colWidths=[(180 * mm) / ncol] * ncol)
            tbl.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.grey), ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke),
                                     ("VALIGN", (0, 0), (-1, -1), "TOP")]))
            flow.append(Spacer(1, 4 * mm))
            flow.append(tbl)
        flow.append(Spacer(1, 4 * mm))
        flow.append(Paragraph("※ 이 PDF는 브라우저(Edge/Chrome)를 찾지 못한 환경의 간이 변환본입니다. 모양은 단순하지만 숫자·표·차트는 같습니다. 원본 모양은 HTML 보고서를 참고하세요.", st))
        doc.build(flow)
        return pdf_path.exists(), f"reportlab:{name}"
    except Exception as e:  # noqa: BLE001
        log.warning("reportlab PDF 실패: %s", e)
        return False, f"error:{e}"

"""차트 생성(matplotlib, PNG). 반출 검수를 통과한 표(비공개 셀 제외)만 그린다.

디자인 규칙: 단일 색조(단일 시리즈) / 고정 순서 범주색(다중 시리즈), 얇은 막대, 2px 선, 최소 8px 마커,
한 축만 사용(이중축 금지), 범례는 2개 이상 시리즈일 때만, 선택적 직접 라벨, 옅은 격자.
"""
from __future__ import annotations

import logging
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from .templates.base import ChartSpec, Table  # noqa: E402

log = logging.getLogger(__name__)
logging.getLogger("matplotlib.category").setLevel(logging.WARNING)
logging.getLogger("matplotlib.font_manager").setLevel(logging.WARNING)

MIN_POINTS = 2  # 점·막대가 1개뿐인 차트는 정보가 없어 그리지 않음


def _pretty_x(v) -> str:
    """연월(202510)→'2025.10', 연도(2025)→'2025년'처럼 축 라벨을 읽기 쉽게."""
    s = str(v)
    if len(s) == 6 and s.isdigit():
        return f"{s[:4]}.{s[4:]}"
    if len(s) == 7 and s[4] in ".-" and s[:4].isdigit():
        return f"{s[:4]}.{s[5:]}"
    return s

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
SURFACE, TEXT, TEXT2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e6e5e1"
GOOD, BAD = "#2a78d6", "#e34948"
_FONT_CANDIDATES = ["Malgun Gothic", "맑은 고딕", "Apple SD Gothic Neo", "AppleGothic", "NanumGothic", "Nanum Gothic", "NanumBarunGothic",
                    "Noto Sans CJK KR", "Noto Sans KR", "Source Han Sans KR", "WenQuanYi Zen Hei", "Unifont-JP"]
_font_name: str | None = None


def setup_font() -> str:
    """시스템에서 한글 폰트를 찾아 matplotlib에 설정. 반환: 사용 폰트명(없으면 'DejaVu Sans')."""
    global _font_name
    if _font_name:
        return _font_name
    available = {f.name for f in font_manager.fontManager.ttflist}
    for cand in _FONT_CANDIDATES:
        if cand in available:
            _font_name = cand
            break
    else:
        _font_name = "DejaVu Sans"
        log.warning("한글 폰트를 찾지 못했습니다. 차트의 한글이 깨질 수 있습니다. (맑은 고딕/나눔고딕 설치 권장)")
    plt.rcParams["font.family"] = _font_name
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.facecolor"] = SURFACE
    plt.rcParams["axes.facecolor"] = SURFACE
    plt.rcParams["savefig.facecolor"] = SURFACE
    return _font_name


def _fmt_axis(v, _pos=None):
    a = abs(v)
    if a >= 1e8:
        return f"{v / 1e8:,.1f}억".replace(".0억", "억")
    if a >= 1e4:
        return f"{v / 1e4:,.0f}만"
    return f"{v:,.0f}"


def _fmt_val(v: float, measure: str) -> str:
    if measure in ("use_amt", "amt_per_visit", "sale_amt"):
        a = abs(v)
        if a >= 1e8:
            return f"{v / 1e8:,.1f}억"
        if a >= 1e4:
            return f"{v / 1e4:,.0f}만"
        return f"{v:,.0f}"
    if measure in ("yoy", "share", "score"):
        return f"{v:+.1f}%" if measure == "yoy" else f"{v:.1f}"
    if measure in ("stores_per_1e8", "stores_per_1k_visit"):
        return f"{v:.2f}"
    return f"{v:,.0f}"


def _style(ax, ylabel_money: bool):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=TEXT2, labelsize=9)
    ax.grid(axis="y", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    if ylabel_money:
        ax.yaxis.set_major_formatter(FuncFormatter(_fmt_axis))


def _safe(table: Table) -> pd.DataFrame:
    df = table.sdc.table if table.sdc is not None else table.df
    if "_suppressed" in df.columns:
        df = df[~df["_suppressed"]].drop(columns=["_suppressed"])
    return df.copy()


def render(spec: ChartSpec, table: Table, out_dir: Path, labels: dict[str, str]) -> dict | None:
    setup_font()
    df = _safe(table)
    if df.empty:
        return None
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{spec.filename or spec.table}.png"
    money = spec.y in ("use_amt", "amt_per_visit") if isinstance(spec.y, str) else False
    fig, ax = plt.subplots(figsize=(8.2, 4.1), dpi=150)
    note = ""
    if table.sdc is not None and (table.sdc.n_suppressed or table.sdc.n_secondary):
        note = f"※ 개인정보 보호를 위해 가린 {table.sdc.n_suppressed + table.sdc.n_secondary}칸은 차트에서 제외했습니다"
    try:
        kind = spec.kind
        # 범주 상향으로 시리즈 차원이 사라졌으면 단일 시리즈 차트로 낮춰 그린다
        if kind in ("multiline", "groupbar") and (spec.series not in df.columns):
            kind = "line" if kind == "multiline" else "bar"
        if kind in ("multiline_wide", "groupbar_wide") and not any(c in df.columns for c in (spec.y if isinstance(spec.y, list) else [spec.y])):
            plt.close(fig)
            return None
        if kind in ("bar", "barh"):
            y = spec.y
            d = df[[spec.x, y]].dropna()
            if spec.options.get("order"):
                pos = {v: i for i, v in enumerate(spec.options["order"])}
                d = d.assign(_o=d[spec.x].map(lambda v: pos.get(str(v), 999))).sort_values("_o").drop(columns="_o")
            elif kind == "barh":
                d = d.sort_values(y, ascending=True)
            if len(d) < MIN_POINTS:
                plt.close(fig)
                return None
            labels_x = [_pretty_x(v) for v in d[spec.x].tolist()]
            vals = d[y].astype(float).tolist()
            if spec.options.get("diverging"):
                colors = [GOOD if v >= 0 else BAD for v in vals]
            else:
                colors = [SERIES[0]] * len(vals)
            if kind == "barh":
                bars = ax.barh(labels_x, vals, color=colors, height=0.62)
                ax.grid(axis="x", color=GRID, linewidth=0.8)
                ax.grid(axis="y", visible=False)
                ax.xaxis.set_major_formatter(FuncFormatter(_fmt_axis if money else (lambda v, p: f"{v:g}")))
                for b, v in zip(bars, vals):
                    ax.text(b.get_width() + (max(abs(x) for x in vals) * 0.01 if vals else 0), b.get_y() + b.get_height() / 2, _fmt_val(v, y), va="center", ha="left" if v >= 0 else "right", fontsize=8, color=TEXT2)
                if spec.options.get("diverging"):
                    ax.axvline(0, color=TEXT2, linewidth=0.8)
                for s in ("top", "right"):
                    ax.spines[s].set_visible(False)
                ax.tick_params(colors=TEXT2, labelsize=9)
            else:
                bars = ax.bar(labels_x, vals, color=colors, width=0.62)
                _style(ax, money)
                top_i = int(np.argmax(vals))
                ax.text(bars[top_i].get_x() + bars[top_i].get_width() / 2, bars[top_i].get_height(), _fmt_val(vals[top_i], y), ha="center", va="bottom", fontsize=8.5, color=TEXT2)
                if len(labels_x) > 8:
                    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
        elif kind == "line":
            d = df[[spec.x, spec.y]].dropna().sort_values(spec.x)
            if len(d) < MIN_POINTS:
                plt.close(fig)
                return None
            xs = [_pretty_x(v) for v in d[spec.x].tolist()]
            ys = d[spec.y].astype(float).tolist()
            ax.plot(xs, ys, color=SERIES[0], linewidth=2, marker="o", markersize=5, markerfacecolor=SERIES[0], markeredgecolor=SURFACE, markeredgewidth=1.5)
            _style(ax, money)
            if ys:
                ax.annotate(_fmt_val(ys[-1], spec.y), (xs[-1], ys[-1]), textcoords="offset points", xytext=(4, 6), fontsize=8.5, color=TEXT2)
                pk = int(np.argmax(ys))
                if pk != len(ys) - 1:
                    ax.annotate(_fmt_val(ys[pk], spec.y), (xs[pk], ys[pk]), textcoords="offset points", xytext=(0, 7), fontsize=8.5, color=TEXT2, ha="center")
            if len(xs) > 12:
                plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
            ax.set_ylim(bottom=0)
        elif kind == "multiline":
            d = df[[spec.x, spec.series, spec.y]].dropna()
            series_vals = list(dict.fromkeys(d[spec.series].astype(str)))
            if len(series_vals) > 8:
                keep = d.groupby(spec.series)[spec.y].sum().sort_values(ascending=False).head(7).index.astype(str).tolist()
                d[spec.series] = d[spec.series].astype(str).where(d[spec.series].astype(str).isin(keep), "기타")
                d = d.groupby([spec.x, spec.series], as_index=False)[spec.y].sum()
                series_vals = keep + ["기타"]
            xs_all = sorted(d[spec.x].astype(str).unique())
            if len(xs_all) < MIN_POINTS:
                plt.close(fig)
                return None
            xs_lab = [_pretty_x(x) for x in xs_all]
            dropped = []
            drawn = 0
            for i, sv in enumerate(series_vals):
                sub = d[d[spec.series].astype(str) == sv].set_index(d[d[spec.series].astype(str) == sv][spec.x].astype(str))
                ys = [float(sub[spec.y].get(x, np.nan)) if x in sub.index else np.nan for x in xs_all]
                if sum(1 for v in ys if not np.isnan(v)) < MIN_POINTS:
                    dropped.append(sv)   # 가린 칸이 많아 점이 1개 이하인 그룹은 선을 그리지 않음
                    continue
                drawn += 1
                ax.plot(xs_lab, ys, color=SERIES[i % 8], linewidth=2, marker="o", markersize=4.5, markeredgecolor=SURFACE, markeredgewidth=1.2, label=sv)
            if drawn == 0:
                plt.close(fig)
                return None
            if dropped:
                note = (note + "  " if note else "") + f"※ {', '.join(dropped[:4])}{' 등' if len(dropped) > 4 else ''}: 가린 칸이 많아 선을 그리지 않음"
            _style(ax, money)
            ax.legend(frameon=False, fontsize=8.5, ncol=min(4, max(1, drawn)), loc="upper left", bbox_to_anchor=(0, 1.02))
            if len(xs_all) > 12:
                plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
            ax.set_ylim(bottom=0)
        elif kind == "multiline_wide":
            ys_cols = [c for c in spec.y if c in df.columns]
            d = df[[spec.x, *ys_cols]].sort_values(spec.x)
            if len(d) < MIN_POINTS or not ys_cols:
                plt.close(fig)
                return None
            xs = [_pretty_x(v) for v in d[spec.x].tolist()]
            for i, c in enumerate(ys_cols):
                ax.plot(xs, d[c].astype(float).tolist(), color=SERIES[i % 8], linewidth=2, marker="o", markersize=4.5, markeredgecolor=SURFACE, markeredgewidth=1.2, label=labels.get(c, c))
            _style(ax, False)
            ax.yaxis.set_major_formatter(FuncFormatter(_fmt_axis))
            ax.legend(frameon=False, fontsize=8.5, ncol=len(ys_cols), loc="upper left", bbox_to_anchor=(0, 1.02))
            if len(xs) > 12:
                plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
            ax.set_ylim(bottom=0)
        elif kind in ("groupbar", "groupbar_wide"):
            if kind == "groupbar":
                d = df[[spec.x, spec.series, spec.y]].dropna()
                piv = d.pivot_table(index=spec.x, columns=spec.series, values=spec.y, aggfunc="sum").fillna(0)
            else:
                piv = df.set_index(spec.x)[[c for c in spec.y if c in df.columns]].astype(float)
                piv.columns = [labels.get(c, c) for c in piv.columns]
            cats = [_pretty_x(v) for v in piv.index.tolist()]
            n = len(piv.columns)
            if len(cats) * n < MIN_POINTS or n == 0:
                plt.close(fig)
                return None
            width = 0.7 / max(n, 1)
            x = np.arange(len(cats))
            for i, c in enumerate(piv.columns):
                ax.bar(x + (i - (n - 1) / 2) * width, piv[c].values, width=width * 0.92, color=SERIES[i % 8], label=str(c))
            ax.set_xticks(x, cats)
            _style(ax, money)
            ax.legend(frameon=False, fontsize=8.5, ncol=min(4, n), loc="upper left", bbox_to_anchor=(0, 1.02))
            if len(cats) > 8:
                plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
        elif kind == "donut":
            d = df[[spec.x, spec.y]].dropna().sort_values(spec.y, ascending=False)
            if len(d) > 6:
                top = d.head(5)
                other = pd.DataFrame({spec.x: ["기타"], spec.y: [d[spec.y].iloc[5:].sum()]})
                d = pd.concat([top, other], ignore_index=True)
            if len(d) < MIN_POINTS:
                plt.close(fig)
                return None
            vals = d[spec.y].astype(float).values
            labs = d[spec.x].astype(str).tolist()
            tot = vals.sum() if vals.sum() else 1
            wedges, _ = ax.pie(vals, colors=SERIES[:len(vals)], startangle=90, counterclock=False, wedgeprops={"width": 0.38, "edgecolor": SURFACE, "linewidth": 2})
            ax.legend(wedges, [f"{l} {v / tot * 100:.1f}%" for l, v in zip(labs, vals)], frameon=False, fontsize=8.5, loc="center left", bbox_to_anchor=(1.0, 0.5))
            ax.set_aspect("equal")
        else:
            plt.close(fig)
            return None
        ax.set_title(spec.title, fontsize=11, color=TEXT, loc="left", pad=14 if kind in ("multiline", "multiline_wide", "groupbar", "groupbar_wide") else 8)
        if note:
            fig.text(0.01, 0.01, note, fontsize=7.5, color=TEXT2)
        fig.tight_layout()
        fig.savefig(path)
        plt.close(fig)
        return {"path": str(path), "title": spec.title, "filename": path.name, "table": spec.table}
    except Exception as e:  # noqa: BLE001
        plt.close(fig)
        log.warning("차트 생성 실패(%s): %s", spec.title, e)
        return None

"""지역 사전: 제주 법정동(읍면 포함)·권역·시 구분과 자연어 지역명 해석.

- 센터 데이터의 `bjd`(법정동) 컬럼은 동 지역은 법정동명, 읍면 지역은 읍면명으로 들어옵니다.
  (예: "서귀포시 서부", "대정읍" / 운영진 답변: 제주시 40개 법정동, 서귀포시 22개 법정동, 읍면 12개)
- `dstrct_se`(지역구분)은 7개 권역: 제주시 중부(동)/중부(서)/동부/서부, 서귀포시 중부/동부/서부
- 아래 권역 배정은 데이터 명세서 [참고1] 지역구분을 기준으로 수정할 수 있습니다 (geo.py 상단 표만 바꾸면 됨).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Iterable

JEJU_CITY = "제주시"
SEOGWIPO_CITY = "서귀포시"

# (법정동/읍면명, 시, 권역, 유형)  유형: dong=동 지역, eup=읍면 지역
_REGION_TABLE: list[tuple[str, str, str, str]] = [
    # ── 제주시 중부(동) ──
    ("일도일동", JEJU_CITY, "제주시 중부(동)", "dong"), ("일도이동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("이도일동", JEJU_CITY, "제주시 중부(동)", "dong"), ("이도이동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("건입동", JEJU_CITY, "제주시 중부(동)", "dong"), ("화북일동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("화북이동", JEJU_CITY, "제주시 중부(동)", "dong"), ("삼양일동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("삼양이동", JEJU_CITY, "제주시 중부(동)", "dong"), ("삼양삼동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("봉개동", JEJU_CITY, "제주시 중부(동)", "dong"), ("아라일동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("아라이동", JEJU_CITY, "제주시 중부(동)", "dong"), ("도련일동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("도련이동", JEJU_CITY, "제주시 중부(동)", "dong"), ("용강동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("월평동", JEJU_CITY, "제주시 중부(동)", "dong"), ("영평동", JEJU_CITY, "제주시 중부(동)", "dong"),
    ("오등동", JEJU_CITY, "제주시 중부(동)", "dong"), ("회천동", JEJU_CITY, "제주시 중부(동)", "dong"),
    # ── 제주시 중부(서) ──
    ("삼도일동", JEJU_CITY, "제주시 중부(서)", "dong"), ("삼도이동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("용담일동", JEJU_CITY, "제주시 중부(서)", "dong"), ("용담이동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("용담삼동", JEJU_CITY, "제주시 중부(서)", "dong"), ("오라일동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("오라이동", JEJU_CITY, "제주시 중부(서)", "dong"), ("오라삼동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("노형동", JEJU_CITY, "제주시 중부(서)", "dong"), ("연동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("외도일동", JEJU_CITY, "제주시 중부(서)", "dong"), ("외도이동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("이호일동", JEJU_CITY, "제주시 중부(서)", "dong"), ("이호이동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("도두일동", JEJU_CITY, "제주시 중부(서)", "dong"), ("도두이동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("도남동", JEJU_CITY, "제주시 중부(서)", "dong"), ("해안동", JEJU_CITY, "제주시 중부(서)", "dong"),
    ("도평동", JEJU_CITY, "제주시 중부(서)", "dong"), ("내도동", JEJU_CITY, "제주시 중부(서)", "dong"),
    # ── 제주시 동부 (읍면) ──
    ("조천읍", JEJU_CITY, "제주시 동부", "eup"), ("구좌읍", JEJU_CITY, "제주시 동부", "eup"),
    ("우도면", JEJU_CITY, "제주시 동부", "eup"),
    # ── 제주시 서부 (읍면) ──
    ("애월읍", JEJU_CITY, "제주시 서부", "eup"), ("한림읍", JEJU_CITY, "제주시 서부", "eup"),
    ("한경면", JEJU_CITY, "제주시 서부", "eup"), ("추자면", JEJU_CITY, "제주시 서부", "eup"),
    # ── 서귀포시 중부 ──
    ("서귀동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("법환동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("서호동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("호근동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("동홍동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("서홍동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("상효동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("하효동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("신효동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("토평동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("보목동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("영남동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("도순동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("강정동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("월평동(서귀포)", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("대포동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("중문동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("회수동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("하원동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("색달동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    ("상예동", SEOGWIPO_CITY, "서귀포시 중부", "dong"), ("하예동", SEOGWIPO_CITY, "서귀포시 중부", "dong"),
    # ── 서귀포시 동부 (읍면) ──
    ("남원읍", SEOGWIPO_CITY, "서귀포시 동부", "eup"), ("성산읍", SEOGWIPO_CITY, "서귀포시 동부", "eup"),
    ("표선면", SEOGWIPO_CITY, "서귀포시 동부", "eup"),
    # ── 서귀포시 서부 (읍면) ──
    ("대정읍", SEOGWIPO_CITY, "서귀포시 서부", "eup"), ("안덕면", SEOGWIPO_CITY, "서귀포시 서부", "eup"),
]

DISTRICTS = ["제주시 중부(동)", "제주시 중부(서)", "제주시 동부", "제주시 서부",
             "서귀포시 중부", "서귀포시 동부", "서귀포시 서부"]


@dataclass(frozen=True)
class Region:
    name: str          # 법정동/읍면명 (데이터의 bjd 값)
    city: str
    district: str      # 권역 (dstrct_se)
    kind: str          # dong | eup

    @property
    def label(self) -> str:
        return f"{self.city} {self.name}"


REGIONS: list[Region] = [Region(*r) for r in _REGION_TABLE]
REGION_BY_NAME: dict[str, Region] = {r.name: r for r in REGIONS}


def regions_in_district(district: str) -> list[Region]:
    return [r for r in REGIONS if r.district == district]


def regions_in_city(city: str) -> list[Region]:
    return [r for r in REGIONS if r.city == city]


def district_of(bjd: str) -> str | None:
    r = REGION_BY_NAME.get(bjd)
    return r.district if r else None


def city_of(bjd: str) -> str | None:
    r = REGION_BY_NAME.get(bjd)
    return r.city if r else None


# ── 자연어 → 지역 해석 ────────────────────────────────────────────────────────
# 별칭: 짧게 부르는 이름 → 법정동. (마을·관광지 이름은 _VILLAGES: 속한 읍면 전체로 계산되며 그 사실을 라벨에 표시)
_ALIASES: dict[str, list[str]] = {
    "애월": ["애월읍"], "한림": ["한림읍"], "한경": ["한경면"], "추자": ["추자면"], "추자도": ["추자면"],
    "조천": ["조천읍"], "구좌": ["구좌읍"], "우도": ["우도면"], "성산": ["성산읍"], "남원": ["남원읍"],
    "표선": ["표선면"], "대정": ["대정읍"], "안덕": ["안덕면"], "중문": ["중문동"], "노형": ["노형동"],
    "이도": ["이도일동", "이도이동"], "일도": ["일도일동", "일도이동"], "삼도": ["삼도일동", "삼도이동"],
    "용담": ["용담일동", "용담이동", "용담삼동"], "오라": ["오라일동", "오라이동", "오라삼동"], "아라": ["아라일동", "아라이동"],
    "화북": ["화북일동", "화북이동"], "삼양": ["삼양일동", "삼양이동", "삼양삼동"], "외도": ["외도일동", "외도이동"],
    "이호": ["이호일동", "이호이동"], "도두": ["도두일동", "도두이동"], "도련": ["도련일동", "도련이동"],
    "동홍": ["동홍동"], "서홍": ["서홍동"], "법환": ["법환동"], "강정": ["강정동"], "대포": ["대포동"], "색달": ["색달동"],
    "신제주": ["노형동", "연동"], "구제주": ["일도일동", "일도이동", "이도일동", "이도이동", "삼도일동", "삼도이동", "건입동"],
    "서귀포시내": ["서귀동", "동홍동", "서홍동"], "제주시내": ["일도일동", "일도이동", "이도일동", "이도이동", "삼도일동", "삼도이동", "연동", "노형동"],
    "공항": ["용담이동"], "탑동": ["삼도이동"],
}
# 마을(리)·관광지 → 읍면. 리 단위 데이터는 없으므로 읍면 전체로 계산하고, 라벨에 '(한림읍 전체)'를 붙인다.
_VILLAGES: dict[str, str] = {
    # 애월읍
    "하귀": "애월읍", "곽지": "애월읍", "광령": "애월읍", "유수암": "애월읍", "납읍": "애월읍", "하가": "애월읍", "상가": "애월읍", "봉성": "애월읍",
    "어음": "애월읍", "소길": "애월읍", "고성리": "애월읍", "신엄": "애월읍", "구엄": "애월읍", "수산리": "애월읍", "장전": "애월읍", "금성": "애월읍",
    # 한림읍
    "협재": "한림읍", "귀덕": "한림읍", "금악": "한림읍", "옹포": "한림읍", "명월": "한림읍", "대림": "한림읍", "동명": "한림읍", "월령": "한림읍", "비양도": "한림읍", "한수": "한림읍",
    # 한경면
    "저지": "한경면", "조수": "한경면", "신창": "한경면", "고산": "한경면", "용수": "한경면", "청수": "한경면", "낙천": "한경면", "판포": "한경면", "두모": "한경면",
    # 조천읍
    "함덕": "조천읍", "신촌": "조천읍", "북촌": "조천읍", "교래": "조천읍", "선흘": "조천읍", "대흘": "조천읍", "와흘": "조천읍", "조천리": "조천읍", "신흥": "조천읍", "와산": "조천읍",
    # 구좌읍
    "월정": "구좌읍", "세화": "구좌읍", "김녕": "구좌읍", "송당": "구좌읍", "하도": "구좌읍", "종달": "구좌읍", "평대": "구좌읍", "한동": "구좌읍", "행원": "구좌읍",
    "동복": "구좌읍", "상도": "구좌읍", "덕천": "구좌읍",
    # 성산읍
    "성산일출봉": "성산읍", "온평": "성산읍", "고성": "성산읍", "수산": "성산읍", "신풍": "성산읍", "삼달": "성산읍", "신산": "성산읍", "난산": "성산읍",
    "신양": "성산읍", "시흥": "성산읍", "오조": "성산읍", "신천": "성산읍", "섭지코지": "성산읍",
    # 표선면
    "표선해수욕장": "표선면", "가시": "표선면", "하천": "표선면", "성읍": "표선면", "토산": "표선면", "세화리(표선)": "표선면",
    # 남원읍
    "위미": "남원읍", "남원리": "남원읍", "태흥": "남원읍", "신례": "남원읍", "하례": "남원읍", "한남": "남원읍", "수망": "남원읍", "의귀": "남원읍",
    # 대정읍
    "모슬포": "대정읍", "송악산": "대정읍", "하모": "대정읍", "상모": "대정읍", "영락": "대정읍", "무릉": "대정읍", "신도": "대정읍", "일과": "대정읍", "보성": "대정읍", "인성": "대정읍", "안성": "대정읍", "구억": "대정읍", "마라도": "대정읍", "가파도": "대정읍",
    # 안덕면
    "사계": "안덕면", "화순": "안덕면", "덕수": "안덕면", "감산": "안덕면", "창천": "안덕면", "상창": "안덕면", "광평": "안덕면", "동광": "안덕면", "서광": "안덕면", "대평": "안덕면", "산방산": "안덕면",
    # 우도·추자
    "하우목동": "우도면", "천진": "우도면", "대서": "추자면", "신양리": "추자면",
}
_REGION_PLACE_SUFFIX = re.compile(r"[가-힣]{1,6}(리|구|군|시|읍|면|동)(?=[^가-힣]|$)")
_NOT_PLACE_WORDS = {
    "우리", "거리", "요리", "관리", "정리", "무리", "분리", "처리", "자리", "소리", "다리", "머리", "유리", "승리", "권리", "원리", "심리", "논리", "물리", "대리", "오리", "파리", "빨리", "멀리", "달리", "그러리",
    "입구", "친구", "도구", "가구", "요구", "연구", "지구", "인구", "야구", "축구", "농구", "당구", "탁구", "출구", "식구", "문구", "창구", "구구", "유동인구", "방문인구", "거주인구", "근무인구",
    "도시", "역시", "당시", "표시", "무시", "감시", "전시", "상시", "수시", "임시", "잠시", "혹시", "정시", "다시", "조시", "몇시", "몇 시", "실시", "개시", "응시", "주시", "제시", "명시", "과시", "중시",
    "활동", "운동", "이동", "행동", "변동", "감동", "노동", "유동", "자동", "수동", "작동", "공동", "협동", "가동", "진동", "부동", "아동", "합동", "출동", "선동", "소동", "폭동", "파동", "격동", "연동해",
    "측면", "화면", "장면", "라면", "냉면", "국면", "전면", "후면", "내면", "외면", "당면", "정면", "방면", "지면", "수면", "표면", "반면", "일면", "대면", "비대면", "서면", "면면",
    "장군", "대군", "우군", "아군", "적군", "해군", "공군", "육군", "전군", "삼군",
    "읍면", "읍면동", "법정동", "행정동", "동네", "전체", "제주시", "서귀포시", "제주도", "시군구", "시도",
}
_HERE_WORDS = ("우리동네", "우리가게", "우리마을", "여기", "이동네", "우리지역", "내가게", "우리집")
# 널리 쓰이는 관광지·마을 이름(2글자라도 그대로 인식). 그 밖의 2글자 마을명은 일상어와 겹치기 쉬워(하도·한동·사계·상가·가시·일과·고성·동일·회수 …)
# '리/마을/해변/항' 같은 접미사나 조사가 바로 붙을 때만 인식한다.
_VILLAGE_FAMOUS = {"협재", "함덕", "곽지", "월정", "세화", "김녕", "성읍", "하귀", "광령", "송당", "신창", "금악", "명월", "옹포", "귀덕", "위미", "대평",
                   "보목", "북촌", "선흘", "교래", "종달", "평대", "모슬포", "섭지코지", "성산일출봉", "표선해수욕장", "산방산", "송악산", "마라도", "가파도", "비양도", "유수암", "하우목동"}
_VILLAGE_SUFFIX = re.compile(r"^(\s?(리|마을|해수욕장|해변|해안|항|포구|오름|곶자왈|근처|주변|일대)|에서|에서는|에는|에|의|은|는|이랑|랑|이란|과|와|도|부터|까지|쪽|[,·/])")
# 2글자 별칭이 다른 단어의 일부일 때(예: '추이도', '요일도', '경우도', '연동해줘') 오탐을 막기 위한 뒤따름 금지 문자열
_STOP_AFTER = ("해줘", "해주", "하기", "시켜", "하세요", "하여", "해서", "된", "되는", "형", "성", "률", "적", "력")

_CITY_WORDS = {"제주시": JEJU_CITY, "서귀포시": SEOGWIPO_CITY, "서귀포": SEOGWIPO_CITY}
_DISTRICT_PATTERNS = [
    (re.compile(r"제주시\s*중부\s*\(?동\)?"), "제주시 중부(동)"),
    (re.compile(r"제주시\s*중부\s*\(?서\)?"), "제주시 중부(서)"),
    (re.compile(r"제주시\s*동부"), "제주시 동부"),
    (re.compile(r"제주시\s*서부"), "제주시 서부"),
    (re.compile(r"서귀포시?\s*중부"), "서귀포시 중부"),
    (re.compile(r"서귀포시?\s*동부"), "서귀포시 동부"),
    (re.compile(r"서귀포시?\s*서부"), "서귀포시 서부"),
]


@dataclass
class RegionMatch:
    regions: list[str]        # bjd 값 목록 (비어 있으면 전체)
    label: str                # 사람이 읽는 표현
    scope: str                # all | city | district | bjd | eup_only | dong_only
    districts: list[str]
    note: str = ""            # 해석 보충 설명(예: '협재는 한림읍 전체로 계산')
    unknown: list[str] = field(default_factory=list)   # 사전에 없는 지역처럼 보이는 표현
    here: bool = False        # '우리 동네' 등 위치를 알 수 없는 표현
    groups: int = 0           # 질문에서 따로 언급된 지역 표현의 수('노형동과 연동'=2, '삼양동'(3개 법정동 합산)=1)


def _occurrences(text: str, key: str) -> list[int]:
    out, i = [], text.find(key)
    while i != -1:
        out.append(i)
        i = text.find(key, i + 1)
    return out


def _is_word_start(text: str, i: int) -> bool:
    """위치 i 가 한글 음절 뒤가 아니면(문장 시작/공백/숫자/기호 뒤) 단어 시작으로 본다."""
    if i == 0:
        return True
    prev = text[i - 1]
    return not ("가" <= prev <= "힣")


def _good_match(text: str, key: str, strict: bool) -> bool:
    for i in _occurrences(text, key):
        j = i + len(key)
        after = text[j:j + 3]
        if strict:
            if not _is_word_start(text, i):
                continue
            if any(after.startswith(sfx) for sfx in _STOP_AFTER):
                continue
        return True
    return False


_NUMERIC_DONG = re.compile(r"(일도|이도|삼도|용담|오라|아라|화북|삼양|외도|이호|도두|도련)\s*([123])\s*동")
_NUM_KO = {"1": "일", "2": "이", "3": "삼"}


def _josa(word: str) -> str:
    """'은/는' 조사 선택."""
    if not word:
        return "는"
    code = ord(word[-1])
    if 0xAC00 <= code <= 0xD7A3:
        return "은" if (code - 0xAC00) % 28 else "는"
    return "은(는)"


def _expand_numeric_dong(text: str) -> str:
    """'일도2동'·'이도 1동' 같은 행정동식 표기를 법정동 표기('일도이동')로 바꾼다."""
    return _NUMERIC_DONG.sub(lambda m: f"{m.group(1)}{_NUM_KO[m.group(2)]}동", text)


def resolve_regions(text: str) -> RegionMatch:
    """질문 문장에서 지역을 해석. 구체적인 법정동 > 마을(읍면 전체) > 권역 > 시 > 전체 순으로 우선."""
    t = _expand_numeric_dong(text)
    text = t
    compact = text.replace(" ", "")
    found: list[str] = []
    labels: list[str] = []
    notes: list[str] = []

    # 1) 정식 법정동/읍면명 (3글자 이상은 어디서든, 2글자('연동')는 단어 시작에서만)
    for name in sorted(REGION_BY_NAME, key=len, reverse=True):
        key = name.replace("(서귀포)", "")
        strict = len(key) <= 2
        if _good_match(t, key, strict) or (not strict and key in compact):
            if name == "월평동(서귀포)" and "서귀포" not in compact:
                continue
            if name == "월평동" and "서귀포" in compact:
                continue
            if name not in found:
                found.append(name)
                labels.append(name)
    # 2) 별칭 (단어 시작에서만, 정식명에 포함된 별칭은 건너뜀)
    for alias, names in sorted(_ALIASES.items(), key=lambda kv: len(kv[0]), reverse=True):
        if any(alias in lab for lab in labels):
            continue
        if _good_match(t, alias, strict=True) or (len(alias) >= 3 and alias in compact):
            added = False
            for n in names:
                if n not in found:
                    found.append(n)
                    added = True
            if added:
                if len(names) == 1:
                    labels.append(names[0])          # '한림' → '한림읍', '중문' → '중문동'처럼 정식 이름으로
                elif alias in ("신제주", "구제주", "제주시내", "서귀포시내"):
                    labels.append(alias)
                else:
                    labels.append(f"{alias} 일대({len(names)}개 법정동 합산)")
                if len(names) >= 2 and alias not in ("신제주", "구제주", "제주시내", "서귀포시내"):
                    notes.append(f"'{alias}'{_josa(alias)} 법정동 {len(names)}곳({', '.join(names)})을 합쳐서 계산합니다")
    # 3) 마을·관광지 → 읍면 전체 (라벨에 명시)
    for vil, eup in sorted(_VILLAGES.items(), key=lambda kv: len(kv[0]), reverse=True):
        key = vil.split("(")[0]
        if any(key in lab for lab in labels):
            continue
        if len(key) <= 2 and key not in _VILLAGE_FAMOUS:
            # 일상어와 겹치는 2글자 마을명: 어절 시작 + 접미사/조사가 바로 붙을 때만
            ok = any(_is_word_start(t, i) and _VILLAGE_SUFFIX.match(t[i + len(key):i + len(key) + 5] or "") for i in _occurrences(t, key))
            if not ok:
                continue
            if eup in found:          # 같은 읍면이 이미 잡혀 있으면(예: '성산일출봉'의 '성산') 지역을 두 번 세지 않는다
                continue
            found.append(eup)
            labels.append(f"{key}({eup} 전체)")
            notes.append(f"'{key}'{_josa(key)} 마을 단위 자료가 없어 {eup} 전체로 계산합니다")
            continue
        if _good_match(t, key, strict=len(key) <= 2) or (len(key) >= 3 and key in compact):
            if eup in found:
                continue
            found.append(eup)
            labels.append(f"{key}({eup} 전체)")
            notes.append(f"'{key}'{_josa(key)} 마을 단위 자료가 없어 {eup} 전체로 계산합니다")
    here = any(w in compact for w in _HERE_WORDS)
    if found:
        uniq_labels = list(dict.fromkeys(labels))
        return RegionMatch(found, "·".join(uniq_labels), "bjd", sorted({district_of(n) for n in found if district_of(n)}), note="; ".join(notes), here=here, groups=len(uniq_labels))

    # 4) 권역
    for pat, dist in _DISTRICT_PATTERNS:
        if pat.search(text):
            names = [r.name for r in regions_in_district(dist)]
            return RegionMatch(names, dist, "district", [dist], here=here, groups=1)

    # 5) 시 단위 + 읍면/동 한정어
    for word, city in _CITY_WORDS.items():
        if word in compact:
            regs = regions_in_city(city)
            if "읍면" in compact:
                regs = [r for r in regs if r.kind == "eup"]
                return RegionMatch([r.name for r in regs], f"{city} 읍면 지역", "eup_only", sorted({r.district for r in regs}), here=here, groups=1)
            if "동지역" in compact or "동단위" in compact or "도심" in compact:
                regs = [r for r in regs if r.kind == "dong"]
                return RegionMatch([r.name for r in regs], f"{city} 동 지역", "dong_only", sorted({r.district for r in regs}), here=here, groups=1)
            return RegionMatch([r.name for r in regs], f"{city} 전체", "city", sorted({r.district for r in regs}), here=here, groups=1)

    if "읍면" in compact:
        regs = [r for r in REGIONS if r.kind == "eup"]
        return RegionMatch([r.name for r in regs], "제주 읍면 지역", "eup_only", sorted({r.district for r in regs}), here=here, groups=1)
    # 6) 사전에 없는 지역명처럼 보이는 표현(○○리/○○구/○○시 등) 수집 → 되묻기 근거
    unknown = []
    for m in _REGION_PLACE_SUFFIX.finditer(text):
        w = m.group(0)
        if w in _NOT_PLACE_WORDS or w.endswith("동네") or len(w) < 2 or len(w) > 4:
            continue
        if w.endswith("동"):
            continue  # 제주의 법정동은 모두 사전에 있음 — 나머지 '○동'은 대개 일반 명사
        if w.endswith("면") and w[:-1].endswith(("하", "되", "보", "려", "으", "다", "이", "오", "가", "자", "라", "니")):
            continue  # ~하면/되면/보면/려면 등 어미
        if any(w.endswith(x) for x in ("인구", "활동", "이동", "변동", "운동", "거리", "관리", "정리", "처리", "표시", "화면", "비교", "지시")):
            continue
        if w not in REGION_BY_NAME and not any(w.startswith(a) for a in _ALIASES):
            unknown.append(w)
    return RegionMatch([], "제주도 전체", "all", [], unknown=list(dict.fromkeys(unknown)), here=here)


def normalize_bjd(value: str) -> str:
    """데이터의 bjd 값이 '제주시 노형동'처럼 시가 붙어 오거나 공백이 있어도 사전 키와 맞추기."""
    if value is None:
        return value
    v = str(value).strip()
    for c in (JEJU_CITY, SEOGWIPO_CITY):
        if v.startswith(c + " "):
            v = v[len(c) + 1:]
    if v == "월평동":
        return "월평동"  # 시 정보 없이 들어오면 제주시 월평동으로 둠 (권역 배정은 district_of에서)
    return v


def all_bjd_names() -> list[str]:
    return [r.name for r in REGIONS]


def describe_scope(match: RegionMatch) -> str:
    if match.scope == "all":
        return "제주도 전체"
    if match.scope == "bjd" and len(match.regions) <= 3:
        return ", ".join(match.regions)
    return f"{match.label} ({len(match.regions)}개 법정동·읍면)"

"""한국어 질문에서 기간·비교 의도·숫자 옵션을 해석하는 도우미."""
from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class Period:
    start: str          # YYYYMM (실제 계산 범위 — 보유 데이터 범위로 조정될 수 있음)
    end: str            # YYYYMM
    label: str          # 사람이 읽는 표현(요청 기간 기준)
    explicit: bool      # 질문에 기간이 명시되었는지
    requested_start: str | None = None   # 질문이 원래 가리킨 범위(조정 전)
    requested_end: str | None = None
    note: str = ""      # 조정·안내 문구(예: '2025년 1~3월은 자료가 없어 4월부터 계산')

    @property
    def requested(self) -> tuple[str, str]:
        return (self.requested_start or self.start, self.requested_end or self.end)


def add_months(ym: str, n: int) -> str:
    y, m = int(ym[:4]), int(ym[4:6])
    t = y * 12 + (m - 1) + n
    return f"{t // 12}{t % 12 + 1:02d}"


def months_between(start: str, end: str) -> list[str]:
    out = []
    cur = start
    while cur <= end:
        out.append(cur)
        cur = add_months(cur, 1)
        if len(out) > 240:
            break
    return out


def ym_label(ym: str) -> str:
    return f"{ym[:4]}년 {int(ym[4:6])}월"


def period_label(start: str, end: str) -> str:
    if start == end:
        return ym_label(start)
    if start[:4] == end[:4]:
        return f"{start[:4]}년 {int(start[4:6])}월~{int(end[4:6])}월"
    return f"{ym_label(start)}~{ym_label(end)}"


def previous_month_today() -> str:
    """데이터가 없을 때 기준으로 쓰는 '오늘 기준 직전 달'."""
    import datetime as _dt
    d = _dt.date.today().replace(day=1) - _dt.timedelta(days=1)
    return f"{d.year}{d.month:02d}"


# 비교 의도: '작년과 비교', '작년보다', '전년 대비' → 올해(또는 명시 기간)를 기준으로 전년 동기 비교
_COMPARE_LAST_YEAR = re.compile(r"(작년|지난해|전년)(과|이랑|하고|보다|대비|에비해|에비하면|같은기간)")


_TWO_YEAR_COMPARE = re.compile(r"(20\d{2})년?\s*(?:vs|VS|와|과|이랑|랑|하고|및)\s*(20\d{2})년")
_RANGE = re.compile(r"(20\d{2})년?\.?(\d{1,2})월?\s*(?:~|-|–|—|부터|에서|∼)\s*(?:(20\d{2})년?\.?)?(\d{1,2})월?(?:까지)?")


def _finalize(s: str, e: str, label: str, explicit: bool, earliest: str | None, latest: str) -> Period:
    """요청 범위(s,e)를 보유 범위로 조정하되, 요청 범위와 조정 사유를 함께 남긴다.
    전부 보유 범위 밖이면 조정하지 않는다(→ 템플릿이 '자료 없음'으로 안내)."""
    rs, re_ = s, e
    if s > e:
        s, e = e, s
        rs, re_ = s, e
    lo = earliest or "000000"
    if e < lo or s > latest:
        return Period(s, e, label, explicit, rs, re_, note="")
    note = ""
    if s < lo:
        s = lo
        note = f"{ym_label(rs)}~{ym_label(add_months(lo, -1))}은 자료가 없어 {ym_label(lo)}부터 계산"
    if e > latest:
        e = latest
        note = (note + "; " if note else "") + f"{ym_label(add_months(latest, 1))} 이후는 자료가 없어 {ym_label(latest)}까지 계산"
    return Period(s, e, label, explicit, rs, re_, note=note)


def parse_period(text: str, latest: str | None, earliest: str | None = None, default_months: int = 12) -> Period:
    """질문에서 기간을 해석. latest = 적재 데이터의 최신 연월(YYYYMM). 없으면 오늘 기준 직전 달.

    규칙 순서: 명시적 연월 범위 → 단일 연월 → 연도 없는 월 → 분기·반기 → 계절 → 연도 → 상대 표현 → 기본(최근 12개월).
    '작년이랑 비교/전년 대비' 같은 비교 어구는 기간을 바꾸지 않고(비교 의도는 wants_yoy가 처리) 제거한 뒤 해석한다.
    """
    t = text.replace(" ", "")
    latest = latest or previous_month_today()
    ly, lm = int(latest[:4]), int(latest[4:6])
    compare = bool(_COMPARE_LAST_YEAR.search(t)) or bool(_TWO_YEAR_COMPARE.search(t))
    note_extra = " ※ 재작년 비교는 지원하지 않아 작년과 비교합니다" if "재작년" in t else ""
    t = _TWO_YEAR_COMPARE.sub(r"\2년", t)          # '2025년 vs 2026년' → 뒤 연도 기준(전년 비교)
    t = re.sub(r"재작년", "", t)
    t = _COMPARE_LAST_YEAR.sub("", t)              # '작년이랑 비교' 제거 → '올해 여름'만 남음
    t = re.sub(r"(전년|작년|지난해)(동기|같은기간)?(대비|비교)", "", t)

    def mk(s: str, e: str, label: str, explicit: bool = True) -> Period:
        p = _finalize(s, e, label, explicit, earliest, latest)
        if note_extra:
            p.label += note_extra
        return p

    # 1) 명시적 연월 범위: 2026년 7월~9월 / 2025년 10월~2026년 9월 / 2026.07~2026.09 / 202607-202609 / 2025년 4월부터 2026년 9월까지
    m = _RANGE.search(t)
    if m and 1 <= int(m.group(2)) <= 12 and 1 <= int(m.group(4)) <= 12:
        y1, y2 = m.group(1), m.group(3) or m.group(1)
        s, e = f"{y1}{int(m.group(2)):02d}", f"{y2}{int(m.group(4)):02d}"
        return mk(s, e, period_label(s, e))
    # 두 연도가 따로 언급되면('2025년 상반기와 2026년 상반기') 뒤(최근) 연도를 기준으로
    years = re.findall(r"(20\d{2})년", t)
    if len(set(years)) >= 2:
        t = t[t.find(max(years)):]
    # 2) 단일 연월: 2026년 7월 / 2026.7 / 202607 / 26년 7월
    m = re.search(r"(20\d{2})년?[.\-/]?(\d{1,2})월", t) or re.search(r"(20\d{2})(0[1-9]|1[0-2])(?!\d)", t)
    if m and 1 <= int(m.group(2)) <= 12:
        s = f"{m.group(1)}{int(m.group(2)):02d}"
        return mk(s, s, ym_label(s))
    m = re.search(r"(?<!\d)(\d{2})년(\d{1,2})월", t)
    if m and 1 <= int(m.group(2)) <= 12:
        s = f"20{m.group(1)}{int(m.group(2)):02d}"
        return mk(s, s, ym_label(s))
    # 2.5) 연도 없는 월 범위/단일 월: 7월~9월 / 7월 → 데이터 최신 연도 기준(그 달이 아직 없으면 전년)
    m = re.search(r"(?<![\d년])(\d{1,2})월\s*(?:~|-|부터)\s*(\d{1,2})월", t)
    if m and 1 <= int(m.group(1)) <= 12 and 1 <= int(m.group(2)) <= 12:
        y = ly if f"{ly}{int(m.group(2)):02d}" <= latest else ly - 1
        s, e = f"{y}{int(m.group(1)):02d}", f"{y}{int(m.group(2)):02d}"
        return mk(s, e, period_label(s, e))
    m = re.search(r"(?<![\d년.\-/])(\d{1,2})월(?!\s*[~\-부터])", t)
    if m and 1 <= int(m.group(1)) <= 12 and not re.search(r"20\d{2}", t):
        y = ly if f"{ly}{int(m.group(1)):02d}" <= latest else ly - 1
        s = f"{y}{int(m.group(1)):02d}"
        return mk(s, s, ym_label(s))
    m = re.search(r"(20\d{2})[.\-/](\d{1,2})(?![\d월])", t)
    if m and 1 <= int(m.group(2)) <= 12:
        s = f"{m.group(1)}{int(m.group(2)):02d}"
        return mk(s, s, ym_label(s))
    # 3) 분기/반기 ('올' 상반기 = 올해)
    m = re.search(r"(20\d{2})년?(?:(\d)분기|(상반기|하반기))", t) or re.search(r"(?:(\d)분기|(상반기|하반기))", t)
    if m:
        g = m.groups()
        if len(g) == 3:
            year, q, half = g
        else:
            q, half = g
            year = None
        if year is None and ("작년" in t or "지난해" in t) and "올해" not in t:
            year = str(ly - 1)
        year = year or str(ly)
        if q:
            qs = (int(q) - 1) * 3 + 1
            s, e = f"{year}{qs:02d}", f"{year}{qs + 2:02d}"
            lab = f"{year}년 {q}분기"
        else:
            s, e = (f"{year}01", f"{year}06") if half == "상반기" else (f"{year}07", f"{year}12")
            lab = f"{year}년 {half}"
        return mk(s, e, lab)
    # 3.5) 계절·성수기 (연도가 함께 있으면 그 연도, '올해'가 '작년'보다 우선)
    for word, (ms, me, lab) in {"여름": (6, 8, "여름(6~8월)"), "겨울": (12, 2, "겨울(12~2월)"), "봄": (3, 5, "봄(3~5월)"), "가을": (9, 11, "가을(9~11월)"), "성수기": (7, 8, "성수기(7~8월)"), "연말": (11, 12, "연말(11~12월)")}.items():
        if word in t:
            ym_ = re.search(r"(20\d{2})년?", t)
            if ym_:
                y = int(ym_.group(1))
            elif "올해" in t or "금년" in t or "이번" in t:
                y = ly
            elif "작년" in t or "지난해" in t:
                y = ly - 1
            else:
                y = ly if f"{ly}{me:02d}" <= latest else ly - 1
            if ms <= me:
                s, e = f"{y}{ms:02d}", f"{y}{me:02d}"
            else:  # 겨울: 전년 12월 ~ 당해 2월
                s, e = f"{y - 1}{ms:02d}", f"{y}{me:02d}"
            return mk(s, e, f"{y}년 {lab}")
    # 4) 연도 전체: 2025년 (월 없이)
    m = re.search(r"(20\d{2})년(?!\d)", t)
    if m and "월" not in t[m.end():m.end() + 3]:
        y = m.group(1)
        return mk(f"{y}01", f"{y}12", f"{y}년")
    # 5) 상대 표현
    m = re.search(r"(최근|지난|직전)?(\d{1,2})개월(간|동안|치)?", t)
    if m and not re.search(r"\d{1,2}개월(마다|단위)", t):
        n = int(m.group(2))
        s, e = add_months(latest, -(n - 1)), latest
        return mk(s, e, f"최근 {n}개월 ({period_label(s, e)})")
    m = re.search(r"(최근|지난|직전)(\d{1,2})년(간|동안|치)?", t)
    if m and not re.search(r"20\d{2}년", t):
        n = int(m.group(2))
        s, e = add_months(latest, -(12 * n - 1)), latest
        return mk(s, e, f"최근 {n}년 ({period_label(s, e)})")
    if re.search(r"(최근|지난)1년|최근12개월|지난12개월|최근일년", t):
        s, e = add_months(latest, -11), latest
        return mk(s, e, f"최근 1년 ({period_label(s, e)})")
    if re.search(r"지난달|저번달|전월|최근달|최신달|이번달", t):
        return mk(latest, latest, f"자료의 최근 달({ym_label(latest)})")
    if "올해" in t or "금년" in t:
        return mk(f"{ly}01", latest, f"{ly}년(1월~{lm}월)")
    if "작년" in t or "지난해" in t or "전년도" in t:
        return mk(f"{ly - 1}01", f"{ly - 1}12", f"{ly - 1}년")
    # 6) 기본: 비교 의도만 있으면 올해(1월~최신월), 아니면 최근 default_months개월
    if compare:
        return mk(f"{ly}01", latest, f"{ly}년(1월~{lm}월, 전년 동기 비교)")
    s, e = add_months(latest, -(default_months - 1)), latest
    p = _finalize(s, e, f"최근 {len(months_between(max(s, earliest or s), e))}개월 ({period_label(max(s, earliest or s), e)})", False, earliest, latest)
    p.note = ""
    return p


def wants_yoy(text: str) -> bool:
    t = text.replace(" ", "")
    if _TWO_YEAR_COMPARE.search(t) or _COMPARE_LAST_YEAR.search(t):
        return True
    if len(set(re.findall(r"(20\d{2})년", t))) >= 2 and re.search(r"비교|vs|VS|대비|차이", t):
        return True
    return any(k in t for k in ("전년", "작년대비", "작년과", "작년이랑", "작년보다", "작년하고", "지난해", "전년동기", "증감", "증가했", "감소했", "늘었", "줄었", "성장", "변화", "추이", "비교해", "나아졌", "좋아졌", "나빠졌"))


def wants_trend(text: str) -> bool:
    t = text.replace(" ", "")
    return any(k in t for k in ("추이", "트렌드", "변화", "흐름", "월별", "시계열", "증감", "성장"))


def extract_top_n(text: str, default: int = 10) -> int:
    m = re.search(r"(상위|top|TOP)\s*(\d{1,2})", text)
    if m:
        return max(1, min(50, int(m.group(2))))
    m = re.search(r"(\d{1,2})\s*(개|곳|위)", text)
    if m and "개월" not in text:
        n = int(m.group(1))
        if n <= 1:
            return default          # '1위가 어디야' 같은 질문은 상위 1줄이 아니라 순위 표를 원하는 것
        return max(1, min(50, n))
    return default

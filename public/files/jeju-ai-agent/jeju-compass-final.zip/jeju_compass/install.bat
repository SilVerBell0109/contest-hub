@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo  Jeju Sangkwon Nachimban (Jeju Commerce Compass) - INSTALL
echo ============================================================
where py >nul 2>nul
if %errorlevel%==0 (set PY=py -3) else (set PY=python)
%PY% --version >nul 2>nul
if not %errorlevel%==0 (
  echo [ERROR] Python not found. Install Python 3.11+ from https://www.python.org/downloads/
  echo         and check "Add python.exe to PATH" during setup. Then run install.bat again.
  pause
  exit /b 1
)
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"
if not %errorlevel%==0 (
  echo [ERROR] Python 3.11 or newer is required ^(recommended: 3.12^).
  echo         Install Python 3.12 from https://www.python.org/downloads/ and run install.bat again.
  pause
  exit /b 1
)
echo [1/4] Creating virtual environment (.venv) ...
if not exist .venv ( %PY% -m venv .venv )
call .venv\Scripts\activate.bat
echo [2/4] Installing packages (internet required, 1-3 minutes) ...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt
if not %errorlevel%==0 (
  echo [ERROR] Package install failed. Check internet connection or proxy policy.
  echo         Offline PC: see INSTALL.md section "Offline install".
  pause
  exit /b 1
)
echo [3/4] Preparing config file (.env) ...
if not exist .env (
  copy .env.example .env >nul
  echo        Created .env - to use an LLM API key, open .env with Notepad and fill LLM_API_KEY.
)
echo [4/4] Checking installation ...
python verify_install.py
echo.
echo Install finished. Run run.bat to start the program.
pause

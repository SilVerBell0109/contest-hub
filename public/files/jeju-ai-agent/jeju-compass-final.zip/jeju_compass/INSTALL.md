# 설치·실행 매뉴얼 (센터 담당자용 · 비전공자도 따라 할 수 있게 작성)

대상 환경: 제주빅데이터센터 Agent 운영 PC(**Windows 11**, Intel Core i7-8700 / GTX 1060 / RAM 32GB, 브라우저 Chrome·Edge, 모니터 1920×1080)
소요 시간: 처음 설치 약 10분(인터넷 필요), 이후 실행은 더블클릭 한 번

---

## 0. 준비물 체크
| 항목 | 필요 여부 | 비고 |
|---|---|---|
| 인터넷 연결 | 설치할 때만 필수 | 패키지 내려받기(약 150MB). 설치 후 오프라인 동작 가능 |
| Python 3.11 이상 (권장 3.12) | 필수 | 아래 1단계에서 설치. 3.10 이하는 데이터 처리 패키지(pandas 3)가 설치되지 않습니다 |
| Microsoft Edge 또는 Chrome | 권장 | 화면 표시와 PDF 변환에 사용 (Windows 11에는 Edge가 기본 설치됨) |
| 외부 LLM API 키 | 선택 | 없어도 모든 분석이 동작합니다(규칙 기반). 있으면 질문 해석이 더 유연해지고 'AI 해설'이 추가됩니다 |
| 제주데이터허브 프로젝트 키 | 선택 | 허브 Open API 자동 수집 기능에만 사용 |

---

## 1. Python 설치 (이미 있으면 건너뜀)
1. https://www.python.org/downloads/windows/ 접속 → **Python 3.12.x (64-bit) Windows installer** 내려받기
2. 설치 파일 실행 → 첫 화면 맨 아래 **☑ Add python.exe to PATH** 를 반드시 체크 → **Install Now**
3. 설치가 끝나면 창을 닫습니다. (확인: 시작 메뉴에서 `cmd` 실행 후 `python --version` 입력 → `Python 3.12.x` 가 보이면 정상)

## 2. 프로그램 폴더 두기
1. 제출 zip 파일을 원하는 위치(예: `C:\Agent\jeju_compass`)에 **압축 해제**합니다.
   - 경로에 한글이 있어도 동작하지만 가능하면 영문 경로를 권장합니다.
2. 폴더 안에 `install.bat`, `run.bat`, `app.py` 가 보이면 됩니다.

## 3. 설치 (한 번만)
1. 폴더에서 **`install.bat` 더블클릭**
2. 검은 창이 열리고 자동으로 진행됩니다: 가상환경 생성 → 패키지 설치(1~3분) → `.env` 파일 생성 → 설치 점검
3. 마지막에 `결과: 모든 점검 통과` 가 보이면 성공입니다. 아무 키나 눌러 창을 닫습니다.

> **설치 점검만 다시 하려면**: 폴더에서 `cmd` 를 연 뒤 `.venv\Scripts\activate` → `python verify_install.py` 입력
> **보안 프로그램이 .bat 실행을 막으면**: `cmd` 를 열고 아래를 한 줄씩 입력해도 같은 결과입니다.
> ```
> cd /d C:\Agent\jeju_compass
> python -m venv .venv
> .venv\Scripts\activate
> python -m pip install -r requirements.txt
> copy .env.example .env
> python verify_install.py
> ```

## 4. (선택) API 키 설정: 담당자가 한 번만
키는 이용자에게 보이지 않도록 **설정 파일에만** 넣습니다. 코드나 보고서에는 들어가지 않습니다.
1. 폴더의 `.env` 파일을 **메모장**으로 엽니다 (`.env.example` 을 복사한 파일. 없으면 복사해서 이름을 `.env` 로 바꿉니다).
2. 아래 두 줄을 채우고 저장합니다.
   ```
   LLM_PROVIDER=openai          ← openai / anthropic / gemini 중 하나
   LLM_API_KEY=발급받은키
   ```
   - 모델을 바꾸려면 `LLM_MODEL=` 에 모델명 입력(비우면 기본값: gpt-5.6-terra / claude-haiku-5-5 / gemini-3.5-flash-lite. 2026년 11월 기준 각사 소형 모델입니다. 모델이 종료되면 이 값만 바꾸면 됩니다)
   - `LLM_BASE_URL`은 사내 프록시 등 **담당자가 통제하는 주소**로만 바꾸세요. 8절 허용 목록 밖 주소를 넣으면 DLP에 막히거나 데이터가 다른 곳으로 갈 수 있습니다.
   - AI 설명이 실패하면 결과 카드에 원인(모델명·키 오류 등)이 한 줄로 표시되고 숫자 분석은 그대로 진행됩니다.
   - 'AI 해설'을 끄고 질문 해석에만 쓰려면 `LLM_NARRATIVE=false`
3. 제주데이터허브 Open API를 쓰려면 `JEJU_HUB_PROJECT_KEY=` 에 프로젝트 키를 입력합니다(허브 로그인 → 데이터 '프로젝트 담기' → 키 발급).
4. 키 발급처: OpenAI https://platform.openai.com/api-keys · Anthropic https://console.anthropic.com · Google AI Studio https://aistudio.google.com/apikey
5. 비용 참고: 질문 1건당 약 2~4천 토큰 → 소형 모델 기준 약 10~40원. 월 1,000건 사용 시 1~4만원 수준(2026년 공시 단가 기준, 변동 가능).

## 4-1. 인터넷이 안 되는 PC에 설치 (Offline install)
센터 PC가 패키지 저장소(pypi.org)에 접속할 수 없을 때는 인터넷이 되는 PC에서 패키지를 미리 내려받아 옮깁니다.
```
(인터넷 PC, 같은 Python 버전)  python -m pip download -r requirements.txt -d wheels
                                → 생성된 wheels 폴더를 USB 등으로 프로그램 폴더 안에 복사
(센터 PC)  python -m venv .venv  →  .venv\Scripts\activate  →  python -m pip install --no-index --find-links=wheels -r requirements.txt
           python verify_install.py  →  run.bat
```
Python 설치 파일(python.org)도 같은 방법으로 옮겨 설치합니다. 설치 후에는 인터넷 없이 모든 분석이 동작합니다(LLM API·허브 API만 선택적으로 인터넷 사용).

## 5. 실행
1. **`run.bat` 더블클릭** → 검은 창이 뜨고 몇 초 뒤 브라우저가 `http://127.0.0.1:8765` 를 엽니다.
   - 브라우저가 자동으로 안 열리면 Edge/Chrome 주소창에 `127.0.0.1:8765` 를 직접 입력합니다.
   - 이 주소는 **이 PC 안에서만** 접속됩니다(외부 공개 아님).
2. 종료: 검은 창을 닫거나 `Ctrl + C`
3. 매번 실행 시 `data/inbox` 폴더의 CSV가 자동 적재됩니다.

## 6. 바탕화면 바로가기 만들기 (이용자 편의)
`run.bat` 에서 마우스 오른쪽 → **보내기 → 바탕 화면에 바로 가기 만들기** → 이름을 "제주 상권 나침반"으로 변경.

---

## 7. 센터 PC 탑재 시 설정 권장값
| 항목 | 권장 | 이유 |
|---|---|---|
| `.env` → `APP_HOST=127.0.0.1` | 유지 | 로컬 전용 서버 |
| `.env` → `AUTO_LOAD_INBOX=true` | 유지 | 이용자가 내려받은 CSV를 자동 적재 |
| `.env` → `AUTO_LOAD_SAMPLE=false` | 유지 | 실제 운영 시 샘플 혼동 방지(샘플은 버튼으로만) |
| `data/inbox` 폴더 | 바탕화면 바로가기 생성 | 이용자가 CSV를 넣기 쉽게 |
| 퇴실 처리 | 화면의 **[🧹 끝내기(모두 지우기)]** 버튼 또는 `outputs/`, `data/inbox/` 폴더 비우기 | 센터 규정(승인 자료 외 삭제) |
| 보존이 필요한 집계 | 없음(기본) | 이 프로그램은 원본·집계를 세션 밖에 저장하지 않습니다. 보존이 필요하면 반출 신청 절차를 따릅니다 |

## 8. 외부 통신 주소 (보안 허용 목록용)
| 용도 | 주소 | 시점 |
|---|---|---|
| 패키지 설치 | `pypi.org`, `files.pythonhosted.org` | 설치할 때만 |
| Python 내려받기 | `www.python.org` | 설치할 때만 |
| LLM API(선택) | `api.openai.com` / `api.anthropic.com` / `generativelanguage.googleapis.com` 중 설정한 하나 | 질문 해석·AI 해설 시 |
| 제주데이터허브 Open API(선택) | `open.jejudatahub.net` | 허브 데이터 가져오기 시 |
그 외 외부 통신은 없습니다. 원본 데이터·CSV 파일은 어떤 주소로도 전송되지 않습니다.

## 9. 의존성 목록
`requirements.txt` 참조. flask, pandas, numpy, matplotlib, pyyaml, jinja2, requests, python-dotenv, reportlab(선택), pytest(테스트). 로컬 LLM 모델 파일은 사용하지 않습니다(GTX 1060 3GB 환경 고려).

## 10. 자주 생기는 문제
| 증상 | 조치 |
|---|---|
| `python을 찾을 수 없습니다` | 1단계에서 "Add python.exe to PATH" 체크를 빠뜨린 경우. Python을 제거 후 다시 설치하거나, 설치 프로그램 재실행 → Modify → "Add Python to environment variables" 체크 |
| 패키지 설치 실패(빨간 글씨) | 인터넷/프록시 확인. 사내 프록시가 있으면 `set HTTPS_PROXY=http://프록시주소:포트` 입력 후 `install.bat` 재실행 |
| 브라우저에 "연결할 수 없음" | `run.bat` 창이 열려 있는지 확인 → 창의 마지막 줄에 `Running on http://127.0.0.1:8765` 가 있어야 함. 포트 충돌 시 `.env` 의 `APP_PORT=8766` 으로 변경 |
| 차트의 한글이 □□로 보임 | 한글 폰트 없음. Windows에는 '맑은 고딕'이 기본 포함되어 보통 발생하지 않음. 발생 시 나눔고딕 설치 후 재실행 |
| PDF 저장 실패 / '간이 PDF' 경고 | PDF 변환은 Edge/Chrome을 별도 임시 프로필(InPrivate)로 잠깐 실행하므로 이용자가 브라우저를 켜 둔 상태여도 됩니다. 그래도 실패하면 `.env` 의 `PDF_BROWSER=` 에 msedge.exe 경로를 지정하거나, 보고서(HTML)를 열고 브라우저 **인쇄(Ctrl+P) → 'PDF로 저장'** 으로 저장 |
| CSV를 넣었는데 "미분류"로 표시 | 헤더(컬럼명)가 레지스트리와 다른 경우. `python scripts/check_csv.py 파일.csv` 로 진단한 뒤 `compass/datasets.yaml` 의 `aliases`/`value_maps` 에 실제 컬럼명·코드값을 추가(코드 수정 불필요). `USER_MANUAL.md` 8절 참조 |
| 수치가 "비공개(<10)"로 가려짐 | 정상 동작(반출 기준). 기간을 늘리거나 지역·업종 범위를 넓혀 다시 질문 |
| install.bat/run.bat 창의 글자가 영어 | 정상입니다. 배치 파일은 인코딩 문제를 피하려고 영어 메시지만 씁니다(프로그램 화면은 한국어) |
| LLM 오류 메시지(상단 칩 '최근 호출 실패') | 키·모델명·잔액 확인. 모델명은 제공자 공지에 따라 바뀌므로(2026-11 기준 기본값) 제공자 모델 목록에서 현재 이름을 확인해 `.env`의 `LLM_MODEL`에 입력. 오류가 나도 규칙 기반으로 분석은 계속 수행됨 |

## 11. 제거
폴더 전체를 삭제하면 끝입니다(레지스트리·시스템 설정을 건드리지 않음).

"""기획서 HTML → PDF 빌드 (헤드리스 Chrome/Edge). 사용: python docs/proposal/build_proposal.py [--team "팀명"]"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1]))
from compass.report import find_browser  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--team", default="silverbell0109 (개인 참가)")
    ap.add_argument("--out", default=str(HERE / "제주상권나침반_AI_Agent_기획서.pdf"))
    args = ap.parse_args()
    html = (HERE / "proposal.html").read_text(encoding="utf-8").replace("{{ team }}", args.team)
    tmp = HERE / "_proposal_build.html"
    tmp.write_text(html, encoding="utf-8")
    exe = find_browser()
    if not exe:
        raise SystemExit("Chrome/Edge를 찾지 못했습니다. PDF_BROWSER 환경변수로 경로를 지정하세요.")
    out = Path(args.out)
    import shutil, tempfile
    profile = Path(tempfile.mkdtemp(prefix="compass_proposal_"))   # 사용 중인 브라우저와 충돌하지 않게 임시 프로필
    # Chromium 공통 --incognito에 Edge 전용 --inprivate를 함께 준다
    private = "--incognito --inprivate" if "msedge" in Path(exe).name.lower() else "--incognito"
    cmd = [exe, "--headless=new", *private.split(), "--disable-gpu", "--no-sandbox", "--no-first-run", "--disable-extensions",
           f"--user-data-dir={profile}", "--disable-background-networking", "--disable-component-update", "--disable-sync",
           "--no-pdf-header-footer", "--run-all-compositor-stages-before-draw", "--virtual-time-budget=5000",
           f"--print-to-pdf={out}", tmp.resolve().as_uri()]
    try:
        subprocess.run(cmd, capture_output=True, timeout=120, check=False)
    finally:
        tmp.unlink(missing_ok=True)
        shutil.rmtree(profile, ignore_errors=True)
    from pypdf import PdfReader
    reader = PdfReader(str(out))
    n = len(reader.pages)
    text = "\n".join((pg.extract_text() or "") for pg in reader.pages)
    print(f"PDF: {out} ({n}쪽, {out.stat().st_size // 1024} KB) — {'OK (15쪽 이내)' if n <= 15 else '!! 15쪽 초과'}")
    if "[참가자/팀명 기입]" in text:
        print("!! 표지 참가자 칸이 비어 있습니다. 제출 전 --team \"팀명\" 으로 다시 빌드하세요.")
    for stale in ("gpt-4o-mini", "gpt-5-mini", "claude-3-5", "gemini-2.0", "gemini-3.1-flash-lite", "82건", "42문항"):
        if stale in text:
            print(f"!! 구버전 문구가 남아 있습니다: {stale}")


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
cd "$(dirname "$0")"
source .venv/bin/activate 2>/dev/null || { echo "먼저 ./install.sh 를 실행하세요."; exit 1; }
python app.py

"""제주 상권 나침반 — 로컬 웹 서버 (Flask).

실행: python app.py  → 브라우저에서 http://127.0.0.1:8765 접속 (센터 PC 내부에서만 접속되는 로컬 서버)
"""
from __future__ import annotations

import logging
import gc
import os
import re
import shutil
import sys
import threading
import time
import webbrowser
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory, render_template, abort

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from compass import APP_NAME, __version__  # noqa: E402
from compass.agent import Agent  # noqa: E402
from compass.charts import setup_font  # noqa: E402
from compass.llm import LLMClient, load_config  # noqa: E402
import pandas as pd  # noqa: E402
from compass.loader import DataStore, UnknownDataset  # noqa: E402
from compass.registry import get_registry  # noqa: E402
from compass.report import find_browser  # noqa: E402
from compass.templates import CATALOG  # noqa: E402

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env", override=False)
except Exception:  # noqa: BLE001
    pass

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("app")

HOST = os.getenv("APP_HOST", "127.0.0.1")
PORT = int(os.getenv("APP_PORT", "8765"))
INBOX = ROOT / "data" / "inbox"
SAMPLE = ROOT / "sample_data"
OUTPUTS = ROOT / "outputs"
LOGS = ROOT / "logs"
for d in (INBOX, OUTPUTS, LOGS):
    d.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, template_folder=str(ROOT / "web" / "templates"), static_folder=str(ROOT / "web" / "static"))
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024  # 2GB 업로드 허용
store = DataStore()
llm = LLMClient(load_config(), audit_path=LOGS / "llm_audit.jsonl")
agent = Agent(store, llm, out_root=OUTPUTS)
_lock = threading.Lock()
_RUN_ID = re.compile(r"^[0-9A-Za-z_가-힣]{1,80}$")
MAX_QUESTION_CHARS = 300


def _bad(msg: str, code: int = 400):
    return jsonify({"error": msg}), code


def _clean_question(v) -> str | None:
    if not isinstance(v, str):
        return None
    q = " ".join(v.replace("\x00", " ").split())
    return q[:MAX_QUESTION_CHARS]


def _clean_override(o) -> dict:
    """해석 수정값 검증: 문자열/정수만 허용, 범위 제한."""
    if not isinstance(o, dict):
        return {}
    out: dict = {}
    for k in ("region_text", "industry_text"):   # 빈 문자열 = '전체'로 되돌리기
        if isinstance(o.get(k), str):
            out[k] = o[k].strip()[:200]
    for k in ("template", "period_text"):
        if isinstance(o.get(k), str) and o[k].strip():
            out[k] = o[k].strip()[:200]
    if "top_n" in o:
        try:
            out["top_n"] = max(1, min(50, int(o["top_n"])))
        except (TypeError, ValueError):
            pass
    if isinstance(o.get("yoy"), bool):
        out["yoy"] = o["yoy"]
    return out

EXAMPLES = [
    "애월읍 카페 상권 요약해줘", "노형동 한식 음식점 2026년 여름 전년 대비 어때?", "연동 주점은 몇 시에 손님이 많아?",
    "제주시 서부 읍면 중 카페 창업 후보지 비교", "서귀포시 외국인 관광객 소비 추이", "구좌읍 유동인구 분석",
    "한림읍 카페 경쟁 밀도", "제주시 동부 음식점 개폐업 추이", "이 분석에 어떤 데이터가 필요해?",
]


def _status() -> dict:
    return {
        "app": APP_NAME, "version": __version__, "llm": llm.status(), "datasets": store.summaries(), "latest_month": store.latest_month(),
        "sample_mode": store.has_sample(), "examples": EXAMPLES, "templates": [{"key": k, "name": v["name"], "description": v["description"]} for k, v in CATALOG.items()],
        "pdf_browser": bool(find_browser()), "font": setup_font(), "inbox": str(INBOX), "outputs": str(OUTPUTS),
        "hub_key_present": bool(os.getenv("JEJU_HUB_PROJECT_KEY", "").strip()),
        "runs_saved": sum(1 for p in OUTPUTS.iterdir() if p.is_dir() and (p / "result.json").exists()),
        "inbox_files": sum(1 for p in INBOX.rglob("*") if p.is_file() and p.name != ".gitkeep"),
        "registry": [{"key": s.key, "name": s.name, "source": s.source, "export": s.export, "download_guide": s.download_guide} for s in get_registry().datasets.values()],
    }


@app.get("/")
def index():
    return render_template("index.html", app_name=APP_NAME, version=__version__)


@app.get("/api/status")
def api_status():
    return jsonify(_status())


@app.post("/api/scan")
def api_scan():
    with _lock:
        store.skipped = []
        store.last_dropped_samples = []
        new = store.scan_folder(INBOX)
    return jsonify({"loaded": [d.summary() for d in new], "datasets": store.summaries(), "skipped": list(store.skipped),
                    "dropped_samples": list(store.last_dropped_samples), "sample_mode": store.has_sample()})


@app.post("/api/sample")
def api_sample():
    with _lock:
        new = store.scan_folder(SAMPLE, origin="sample")
    return jsonify({"loaded": [d.summary() for d in new], "datasets": store.summaries(), "sample_mode": store.has_sample()})


@app.post("/api/upload")
def api_upload():
    files = request.files.getlist("files")
    if not files:
        return jsonify({"error": "파일이 없습니다"}), 400
    up = INBOX / "uploads"
    up.mkdir(parents=True, exist_ok=True)
    loaded, errors, dropped = [], [], []
    with _lock:
        for f in files:
            name = Path(f.filename or "upload.csv").name
            if not (name.lower().endswith(".csv") or name.lower().endswith(".csv.gz")):
                errors.append(f"{name}: CSV 파일만 지원합니다")
                continue
            data = f.read()
            if not data or not data.strip():
                errors.append(f"{name}: 내용이 비어 있는 파일입니다")
                continue
            try:
                # 먼저 메모리에서 읽어 보고, 알아볼 수 있는 파일만 data/inbox/uploads에 남긴다(쓸 수 없는 파일은 디스크에 저장하지 않음)
                store.last_dropped_samples = []
                ds = store.load_bytes(data, name)
                loaded.append(ds.summary())
                dropped += store.last_dropped_samples
                (up / name).write_bytes(data)
            except UnknownDataset as e:
                errors.append(str(e))
            except pd.errors.EmptyDataError:
                errors.append(f"{name}: 표 형식의 내용이 없는 파일입니다(열 제목·자료 행이 없음)")
            except ValueError as e:
                errors.append(f"{name}: {e}")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{name}: 읽는 중 문제가 생겼습니다 ({type(e).__name__}: {e})")
    return jsonify({"loaded": loaded, "errors": errors, "datasets": store.summaries(), "dropped_samples": dropped, "sample_mode": store.has_sample()})


@app.post("/api/hub")
def api_hub():
    """제주데이터허브 Open API에서 데이터를 받아 데이터함에 적재 (JEJU_HUB_PROJECT_KEY 필요)."""
    body = request.get_json(silent=True) or {}
    key, start, end = body.get("key"), str(body.get("start") or "").strip(), str(body.get("end") or "").strip()
    if not isinstance(key, str) or not key:
        return _bad("받을 데이터 종류(key)를 선택하세요")
    if not os.getenv("JEJU_HUB_PROJECT_KEY", "").strip():
        return _bad("허브 API 키(JEJU_HUB_PROJECT_KEY)가 .env에 없습니다. 담당자에게 문의하세요.")
    try:
        from compass import hub_api
        res = hub_api.fetch(key, start, end, params=body.get("params") or {})
        if res.df.empty:
            return jsonify({"error": f"받은 데이터가 없습니다. {res.note}"}), 400
        with _lock:
            ds = store.load_frame(res.df, f"{key}_{start}_{end}.csv", origin="hub")
            (INBOX / "hub").mkdir(parents=True, exist_ok=True)
            res.df.to_csv(INBOX / "hub" / f"{key}_{start}_{end}.csv", index=False, encoding="utf-8-sig")
        return jsonify({"loaded": ds.summary(), "rows": res.rows, "note": res.note, "datasets": store.summaries()})
    except Exception as e:  # noqa: BLE001
        log.exception("허브 API 실패")
        return jsonify({"error": f"허브 API 오류: {type(e).__name__}: {e}"}), 500


@app.post("/api/remove")
def api_remove():
    key = (request.get_json(silent=True) or {}).get("key")
    if not isinstance(key, str):
        return _bad("삭제할 데이터 키가 없습니다")
    with _lock:
        store.remove(key)
    gc.collect()        # 큰 표를 뺀 뒤 메모리를 바로 돌려준다(센터 PC 32GB 공유)
    return jsonify({"datasets": store.summaries()})


@app.post("/api/clear")
def api_clear():
    """퇴실 정리: 메모리의 데이터와 산출물(outputs)·업로드 파일을 삭제. (센터 규정: 승인된 반출 자료 외 삭제)"""
    body = request.get_json(silent=True) or {}
    with _lock:
        store.clear()
        agent.runs.clear()
        removed = []
        if body.get("delete_outputs", True) is not False:
            for p in OUTPUTS.iterdir():
                if p.is_dir():
                    shutil.rmtree(p, ignore_errors=True)
                    removed.append(p.name)
        if body.get("delete_inbox", False):
            for p in INBOX.rglob("*"):
                if p.is_file() and p.name != ".gitkeep":
                    p.unlink(missing_ok=True)
                    removed.append(p.name)
    gc.collect()
    return jsonify({"removed": removed, "datasets": []})


@app.post("/api/ask")
def api_ask():
    body = request.get_json(silent=True) or {}
    q = _clean_question(body.get("question"))
    if q is None:
        return _bad("질문은 글자(문자열)로 보내 주세요")
    if not q:
        return _bad("질문을 입력하세요")
    try:
        with _lock:
            run = agent.ask(q)
        return jsonify(agent.public_payload(run.run_id))
    except Exception as e:  # noqa: BLE001
        log.exception("분석 실패")
        return jsonify({"error": f"분석 중 오류: {type(e).__name__}: {e}"}), 500


@app.post("/api/rerun")
def api_rerun():
    body = request.get_json(silent=True) or {}
    run_id, override = body.get("run_id"), _clean_override(body.get("override"))
    if not isinstance(run_id, str) or not _RUN_ID.match(run_id):
        return _bad("이전 분석 번호가 올바르지 않습니다")
    try:
        with _lock:
            run = agent.rerun(run_id, override)
        return jsonify(agent.public_payload(run.run_id))
    except KeyError:
        return jsonify({"error": "이전 분석을 찾을 수 없습니다. 질문을 다시 입력하세요."}), 404
    except Exception as e:  # noqa: BLE001
        log.exception("재실행 실패")
        return jsonify({"error": f"재실행 중 오류: {type(e).__name__}: {e}"}), 500


@app.post("/api/pdf")
def api_pdf():
    run_id = (request.get_json(silent=True) or {}).get("run_id")
    if not isinstance(run_id, str) or not _RUN_ID.match(run_id):
        return _bad("분석 번호가 올바르지 않습니다")
    pdf, how = agent.to_pdf(run_id)
    if pdf is None:
        return jsonify({"error": f"PDF 변환 실패({how}). 보고서를 열어 브라우저의 인쇄 → 'PDF로 저장'을 이용하세요."}), 500
    simple = how.startswith("reportlab")
    return jsonify({"pdf_url": f"/outputs/{run_id}/{pdf.name}", "pdf_path": str(pdf.resolve()), "how": how, "simple": simple,
                    "warning": "이 PC에서 Edge/Chrome을 찾지 못해 모양이 단순한 간이 PDF로 만들었습니다(숫자·표는 같음)." if simple else ""})


@app.get("/api/audit")
def api_audit():
    return jsonify({"entries": llm.recent_audit(50)})


@app.get("/api/runs")
def api_runs():
    runs = []
    for p in sorted(OUTPUTS.iterdir(), reverse=True):
        if p.is_dir() and (p / "result.json").exists():
            runs.append({"run_id": p.name, "report": f"/outputs/{p.name}/report.html" if (p / "report.html").exists() else None,
                         "pdf": next((f"/outputs/{p.name}/{x.name}" for x in p.glob("*.pdf")), None)})
    return jsonify({"runs": runs[:50]})


@app.get("/outputs/<path:path>")
def outputs(path):
    full = (OUTPUTS / path).resolve()
    try:
        full.relative_to(OUTPUTS.resolve())
    except ValueError:
        abort(404)
    return send_from_directory(OUTPUTS, path)


def _open_browser():
    time.sleep(1.2)
    try:
        webbrowser.open(f"http://{HOST}:{PORT}")
    except Exception:  # noqa: BLE001
        pass


if __name__ == "__main__":
    setup_font()
    if os.getenv("AUTO_LOAD_INBOX", "true").lower() != "false":
        n = store.scan_folder(INBOX)
        if n:
            log.info("data/inbox에서 %d개 데이터셋 적재", len(n))
    if os.getenv("AUTO_LOAD_SAMPLE", "false").lower() == "true" and not store.datasets:
        store.scan_folder(SAMPLE, origin="sample")
    if os.getenv("OPEN_BROWSER", "true").lower() != "false":
        threading.Thread(target=_open_browser, daemon=True).start()
    log.info("%s v%s — http://%s:%d  (LLM: %s)", APP_NAME, __version__, HOST, PORT, llm.status()["provider"])
    try:
        app.run(host=HOST, port=PORT, debug=False, threaded=True)
    except OSError as e:
        if getattr(e, "errno", None) in (98, 10048, 48) or "address" in str(e).lower() or "in use" in str(e).lower():
            print(f"\n[안내] {PORT}번 포트를 이미 다른 프로그램(또는 먼저 켜 둔 상권 나침반)이 쓰고 있습니다.\n"
                  f"       브라우저에서 http://{HOST}:{PORT} 이 열리는지 확인하고, 열리면 그 창을 그대로 쓰세요.\n"
                  f"       새로 띄우려면 .env의 APP_PORT를 다른 번호(예: 8766)로 바꾸거나, 실행 창에서 set APP_PORT=8766 후 다시 실행하세요.\n")
            raise SystemExit(1)
        raise

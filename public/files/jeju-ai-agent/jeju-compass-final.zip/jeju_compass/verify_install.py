"""설치 점검 — 센터 담당자/심사위원이 설치 직후 실행해 환경을 확인합니다.

python verify_install.py            : 환경·패키지·폰트·브라우저·키 설정 점검 + 샘플 분석 1회(10초 내외)
python verify_install.py --quick    : 분석 실행 없이 점검만
"""
from __future__ import annotations

import importlib
import os
import platform
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
OK, NG, WARN = "[OK] ", "[실패]", "[주의]"


def main() -> int:
    quick = "--quick" in sys.argv
    problems = 0
    print("=" * 60)
    print(" 제주 상권 나침반 설치 점검")
    print("=" * 60)
    v = sys.version_info
    print(f"{OK if v >= (3, 11) else NG} Python {v.major}.{v.minor}.{v.micro} ({platform.system()} {platform.release()})")
    if v < (3, 11):
        print("      Python 3.11 이상이 필요합니다(권장 3.12). python.org에서 새로 설치한 뒤 install.bat을 다시 실행하세요.")
        problems += 1
    for mod, pkg in (("flask", "flask"), ("pandas", "pandas"), ("numpy", "numpy"), ("matplotlib", "matplotlib"), ("yaml", "pyyaml"), ("jinja2", "jinja2"), ("requests", "requests"), ("dotenv", "python-dotenv")):
        try:
            importlib.import_module(mod)
            try:
                from importlib.metadata import version as _ver
                ver = _ver(pkg)
            except Exception:  # noqa: BLE001
                ver = ""
            print(f"{OK} 패키지 {pkg} {ver}")
        except Exception as e:  # noqa: BLE001
            print(f"{NG} 패키지 {pkg} 없음 → pip install {pkg}  ({e})")
            problems += 1
    try:
        importlib.import_module("reportlab")
        print(f"{OK} 패키지 reportlab (브라우저 없을 때 간이 PDF)")
    except Exception:  # noqa: BLE001
        print(f"{WARN} reportlab 없음 — 브라우저가 있으면 문제 없음")

    from compass.charts import setup_font
    font = setup_font()
    print(f"{OK if font != 'DejaVu Sans' else WARN} 차트 한글 폰트: {font}" + ("" if font != "DejaVu Sans" else " → 한글이 깨집니다. 맑은 고딕/나눔고딕을 설치하세요"))
    from compass.report import find_browser
    br = find_browser()
    print(f"{OK if br else WARN} PDF 변환용 브라우저: {br or '없음 (보고서 화면에서 인쇄→PDF 저장 또는 reportlab 간이 변환)'}")

    try:
        from dotenv import load_dotenv
        load_dotenv(ROOT / ".env", override=False)
    except Exception:  # noqa: BLE001
        pass
    from compass.llm import load_config
    cfg = load_config()
    if cfg.enabled:
        print(f"{OK} LLM 설정: {cfg.provider} / {cfg.model} (키 있음)")
    else:
        print(f"{WARN} LLM 키 없음 → 규칙 기반(오프라인) 모드로 동작합니다. AI 해설을 쓰려면 .env 에 LLM_PROVIDER/LLM_API_KEY 입력")
    print(f"{OK if os.getenv('JEJU_HUB_PROJECT_KEY') else WARN} 제주데이터허브 프로젝트 키: {'있음' if os.getenv('JEJU_HUB_PROJECT_KEY') else '없음(선택 기능)'}")

    for d in ("data/inbox", "outputs", "logs", "sample_data"):
        p = ROOT / d
        p.mkdir(parents=True, exist_ok=True)
        print(f"{OK} 폴더 {d}/ {'(쓰기 가능)' if os.access(p, os.W_OK) else '(쓰기 불가!)'}")
    free_gb = shutil.disk_usage(ROOT).free / 1e9
    print(f"{OK if free_gb > 2 else WARN} 디스크 여유 {free_gb:.1f} GB")

    if not quick and problems == 0:
        print("-" * 60)
        print(" 샘플 데이터로 분석 1회 실행 중 (10~20초)...")
        try:
            from compass.loader import DataStore
            from compass.agent import Agent
            from compass.llm import LLMClient, LLMConfig
            store = DataStore()
            n = store.scan_folder(ROOT / "sample_data", origin="sample")
            if not n:
                print(f"{WARN} sample_data 폴더에 샘플이 없습니다 → python scripts/make_sample_data.py 로 생성 가능")
            else:
                agent = Agent(store, LLMClient(LLMConfig(provider="none"), audit_path=Path(tempfile.gettempdir()) / "compass_verify_audit.jsonl"), out_root=Path(tempfile.gettempdir()) / "compass_verify_out")
                run = agent.ask("애월읍 카페 상권 요약해줘")
                p = run.payload
                print(f"{OK} 분석 성공: '{p['title']}' KPI {len(p['kpis'])}개, 차트 {len(p['charts'])}개, 표 {len(p['tables'])}개, 반출검수 {'통과' if p['sdc_overall']['passed'] else '확인필요'} ({p['elapsed_s']}s)")
                pdf, how = agent.to_pdf(run.run_id)
                print(f"{OK if pdf else WARN} PDF 생성: {how}")
                shutil.rmtree(agent.out_root, ignore_errors=True)
        except Exception as e:  # noqa: BLE001
            print(f"{NG} 분석 실행 오류: {type(e).__name__}: {e}")
            problems += 1
    print("-" * 60)
    print(" 결과:", "모든 점검 통과 — run.bat(또는 run.sh)로 실행하세요." if problems == 0 else f"{problems}개 항목 실패 — 위 안내를 확인하세요.")
    return 0 if problems == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

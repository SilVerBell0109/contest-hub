#!/usr/bin/env bash
# 제주 상권 나침반 - 설치 (macOS / Linux)
set -e
cd "$(dirname "$0")"
echo "[1/4] 가상환경(.venv) 만들기"
python3 -m venv .venv
source .venv/bin/activate
echo "[2/4] 패키지 설치 (인터넷 필요)"
python -m pip install --upgrade pip >/dev/null
python -m pip install -r requirements.txt
echo "[3/4] 설정 파일 준비"
[ -f .env ] || cp .env.example .env
echo "[4/4] 설치 점검"
python verify_install.py
echo "설치 완료. ./run.sh 로 실행하세요."

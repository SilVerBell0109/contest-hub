"""CSV 진단 도구 — 센터에서 내려받은 실제 CSV가 어떤 데이터셋으로 인식되고 어떤 컬럼이 매핑되는지 확인합니다.

사용: python scripts/check_csv.py <파일.csv> [<파일2.csv> ...]
출력: 판정된 데이터셋, 매핑된 컬럼(원본→표준), 매핑되지 않은 컬럼, 값 정규화 예시, 기간·지역 커버리지, 조치 안내
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from compass.loader import DataStore, read_csv_any  # noqa: E402
from compass.registry import get_registry  # noqa: E402


def check(path: Path) -> None:
    print("=" * 70)
    print(f"파일: {path}")
    raw = read_csv_any(path)
    reg = get_registry()
    det = reg.detect(raw.columns, path.name)
    print(f"행 수: {len(raw):,} / 원본 컬럼 {len(raw.columns)}개: {', '.join(map(str, raw.columns))}")
    print(f"판정: {det.spec.name if det.spec else '미분류'}  ({det.reason})")
    print("매핑된 컬럼(원본 → 표준):")
    for k, v in det.mapping.items():
        print(f"   {k!s:28s} → {v:12s} ({reg.label(v)})")
    if det.unmapped:
        print("매핑되지 않은 컬럼 (분석에 쓰려면 compass/datasets.yaml 의 aliases 에 추가):")
        for c in det.unmapped:
            sample = raw[c].dropna().astype(str).head(3).tolist()
            print(f"   {c!s:28s} 예시값: {sample}")
    if det.spec is None:
        print("→ 필수 컬럼(연월·지역·금액 등)이 인식되지 않았습니다. 위 '매핑되지 않은 컬럼'의 이름을 datasets.yaml aliases에 추가하세요.")
        return
    st = DataStore(reg)
    ds = st.load_frame(raw, path.name)
    df = ds.df
    p = ds.period
    print(f"정규화 결과: 연월 {p[0]}~{p[1]} ({len(ds.months)}개월)" + (f", 지역 {df['bjd'].nunique()}개" if "bjd" in df.columns else ""))
    for c in ("bjd", "ksic_nm", "user_se", "age_se", "gender_se", "time_se", "dow_se"):
        if c in df.columns:
            vals = df[c].dropna().astype(str).unique()[:8].tolist()
            print(f"   {reg.label(c)}: {vals}{' …' if df[c].nunique() > 8 else ''}")
    if "bjd" in df.columns:
        unknown = df.loc[df["city"].isna(), "bjd"].dropna().unique().tolist()
        if unknown:
            print(f"   ⚠ 사전에 없는 지역명 {len(unknown)}개: {unknown[:10]} → compass/geo.py 표에 추가하면 권역·시가 배정됩니다")
    for n in ds.notes:
        print("   -", n)
    print("→ 이 파일을 data/inbox 폴더에 넣으면 위와 같이 적재됩니다.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    for a in sys.argv[1:]:
        check(Path(a))

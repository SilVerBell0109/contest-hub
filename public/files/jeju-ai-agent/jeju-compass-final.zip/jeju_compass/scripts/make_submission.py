"""최종 제출 zip 생성 — 민감정보·산출물·캐시를 제외하고 제출물만 묶습니다.

사용: python scripts/make_submission.py [--out ../제주상권나침반_최종결과물.zip]
포함: 소스(compass/, web/, app.py, scripts/, tests/), 매뉴얼·명세·설명자료(.md), 설치 스크립트, requirements.txt, .env.example,
      sample_data/(합성), docs/(결정 기록·화면·기획서 PDF), 제출물_구성.txt
제외: .env, logs/*, outputs/*, data/inbox/*(gitkeep 제외), __pycache__, .pytest_cache, .venv, 빌드 임시파일
"""
from __future__ import annotations

import argparse
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE_DIRS = {".venv", "venv", "__pycache__", ".pytest_cache", ".git", "outputs", "logs", ".idea", ".vscode"}
EXCLUDE_FILES = {".env", ".DS_Store", "Thumbs.db"}
EXCLUDE_SUFFIX = {".pyc", ".log"}
MANIFEST = """제주 상권 나침반 — 최종 결과물 구성 (대회 규칙 '최종 결과물' 4개 항목 대응)

[1] 실행 소스 코드
    app.py                      로컬 웹 서버 진입점
    compass/                    에이전트 패키지 (플래너·LLM 전송가드·반출검수·템플릿·차트·보고서·레지스트리)
    compass/datasets.yaml       데이터셋 레지스트리(컬럼 매핑 규칙) — 코드 수정 없이 편집 가능
    web/                        화면 (HTML/CSS/JS)
    scripts/make_sample_data.py 합성 샘플 데이터 생성기 / check_csv.py CSV 매핑 진단 / eval_questions.py 해석 평가 / make_submission.py 제출 zip 생성
    tests/                      자동 테스트 (pytest, 114건) · scripts/eval_questions.py 해석 평가 65문항
    사용 모델·라이브러리: README.md '사용 모델·라이브러리·외부 서비스 명시' 절, requirements.txt

[2] 실행환경·매뉴얼
    README.md                   개요·빠른 시작
    INSTALL.md                  설치·실행 절차(비전공자용, Windows 11 센터 PC), 의존성, 환경변수, 오류 대처, 허용 주소
    USER_MANUAL.md              사용자 매뉴얼(1부 이용자용 / 2부 담당자용), 제약사항·오류 대처
    .env.example                환경변수 예시 (API 키는 포함되어 있지 않음)
    install.bat / run.bat / install.sh / run.sh / verify_install.py

[3] 데이터 활용 명세
    DATA_SPEC.md                필수 데이터 사용 내역, 출처·이용조건, 전처리·분석 흐름, 외부 데이터·오픈소스 목록

[4] 결과 설명자료
    RESULT_REPORT.md            문제 정의, Agent 구조, 주요 기능, 실행 결과, 검증 방법·한계, 센터 활용 방안
    docs/proposal/제주상권나침반_AI_Agent_기획서.pdf   기획서(별도 제출본과 동일)
    docs/screens/               실행 화면 캡처 (합성 샘플 데이터)
    docs/DECISION.md            주제 선정·설계 결정 기록
    docs/REVIEW_FIXES.md        제출 전 독립 검토 2회(심사위원·도민 관점)에서 나온 문제와 보완·검증 내역

[샘플 데이터] sample_data/      명세 구조를 따른 합성(가상) 데이터 — 실제 데이터 아님. 제주데이터허브 '데이터 목록' 파일은 포함하지 않음.

[참가자] silverbell0109 (개인 참가) · 생성형 AI 활용 범위는 README.md '사용 모델·라이브러리·외부 서비스 명시' 절 참조
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT.parent / "제주상권나침반_최종결과물.zip"))
    args = ap.parse_args()
    out = Path(args.out)
    (ROOT / "제출물_구성.txt").write_text(MANIFEST, encoding="utf-8")
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob("*")):
            rel = p.relative_to(ROOT)
            if any(part in EXCLUDE_DIRS for part in rel.parts):
                if not (rel.parts[0] in ("outputs", "logs") and p.name == ".gitkeep"):
                    continue
            if p.name in EXCLUDE_FILES or p.suffix in EXCLUDE_SUFFIX:
                continue
            if rel.parts[0] == "data" and p.name != ".gitkeep":
                continue
            if rel.parts[0] == "docs" and p.name.startswith("_"):
                continue
            if p.is_file():
                z.write(p, Path("jeju_compass") / rel)
                n += 1
    size = out.stat().st_size / 1e6
    print(f"제출 zip 생성: {out} ({n}개 파일, {size:.1f} MB)")
    with zipfile.ZipFile(out) as z:
        names = z.namelist()
        assert not any(name.endswith("/.env") or name.endswith(".env") for name in names), ".env 포함됨!"
        assert not any("llm_audit" in name for name in names), "감사 로그 포함됨!"
        assert not any(name.endswith((".env",)) or "/uploads/" in name for name in names), "업로드 파일 포함됨!"
        assert not any("/review_" in name or "/review2_" in name or "screens/review" in name for name in names), "검토 원문이 포함됨!"
        assert not any(name.lower().endswith((".xlsx", ".xls")) for name in names), "엑셀 파일(허브 데이터 목록 등)이 포함됨!"
        # 기획서 PDF가 최신 HTML과 같은 내용인지(모델명·테스트 수) 검사
        pdf_name = next((n for n in names if n.endswith("기획서.pdf")), None)
        assert pdf_name, "기획서 PDF 없음!"
        import io
        from pypdf import PdfReader
        text = "\n".join((pg.extract_text() or "") for pg in PdfReader(io.BytesIO(z.read(pdf_name))).pages)
        for stale in ("gpt-4o-mini", "gpt-5-mini", "claude-3-5", "gemini-2.0", "gemini-3.1-flash-lite", "82건", "42문항", "42/42"):
            assert stale not in text, f"기획서 PDF에 구버전 문구 '{stale}' — docs/proposal/build_proposal.py 로 다시 빌드하세요"
        if "[참가자/팀명 기입]" in text:
            print("!! 주의: 기획서 표지의 참가자 칸이 비어 있습니다. 제출 전 python docs/proposal/build_proposal.py --team \"팀명\" 후 zip을 다시 만드세요.")
        readme = z.read("jeju_compass/README.md").decode("utf-8")
        for stale in ("(기본 `gpt-5-mini`)", "테스트(82개)", "`tests/`, 82개"):
            assert stale not in readme, f"README에 구버전 문구 '{stale}'"
    print("민감정보 검사 통과 (.env·감사 로그·업로드 파일 미포함) · 기획서 PDF 최신 여부 검사 통과")


if __name__ == "__main__":
    sys.exit(main())

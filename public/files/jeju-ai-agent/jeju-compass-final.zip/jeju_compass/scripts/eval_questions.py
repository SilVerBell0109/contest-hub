"""규칙 플래너 해석 정확도 평가 — 구어체 질문 세트(정답 라벨 포함).

사용: python scripts/eval_questions.py [--data sample_data]
출력: 질문별 (분석 종류 / 동네 / 업종) 일치 여부와 전체 정확도. 기획서·결과 설명자료의 수치 근거.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from compass.loader import DataStore  # noqa: E402
from compass.planner import rule_based_plan  # noqa: E402

# (질문, 기대 분석 종류, 기대 동네 라벨에 포함될 문자열, 기대 업종 라벨에 포함될 문자열)
# 분석 종류: market_summary / time_pattern / region_compare / tourist / footfall / competition / site_score / navigator / clarify
CASES = [
    ("애월읍 카페 장사 잘 돼?", "market_summary", "애월읍", "커피"),
    ("애월읍 카페 상권 요약해줘", "market_summary", "애월읍", "커피"),
    ("노형동 한식집 요즘 어때", "market_summary", "노형동", "한식"),
    ("연동에서 치킨집 하면 손님 많아?", "market_summary", "연동", "치킨"),
    ("협재에서 카페 하려는데 어때?", "market_summary", "한림읍", "커피"),
    ("함덕 횟집 매출 작년이랑 비교해줘", "market_summary", "조천읍", "한식"),
    ("삼양동 편의점", "market_summary", "삼양", "편의점"),
    ("일도2동 분식집 최근 6개월", "market_summary", "일도이동", "간이음식"),
    ("서귀포 중문 숙박업소 2026년 여름 전년 대비", "market_summary", "중문", "숙박"),
    ("제주시 카페 올해 상반기", "market_summary", "제주시", "커피"),
    ("연동 주점은 몇 시에 손님이 많아?", "time_pattern", "연동", "주점"),
    ("성산읍 음식점 시간대별 요일별 패턴", "time_pattern", "성산읍", "음식점"),
    ("중문동 숙박 주말과 평일 매출 비교", "time_pattern", "중문동", "숙박"),
    ("노형동 술집 언제 손님 많아", "time_pattern", "노형동", "주점"),
    ("애월읍 카페 피크 시간", "time_pattern", "애월읍", "커피"),
    ("노형동과 연동 카페 비교", "region_compare", "노형동", "커피"),
    ("서귀포시 동부 읍면별 음식점 매출 순위", "region_compare", "서귀포시 동부", "음식점"),
    ("제주 전체 카페 지역 순위", "region_compare", "제주도 전체", "커피"),
    ("삼양동이랑 화북동 치킨집 비교", "region_compare", "삼양", "치킨"),
    ("서귀포시 외국인 관광객 소비 추이", "tourist", "서귀포시", "전체"),
    ("애월읍 카페 중국인 관광객 소비", "tourist", "애월읍", "커피"),
    ("우도 음식점 관광객 비중", "tourist", "우도", "음식점"),
    ("제주 전체 외국인 관광객 소비 추이", "tourist", "제주도 전체", "전체"),
    ("구좌읍 유동인구 분석", "footfall", "구좌읍", "전체"),
    ("방문인구 대비 소비가 높은 동네는?", "footfall", "제주도 전체", "전체"),
    ("한림읍 유동인구 월별 추이", "footfall", "한림읍", "전체"),
    ("한림읍 카페 경쟁 밀도", "competition", "한림읍", "커피"),
    ("한림읍 카페 너무 많은 거 아니야?", "competition", "한림읍", "커피"),
    ("서귀포시 동부 음식점 개폐업 추이", "competition", "서귀포시 동부", "음식점"),
    ("애월읍에 치킨집 몇 개나 있어?", "competition", "애월읍", "치킨"),
    ("제주시 서부 읍면 중 카페 창업 후보지 비교", "site_score", "제주시 서부", "커피"),
    ("한림읍이랑 구좌읍 중에 카페 하기 어디가 좋아?", "site_score", "구좌읍", "커피"),
    ("성산읍, 표선면, 남원읍 중 펜션 어디가 좋아?", "site_score", "성산읍", "숙박"),
    ("노형동 연동 중에 2호점 내기 어디가 나아? 카페", "site_score", "노형동", "커피"),
    ("이 분석에 어떤 데이터가 필요해?", "navigator", "", ""),
    ("카페 입지 분석에 어떤 데이터가 필요해?", "navigator", "", ""),
    ("도움말", "navigator", "", ""),
    ("애월읍 월세 얼마야?", "navigator", "애월읍", ""),
    ("창업하려는데 뭘 봐야 해?", "navigator", "", ""),
    ("우리 동네 치킨집 잘 돼?", "clarify", "", "치킨"),
    ("강남 카페 상권", "clarify", "", "커피"),
    ("카페 상권", "clarify", "", "커피"),
    # 2차 도민 검토에서 틀렸던 표현들
    ("애월읍 카페 올해 여름 작년이랑 비교", "market_summary", "애월읍", "커피"),
    ("2호점 내도 돼?", "clarify", "", ""),
    ("외국인 손님 많아?", "clarify", "", ""),
    ("애월읍 카페 재작년이랑 비교", "market_summary", "애월읍", "커피"),
    ("애월읍 카페 2025년 vs 2026년", "market_summary", "애월읍", "커피"),
    ("애월읍 카페 망하는 데 많아?", "competition", "애월읍", "커피"),
    ("애월읍 카페 저녁 장사 어때", "time_pattern", "애월읍", "커피"),
    ("애월읍 사람 많이 다녀?", "footfall", "애월읍", ""),
    ("대출 받을 수 있어?", "navigator", "", ""),
    ("손님 언제 많아", "clarify", "", ""),
    ("한림이랑 구좌 중에 어디가 나아", "clarify", "", ""),
    ("제주 카페 다 합쳐서 얼마야", "market_summary", "제주도 전체", "커피"),
    ("작년보다 나아졌어?", "clarify", "", ""),
    ("애월읍 작년보다 나아졌어? 카페", "market_summary", "애월읍", "커피"),
    ("서울 강남 카페", "clarify", "", "커피"),
    ("애월읍 상권 요약", "clarify", "애월읍", ""),
    ("애월읍 전체 업종 상권 요약", "market_summary", "애월읍", "전체"),
    # 2차 심사 검토에서 나온 오탐 문장(일상어 속 미지원 키워드·일반 명사)
    ("노형동 카페 매출 10억원가량 돼?", "market_summary", "노형동", "커피"),
    ("성산일출봉 전망대 근처 카페 상권", "market_summary", "성산읍", "커피"),
    ("노형동 카페 매장이 몇 개나 있어", "competition", "노형동", "커피"),
    ("카페 매출 1위 동네가 어디야", "region_compare", "", "커피"),
    ("전체 카페 요약해줘", "market_summary", "", "커피"),
    ("최근 2년 애월읍 카페 매출", "market_summary", "애월읍", "커피"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(ROOT / "sample_data"))
    args = ap.parse_args()
    store = DataStore()
    store.scan_folder(Path(args.data), origin="sample")
    ok_t = ok_r = ok_i = ok_all = 0
    rows = []
    for q, tpl, reg, ind in CASES:
        p = rule_based_plan(q, store)
        got_t = "clarify" if p.clarify else p.template
        t_ok = got_t == tpl
        r_ok = (reg in (p.region_label or "")) if reg else True
        i_ok = (ind in (p.industry_label or "")) if ind else True
        ok_t += t_ok; ok_r += r_ok; ok_i += i_ok; ok_all += (t_ok and r_ok and i_ok)
        rows.append((q, tpl, got_t, p.region_label, p.industry_label, t_ok and r_ok and i_ok))
    for q, tpl, got_t, rl, il, ok in rows:
        print(f"{'OK ' if ok else 'NG '} {q:34} | {got_t:15} (기대 {tpl:15}) | {rl} / {il}")
    n = len(CASES)
    print("-" * 100)
    print(f"분석 종류 {ok_t}/{n} ({ok_t / n * 100:.0f}%) · 동네 {ok_r}/{n} ({ok_r / n * 100:.0f}%) · 업종 {ok_i}/{n} ({ok_i / n * 100:.0f}%) · 셋 다 일치 {ok_all}/{n} ({ok_all / n * 100:.0f}%)")


if __name__ == "__main__":
    main()

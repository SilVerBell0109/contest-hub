"""합성(샘플) 데이터 생성기 — 제주빅데이터센터 데이터 명세 구조를 따른 가상 데이터.

※ 실제 데이터가 아닙니다. 센터 데이터는 센터 PC에서만 조회·활용할 수 있으므로, 개발·시연·테스트용으로
   명세서의 컬럼 구조와 현실적인 분포(계절성, 지역·업종 특성, 관광객 구성)를 흉내 낸 데이터를 만듭니다.
생성 파일(기본 sample_data/):
  card_emd_sample.csv        카드 이용 현황(읍면동)_v02 구조
  card_time_sample.csv       카드 이용 현황(시간대)_v02 구조 (3시간 구간)
  card_dow_sample.csv        카드 이용 현황(요일별)_v02 구조
  footfall_emd_sample.csv    내국인 유동인구(읍면동)_v02 구조
  store_cnt_sample.csv       제주도 내 업종별 매장 수 구조
  hub_card_industry_sample.csv  제주데이터허브 '업종별 성별 카드 이용 정보' 구조(한글 헤더)
사용: python scripts/make_sample_data.py [--out sample_data] [--start 202501] [--end 202609] [--seed 7] [--scale 1.0]
"""
from __future__ import annotations

import argparse
import sys
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from compass import geo  # noqa: E402
from compass.textutil import months_between  # noqa: E402

# ── 지역 기본 규모(월간 도민 카드 이용자 수 기준, 전체 업종) & 관광 친화도 ──
REGION_SIZE = {
    "노형동": 60000, "연동": 55000, "이도이동": 40000, "일도이동": 25000, "아라일동": 20000, "삼도이동": 15000, "이도일동": 12000, "일도일동": 9000,
    "삼도일동": 8000, "용담이동": 12000, "용담일동": 6000, "건입동": 9000, "화북일동": 10000, "삼양이동": 8000, "오라이동": 7000, "외도일동": 12000,
    "도남동": 9000, "봉개동": 3000, "아라이동": 4000, "도련일동": 3000, "영평동": 3000, "해안동": 2000, "이호일동": 4000, "도두일동": 3500, "회천동": 1500,
    "애월읍": 25000, "한림읍": 18000, "조천읍": 18000, "구좌읍": 12000, "한경면": 5000, "추자면": 800, "우도면": 2000,
    "서귀동": 25000, "동홍동": 20000, "서홍동": 10000, "중문동": 15000, "법환동": 6000, "강정동": 8000, "색달동": 4000, "대포동": 3000, "토평동": 4000,
    "하효동": 3500, "신효동": 3000, "상효동": 2000, "호근동": 4000, "서호동": 3500, "보목동": 1500, "영남동": 800, "도순동": 1500, "하원동": 1800,
    "회수동": 1200, "상예동": 1500, "하예동": 1500, "월평동(서귀포)": 1200,
    "대정읍": 15000, "안덕면": 10000, "표선면": 8000, "성산읍": 12000, "남원읍": 10000,
}
TOURIST_AFFINITY = {
    "중문동": 3.0, "애월읍": 2.5, "성산읍": 2.5, "우도면": 3.0, "색달동": 2.5, "구좌읍": 2.0, "조천읍": 1.8, "한림읍": 1.8, "안덕면": 1.8, "표선면": 1.8,
    "연동": 1.5, "용담이동": 1.5, "서귀동": 1.5, "한경면": 1.5, "대정읍": 1.3, "남원읍": 1.3, "삼도이동": 1.3, "건입동": 1.3, "대포동": 2.0, "법환동": 1.2,
    "노형동": 0.9, "이도이동": 0.6, "일도이동": 0.8, "아라일동": 0.5, "동홍동": 0.7, "서홍동": 0.7, "추자면": 1.2,
}
# (코드, 업종명, 도민 비중, 내국인관광 배수, 외국인 배수, 평균 결제액(원), 시간대 프로필, 요일 프로필 유형)
INDUSTRIES = [
    ("I56111", "한식 음식점업", 0.18, 1.3, 1.0, 32000, "meal", "flat"),
    ("I56221", "커피 전문점", 0.12, 1.5, 1.2, 9000, "cafe", "weekend"),
    ("G47122", "체인화 편의점", 0.08, 1.0, 1.0, 8000, "store", "flat"),
    ("I56112", "중식 음식점업", 0.03, 1.0, 2.0, 28000, "meal", "flat"),
    ("I56113", "일식 음식점업", 0.03, 1.2, 1.2, 45000, "meal", "weekend"),
    ("I56193", "치킨 전문점", 0.04, 0.9, 0.5, 22000, "night", "weekend"),
    ("I56191", "제과점업", 0.04, 1.1, 1.0, 12000, "cafe", "flat"),
    ("I56211", "일반 유흥 주점업", 0.03, 0.8, 0.7, 60000, "bar", "friday"),
    ("I55101", "호텔업", 0.01, 8.0, 6.0, 110000, "hotel", "weekend"),
    ("N76110", "자동차 임대업", 0.01, 15.0, 3.0, 95000, "day", "weekend"),
    ("G47599", "기념품 및 토산품 소매업", 0.01, 10.0, 15.0, 45000, "shop", "weekend"),
    ("R91211", "골프장 운영업", 0.02, 2.0, 1.5, 150000, "day", "weekend"),
    ("Q86201", "의원", 0.08, 0.1, 0.2, 40000, "day", "weekday"),
    ("P85501", "일반 교과 학원", 0.05, 0.0, 0.0, 150000, "day", "weekday"),
]
USER_MIX = {"제주도민": 1.0, "내국인": 0.55, "중국": 0.06, "일본": 0.012, "동남아": 0.02, "기타외국": 0.015}
AGE = ["20", "30", "40", "50", "60"]
AGE_MIX = {"제주도민": [0.15, 0.22, 0.25, 0.22, 0.16], "내국인": [0.28, 0.30, 0.22, 0.13, 0.07]}
TIME_BANDS = ["00-03시", "03-06시", "06-09시", "09-12시", "12-15시", "15-18시", "18-21시", "21-24시"]
TIME_PROFILE = {
    "meal": [0.01, 0.005, 0.05, 0.2, 0.3, 0.1, 0.28, 0.055], "cafe": [0.01, 0.005, 0.08, 0.25, 0.3, 0.25, 0.09, 0.015],
    "bar": [0.15, 0.03, 0.005, 0.01, 0.03, 0.08, 0.35, 0.345], "store": [0.08, 0.03, 0.08, 0.14, 0.17, 0.17, 0.19, 0.14],
    "hotel": [0.05, 0.02, 0.05, 0.1, 0.2, 0.35, 0.18, 0.05], "shop": [0.01, 0.005, 0.03, 0.2, 0.3, 0.3, 0.12, 0.035],
    "night": [0.08, 0.02, 0.01, 0.03, 0.1, 0.12, 0.35, 0.29], "day": [0.005, 0.005, 0.07, 0.3, 0.25, 0.25, 0.1, 0.02],
}
DOWS = ["월", "화", "수", "목", "금", "토", "일", "공휴일"]
DOW_PROFILE = {
    "flat": [0.135, 0.13, 0.13, 0.13, 0.145, 0.15, 0.13, 0.05], "weekend": [0.11, 0.11, 0.11, 0.115, 0.14, 0.2, 0.16, 0.055],
    "friday": [0.1, 0.1, 0.11, 0.13, 0.2, 0.22, 0.09, 0.05], "weekday": [0.18, 0.18, 0.18, 0.18, 0.18, 0.07, 0.02, 0.01],
}
SEASON = {  # 월별 계절성 (1~12월)
    "제주도민": [0.95, 0.95, 1.0, 1.0, 1.02, 1.0, 1.05, 1.08, 1.0, 1.0, 0.98, 1.1],
    "내국인": [0.8, 0.85, 0.95, 1.05, 1.2, 1.05, 1.45, 1.55, 1.05, 1.25, 0.9, 0.95],
    "중국": [1.3, 1.5, 0.9, 1.0, 1.1, 1.0, 1.3, 1.35, 1.0, 1.6, 0.8, 0.9],
    "일본": [0.9, 1.0, 1.3, 0.9, 1.1, 0.9, 1.0, 1.4, 1.0, 1.1, 1.0, 1.3],
    "동남아": [1.1, 1.0, 1.0, 1.1, 1.0, 1.1, 1.2, 1.2, 0.9, 1.0, 1.1, 1.4],
    "기타외국": [0.9, 0.9, 1.0, 1.1, 1.1, 1.1, 1.3, 1.3, 1.1, 1.1, 0.9, 1.0],
}
GROWTH_YOY = {"제주도민": 1.03, "내국인": 1.02, "중국": 1.35, "일본": 1.1, "동남아": 1.2, "기타외국": 1.15}


def growth_factor(ym: str, user: str, bjd: str, ind_name: str) -> float:
    years = int(ym[:4]) - 2025 + (int(ym[4:6]) - 1) / 12.0
    g = GROWTH_YOY[user] ** years
    if ind_name == "커피 전문점" and bjd in ("애월읍", "구좌읍", "조천읍", "한림읍"):
        g *= 1.10 ** years
    if "주점" in ind_name and bjd in ("노형동", "연동"):
        g *= 0.94 ** years
    if ind_name == "호텔업" and bjd == "중문동":
        g *= 1.06 ** years
    return g


def gen_card_emd(months, rng, scale):
    rows = []
    regions = geo.all_bjd_names()
    for ym in months:
        m = int(ym[4:6]) - 1
        for bjd in regions:
            size = REGION_SIZE.get(bjd, 1500) * scale
            aff = TOURIST_AFFINITY.get(bjd, 0.8)
            district = geo.district_of(bjd)
            for code, name, dshare, tmul, fmul, ticket, _, _ in INDUSTRIES:
                for user, umix in USER_MIX.items():
                    if user == "제주도민":
                        base = size * dshare * umix
                    elif user == "내국인":
                        base = size * dshare * umix * tmul * aff
                    else:
                        base = size * dshare * umix * fmul * aff * (1.6 if (user == "중국" and name in ("기념품 및 토산품 소매업", "중식 음식점업")) else 1.0)
                    if base <= 0:
                        continue
                    base *= SEASON[user][m] * growth_factor(ym, user, bjd, name)
                    if user in ("제주도민", "내국인"):
                        trips = [("도민", 1.0)] if user == "제주도민" else [("개별", 0.82), ("단체", 0.18)]
                        for trip, tshare in trips:
                            if trip == "단체":
                                # 단체는 연령·성별 미상으로 집계되는 구조
                                lam = base * tshare * rng.lognormal(0, 0.08)
                                uc = rng.poisson(lam)
                                if uc <= 0:
                                    continue
                                cnt = uc + rng.poisson(uc * 0.25)
                                amt = int(cnt * ticket * (1.25 if user == "내국인" else 0.9) * rng.lognormal(0, 0.1))
                                rows.append((ym, district, bjd, code, name, user, trip, "알수없음", "알수없음", int(uc), int(cnt), amt))
                                continue
                            for ai, age in enumerate(AGE):
                                for gender, gshare in (("남성", 0.48), ("여성", 0.52)):
                                    lam = base * tshare * AGE_MIX[user][ai] * gshare * rng.lognormal(0, 0.08)
                                    uc = rng.poisson(lam)
                                    if uc <= 0:
                                        continue
                                    cnt = uc + rng.poisson(uc * 0.35)
                                    amt = int(cnt * ticket * (1.2 if user == "내국인" else 0.9) * (1.1 if age in ("40", "50") else 0.95) * rng.lognormal(0, 0.1))
                                    rows.append((ym, district, bjd, code, name, user, trip, age, gender, int(uc), int(cnt), amt))
                    else:
                        for trip, tshare in (("개별", 0.6 if user != "중국" else 0.45), ("단체", 0.4 if user != "중국" else 0.55)):
                            lam = base * tshare * rng.lognormal(0, 0.1)
                            uc = rng.poisson(lam)
                            if uc <= 0:
                                continue
                            cnt = uc + rng.poisson(uc * 0.3)
                            mul = {"중국": 1.6, "일본": 1.1, "동남아": 1.0, "기타외국": 1.2}[user]
                            amt = int(cnt * ticket * mul * rng.lognormal(0, 0.12))
                            rows.append((ym, district, bjd, code, name, user, trip, "알수없음", "알수없음", int(uc), int(cnt), amt))
    cols = ["ym", "dstrct_se", "bjd", "ksic_cd", "ksic_nm", "user_se", "trip_se", "age_se", "gender_se", "user_cnt", "use_cnt", "use_amt"]
    return pd.DataFrame(rows, columns=cols)


def _split_by_profile(df: pd.DataFrame, dim_name: str, labels: list[str], profile_key_col: str, profiles: dict, user_adjust=None, rng=None) -> pd.DataFrame:
    """집계 프레임을 프로필 비율로 나눠 새 차원을 추가(시간대/요일)."""
    out = []
    for key, grp in df.groupby(profile_key_col, observed=True):
        prof = np.array(profiles[key], dtype=float)
        for lab, p in zip(labels, prof):
            g = grp.copy()
            adj = user_adjust(g, lab) if user_adjust else 1.0
            share = p * adj
            g[dim_name] = lab
            g["user_cnt"] = np.maximum(0, rng.poisson(g["user_cnt"].values * share)) if rng is not None else (g["user_cnt"] * share).round()
            g["use_cnt"] = np.maximum(g["user_cnt"], (g["use_cnt"] * share).round())
            g["use_amt"] = (g["use_amt"] * share * rng.lognormal(0, 0.05, len(g))).round() if rng is not None else (g["use_amt"] * share).round()
            out.append(g[g["user_cnt"] > 0])
    return pd.concat(out, ignore_index=True)


TIME_DOW_INDUSTRIES = ["한식 음식점업", "커피 전문점", "체인화 편의점", "중식 음식점업", "일식 음식점업", "치킨 전문점", "제과점업", "일반 유흥 주점업", "호텔업", "기념품 및 토산품 소매업"]


def gen_card_time_dow(card: pd.DataFrame, rng, months):
    # 이용자구분을 3그룹(제주도민/내국인/외국인)으로, 연령·성별·관광구분 제거 후 분배 → 크기 절감 (최근 12개월·10개 업종)
    base = card[card["ym"].isin(months[-12:]) & card["ksic_nm"].isin(TIME_DOW_INDUSTRIES)].copy()
    base["user_se"] = base["user_se"].map(lambda u: u if u in ("제주도민", "내국인") else "외국인")
    base = base.groupby(["ym", "dstrct_se", "bjd", "ksic_cd", "ksic_nm", "user_se"], as_index=False)[["user_cnt", "use_cnt", "use_amt"]].sum()
    tprof = {name: TIME_PROFILE[tp] for _, name, *_rest, tp, _ in INDUSTRIES}
    dprof = {name: DOW_PROFILE[dp] for _, name, *_rest, _, dp in INDUSTRIES}

    def dow_adjust(g, lab):
        # 관광객은 주말·공휴일 가중
        is_tour = g["user_se"].isin(["내국인", "외국인"]).values
        if lab in ("토", "일", "공휴일"):
            return np.where(is_tour, 1.25, 1.0)
        return np.where(is_tour, 0.92, 1.0)

    time_df = _split_by_profile(base, "time_se", TIME_BANDS, "ksic_nm", tprof, None, rng)
    dow_df = _split_by_profile(base, "dow_se", DOWS, "ksic_nm", dprof, dow_adjust, rng)
    tcols = ["ym", "dstrct_se", "bjd", "ksic_cd", "ksic_nm", "user_se", "time_se", "user_cnt", "use_cnt", "use_amt"]
    dcols = ["ym", "dstrct_se", "bjd", "ksic_cd", "ksic_nm", "user_se", "dow_se", "user_cnt", "use_cnt", "use_amt"]
    return time_df[tcols].astype({"user_cnt": int, "use_cnt": int, "use_amt": int}), dow_df[dcols].astype({"user_cnt": int, "use_cnt": int, "use_amt": int})


def gen_footfall(months, rng, scale):
    rows = []
    vis_age = [0.3, 0.27, 0.2, 0.14, 0.09]
    res_age = [0.17, 0.2, 0.22, 0.22, 0.19]
    tband = [0.04, 0.02, 0.08, 0.17, 0.2, 0.2, 0.18, 0.11]
    for ym in months:
        m = int(ym[4:6]) - 1
        for bjd in geo.all_bjd_names():
            size = REGION_SIZE.get(bjd, 1500) * scale
            aff = TOURIST_AFFINITY.get(bjd, 0.8)
            resid = size * 1.3
            work = size * 0.5 * (1.3 if bjd in ("연동", "노형동", "이도이동", "서귀동", "동홍동") else 0.8)
            visit = size * 2.2 * aff * SEASON["내국인"][m] * (1.02 ** (int(ym[:4]) - 2025))
            for ti, tb in enumerate(TIME_BANDS):
                for ai, age in enumerate(AGE):
                    for gender, gs in (("남성", 0.49), ("여성", 0.51)):
                        r = rng.poisson(resid * res_age[ai] * gs * tband[ti] * 30 / 8)
                        w = rng.poisson(work * res_age[ai] * gs * ([0.01, 0.01, 0.15, 0.25, 0.22, 0.2, 0.12, 0.04][ti]) * 30)
                        v = rng.poisson(visit * vis_age[ai] * gs * tband[ti] * 30 / 8)
                        rows.append((ym, geo.district_of(bjd), bjd, tb, age, gender, int(r), int(w), int(v)))
    return pd.DataFrame(rows, columns=["ym", "dstrct_se", "bjd", "time_se", "age_se", "gender_se", "resd_pop", "work_pop", "visit_pop"])


def gen_store_cnt(card: pd.DataFrame, months, rng):
    last12 = months[-12:]
    monthly = card[card["ym"].isin(last12)].groupby(["ym", "dstrct_se", "bjd", "ksic_cd", "ksic_nm"], as_index=False)["use_amt"].sum()
    base = monthly.groupby(["dstrct_se", "bjd", "ksic_cd", "ksic_nm"], as_index=False)["use_amt"].mean()
    rows = []
    for _, r in base.iterrows():
        ticket = next(i[5] for i in INDUSTRIES if i[0] == r["ksic_cd"])
        monthly_cnt = r["use_amt"] / ticket
        per_store = {"커피 전문점": 400, "한식 음식점업": 500, "체인화 편의점": 2500, "슈퍼마켓": 1800, "호텔업": 350, "자동차 임대업": 300, "골프장 운영업": 2500, "의원": 900, "일반 교과 학원": 120}.get(r["ksic_nm"], 450)
        n0 = max(1, int(round(monthly_cnt / per_store * rng.uniform(0.85, 1.15))))
        for i, ym in enumerate(last12):
            g = 1 + (0.012 if r["ksic_nm"] == "커피 전문점" else 0.002) * i
            rows.append((ym, r["dstrct_se"], r["bjd"], r["ksic_cd"], r["ksic_nm"], max(1, int(round(n0 * g)))))
    return pd.DataFrame(rows, columns=["ym", "dstrct_se", "bjd", "ksic_cd", "ksic_nm", "store_cnt"])


def gen_hub_card_industry(card: pd.DataFrame, rng):
    df = card.copy()
    df["gender_se"] = df["gender_se"].where(df["user_se"].isin(["제주도민", "내국인"]) & (df["gender_se"] != "알수없음"), "알수없음")
    g = df.groupby(["ym", "ksic_nm", "user_se", "gender_se"], as_index=False)[["user_cnt", "use_cnt", "use_amt"]].sum()
    # 법인 행 추가(합성)
    corp = df.groupby(["ym", "ksic_nm"], as_index=False)[["user_cnt", "use_cnt", "use_amt"]].sum()
    corp["user_se"], corp["gender_se"] = "법인", "알수없음"
    for c in ("user_cnt", "use_cnt", "use_amt"):
        corp[c] = (corp[c] * 0.06).round().astype(int)
    g = pd.concat([g, corp], ignore_index=True)
    g = g.rename(columns={"ym": "연월", "ksic_nm": "업종명", "user_se": "이용자구분", "gender_se": "성별", "user_cnt": "이용자수", "use_cnt": "이용건수", "use_amt": "이용금액"})
    return g.sort_values(["연월", "업종명", "이용자구분", "성별"]).reset_index(drop=True)


RESTAURANT_TYPES = [("일반음식점", "한식", 0.42), ("일반음식점", "중국식", 0.05), ("일반음식점", "일식", 0.05), ("일반음식점", "경양식", 0.05),
                    ("일반음식점", "호프/통닭", 0.08), ("일반음식점", "식육(숯불구이)", 0.07), ("일반음식점", "횟집", 0.05), ("일반음식점", "분식", 0.04),
                    ("휴게음식점", "커피숍", 0.12), ("휴게음식점", "제과점", 0.03), ("휴게음식점", "패스트푸드", 0.02), ("휴게음식점", "아이스크림", 0.02)]


def gen_restaurants(rng, scale):
    """허브 공개 '제주특별자치도 음식점 목록(통합)' 구조의 합성 목록 (LOCALDATA 형식)."""
    rows = []
    sizes = {b: REGION_SIZE.get(b, 1500) for b in geo.all_bjd_names()}
    tot = sum(sizes.values())
    n_total = int(9000 * scale)
    types = [t for t in RESTAURANT_TYPES]
    probs = np.array([t[2] for t in types]) / sum(t[2] for t in types)
    k = 0
    for bjd, sz in sizes.items():
        n = max(2, int(round(n_total * sz / tot)))
        aff = TOURIST_AFFINITY.get(bjd, 0.8)
        city = geo.city_of(bjd)
        reg = geo.REGION_BY_NAME[bjd]
        for _ in range(n):
            k += 1
            ti = rng.choice(len(types), p=probs)
            big, small, _ = types[ti]
            if small == "커피숍" and aff > 1.5 and rng.random() < 0.5:
                pass
            yr = int(np.clip(rng.normal(2016, 6), 1985, 2026))
            open_dt = f"{yr}{rng.integers(1, 13):02d}{rng.integers(1, 29):02d}"
            closed = rng.random() < (0.45 if yr < 2015 else 0.15 + (2026 - yr) * 0.03)
            if closed:
                cy = min(2026, yr + int(rng.integers(1, 9)))
                close_dt = f"{cy}{rng.integers(1, 13):02d}{rng.integers(1, 29):02d}"
                status, detail = "폐업", "폐업"
            else:
                close_dt, status, detail = "", "영업/정상", "영업"
            name = f"{bjd[:2]}{small[:2]}{k:05d}"
            dong_part = bjd.replace("(서귀포)", "")
            addr = f"제주특별자치도 {city} {dong_part} {rng.integers(1, 2500)}-{rng.integers(1, 30)}" if reg.kind == "dong" else f"제주특별자치도 {city} {dong_part} {'상대리' if bjd=='한림읍' else '리'} {rng.integers(1, 2500)}"
            area = round(float(rng.lognormal(4.2, 0.5)), 2)
            rows.append((name, big, small, open_dt, "", status, detail, close_dt, "", "", "", area, addr, "", "", "2026-10-17 2:40"))
    cols = ["사업장명", "업종구분대분류", "업종구분소분류", "인허가일자", "인허가취소일자", "영업상태명", "상세영업상태명", "폐업일자", "휴업시작일자", "휴업종료일자", "재개업일자", "소재지면적", "소재지전체주소", "도로명전체주소", "도로명우편번호", "데이터갱신일자"]
    return pd.DataFrame(rows, columns=cols)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "sample_data"))
    ap.add_argument("--start", default="202504")
    ap.add_argument("--end", default="202609")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--scale", type=float, default=1.0, help="규모 배수(행 수가 아니라 수치 크기)")
    ap.add_argument("--plain", action="store_true", help="gzip 압축 없이 .csv로 저장")
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    months = months_between(args.start, args.end)
    ext = ".csv" if args.plain else ".csv.gz"
    print(f"생성 기간 {months[0]}~{months[-1]} ({len(months)}개월), 지역 {len(geo.all_bjd_names())}개, 업종 {len(INDUSTRIES)}개")
    card = gen_card_emd(months, rng, args.scale)
    card.to_csv(out / ("card_emd_sample" + ext), index=False, encoding="utf-8")
    print(f"card_emd_sample.csv: {len(card):,} rows")
    t, d = gen_card_time_dow(card, rng, months)
    t.to_csv(out / ("card_time_sample" + ext), index=False, encoding="utf-8")
    d.to_csv(out / ("card_dow_sample" + ext), index=False, encoding="utf-8")
    print(f"card_time_sample.csv: {len(t):,} rows / card_dow_sample.csv: {len(d):,} rows")
    ff = gen_footfall(months, rng, args.scale)
    ff.to_csv(out / ("footfall_emd_sample" + ext), index=False, encoding="utf-8")
    print(f"footfall_emd_sample.csv: {len(ff):,} rows")
    sc = gen_store_cnt(card, months, rng)
    sc.to_csv(out / ("store_cnt_sample" + ext), index=False, encoding="utf-8")
    print(f"store_cnt_sample.csv: {len(sc):,} rows")
    rest = gen_restaurants(rng, args.scale)
    rest.to_csv(out / ("hub_restaurants_sample" + ext), index=False, encoding="utf-8-sig")
    print(f"hub_restaurants_sample{ext}: {len(rest):,} rows")
    hub = gen_hub_card_industry(card, rng)
    hub.to_csv(out / ("hub_card_industry_sample" + ext), index=False, encoding="utf-8-sig")
    print(f"hub_card_industry_sample.csv: {len(hub):,} rows")
    (out / "README_SAMPLE.txt").write_text(
        "이 폴더의 CSV(.csv.gz, 압축)는 명세 구조를 따른 합성(가상) 데이터입니다. 프로그램이 압축을 그대로 읽습니다. 실제 제주빅데이터센터 데이터가 아니며 수치에 의미가 없습니다.\n"
        f"생성: scripts/make_sample_data.py --start {args.start} --end {args.end} --seed {args.seed}\n"
        "실제 데이터를 data/inbox 에 넣으면 같은 종류의 샘플은 자동으로 교체됩니다.\n", encoding="utf-8")


if __name__ == "__main__":
    main()

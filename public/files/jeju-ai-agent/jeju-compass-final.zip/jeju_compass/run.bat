@echo off
cd /d "%~dp0"
if exist .venv\Scripts\activate.bat (
  call .venv\Scripts\activate.bat
) else (
  echo [WARN] .venv not found. Run install.bat first. Trying system Python ...
)
echo Starting Jeju Commerce Compass. The browser opens in a few seconds.
echo (Address: http://127.0.0.1:8765  -  To stop: close this window or press Ctrl+C)
python app.py
pause
